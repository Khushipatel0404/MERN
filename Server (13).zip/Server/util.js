// const fun = ()=> {
//     console.log("fun is working");
// };

// const fun2 = ()=> {
//     console.log("fun2 is working");
// };


// module.exports = { fun, fun2 };