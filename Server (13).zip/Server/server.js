
import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import crypto from "crypto";
import nodemailer from "nodemailer";
import User from "./models/User.js"; 
import upload from "./middleware/upload.js";
import Application from "./models/Application.js";
import InterviewSchedule from "./models/InterviewSchedule.js";
import JobSeekerProfile from "./models/JobSeekerProfile.js";
import EmployerProfile from "./models/EmployerProfile.js";
import Contact from "./models/Contact.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// ------------------ MongoDB Connection ------------------
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ MongoDB connected");
  } catch (err) {
    console.error("❌ MongoDB connection error:", err.message);
    process.exit(1);
  }
};
connectDB();

// ------------------ Nodemailer Setup ------------------
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
});

transporter.verify((err, success) => {
  if (err) console.error("❌ Mail transporter error:", err);
  else console.log("✅ Mail server ready");
});


// ------------------ Signup ------------------
app.post("/api/signup", async (req, res) => {
  try {
    const { firstName, lastName, email, password, role } = req.body;

    if (!email || !password || !role)
      return res.status(400).json({ success: false, message: "❌ Required fields missing" });

    const exist = await User.findOne({ email });
    if (exist) return res.status(409).json({ success: false, message: "❌ Email already registered!" });

    const newUser = new User({ firstName, lastName, email, password, role: role.toLowerCase() });
    await newUser.save();

    res.status(201).json({ success: true, message: "✅ Registration successful! Complete your profile.", userId: newUser._id });
  } catch (err) {
    res.status(500).json({ success: false, message: "❌ Error in signup", error: err.message });
  }
});


// Approve Application
// app.post("/api/applications/:id/approve", async (req, res) => {
//   try {
//     const { date, meetingLink } = req.body;
//     const applicationId = req.params.id;

//     const appData = await Application.findById(applicationId);
//     if (!appData) return res.status(404).json({ message: "Application not found" });

  
//     if (appData.status !== "pending") {
//       return res.status(400).json({ message: `Already ${appData.status}` });
//     }

  
//     appData.status = "approved";
//     await appData.save();

//     await transporter.sendMail({
//       from: process.env.EMAIL_USER,
//       to: appData.email,
//       subject: "Interview Scheduled",
//       html: `<p>Dear ${appData.name},</p>
//              <p>Your interview has been scheduled.</p>
//              <p><b>Date:</b> ${new Date(date).toLocaleString()}</p>
//              <p><b>Meeting Link:</b> <a href="${meetingLink}">${meetingLink}</a></p>`,
//     });

//     res.json({ success: true, message: "Interview scheduled & mail sent", status: "approved" });
//   } catch (err) {
//     console.error("❌ Approve error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // Reject Application
// app.post("/api/applications/:id/reject", async (req, res) => {
//   try {
//     const applicationId = req.params.id;
//     const appData = await Application.findById(applicationId);
//     if (!appData) return res.status(404).json({ message: "Application not found" });

//     if (appData.status !== "pending") {
//       return res.status(400).json({ message: `Already ${appData.status}` });
//     }

//     appData.status = "rejected";
//     await appData.save();

//     // ✅ Mail send
//     await transporter.sendMail({
//       from: process.env.EMAIL_USER,
//       to: appData.email,
//       subject: "Application Rejected",
//       html: `<p>Dear ${appData.name},</p>
//              <p>We regret to inform you that your application has been rejected.</p>`,
//     });

//     res.json({ success: true, message: "Application rejected & mail sent", status: "rejected" });
//   } catch (err) {
//     console.error("❌ Reject error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// });
// Approve Application
app.post("/api/applications/:id/approve", async (req, res) => {
  try {
    const { date, meetingLink } = req.body;
    const applicationId = req.params.id;

    const appData = await Application.findById(applicationId);
    if (!appData) return res.status(404).json({ message: "Application not found" });

    if (appData.status !== "pending") {
      return res.status(400).json({ message: `Already ${appData.status}` });
    }

    // 1️⃣ Update Application status
    appData.status = "approved";
    await appData.save();

    // 2️⃣ Create InterviewSchedule
    const interview = new InterviewSchedule({
      applicationId: appData._id,
      employerId: appData.employerId,
      jobseekerId: appData.jobseekerId,
      status: "approved",
      interviewDate: date,
      meetingLink,
    });
    await interview.save();

    // 3️⃣ Send Email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: appData.email,
      subject: "Interview Scheduled",
      html: `<p>Dear ${appData.name},</p>
             <p>Your interview has been scheduled.</p>
             <p><b>Date:</b> ${new Date(date).toLocaleString()}</p>
             <p><b>Meeting Link:</b> <a href="${meetingLink}">${meetingLink}</a></p>`,
    });

    res.json({ success: true, message: "Interview scheduled & mail sent", status: "approved", interview });
  } catch (err) {
    console.error("❌ Approve error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Reject Application
app.post("/api/applications/:id/reject", async (req, res) => {
  try {
    const applicationId = req.params.id;
    const appData = await Application.findById(applicationId);
    if (!appData) return res.status(404).json({ message: "Application not found" });

    if (appData.status !== "pending") {
      return res.status(400).json({ message: `Already ${appData.status}` });
    }

    // 1️⃣ Update Application status
    appData.status = "rejected";
    await appData.save();

    // 2️⃣ Optional: create InterviewSchedule with rejected status
    const interview = new InterviewSchedule({
      applicationId: appData._id,
      employerId: appData.employerId,
      jobseekerId: appData.jobseekerId,
      status: "rejected",
    });
    await interview.save();

    // 3️⃣ Send Email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: appData.email,
      subject: "Application Rejected",
      html: `<p>Dear ${appData.name},</p>
             <p>We regret to inform you that your application has been rejected.</p>`,
    });

    res.json({ success: true, message: "Application rejected & mail sent", status: "rejected", interview });
  } catch (err) {
    console.error("❌ Reject error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

app.use("/uploads", express.static("uploads"));

// Apply Job route
app.post("/api/apply-job", upload.single("resume"), async (req, res) => {
  try {
    const { employerId, jobseekerId, name, email, portfolio, coverLetter } = req.body;

    const newApp = new Application({
      employerId,
      jobseekerId,
      name,
      email,
      portfolio,
      coverLetter,
      resume: req.file ? `/uploads/resumes/${req.file.filename}` : null,
    });

    await newApp.save();

    res.json({ success: true, message: "✅ Application submitted", application: newApp });
  } catch (err) {
    console.error("❌ Application error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});
app.get("/jobseekers/count", async (req, res) => {
  try {
    const count = await JobSeekerProfile.countDocuments();
    res.json({ count });
  } catch (err) {
    res.status(500).json({ error: "Error fetching jobseekers count" });
  }
});
// ✅ Get all industries with employer count
app.get("/api/industries", async (req, res) => {
  try {
    const industries = await EmployerProfile.aggregate([
      { $group: { _id: "$industry", count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);
    res.json(industries);
  } catch (err) {
    console.error("❌ Industry fetch error:", err);
    res.status(500).json({ error: "Server error" });
  }
});
app.get("/api/applications/by-user/:userId", async (req, res) => {
  try {
    const { userId } = req.params;

    const employer = await EmployerProfile.findOne({ userId });
    if (!employer) {
      return res.status(404).json({ success: false, message: "Employer profile not found" });
    }

    const applications = await Application.find({ employerId: employer._id })
      .populate({
        path: "jobseekerId", 
        populate: { path: "userId", select: "firstName lastName email" },
      })
      .sort({ createdAt: -1 });

    res.json({ success: true, applications });
  } catch (err) {
    console.error("❌ Error fetching applications:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ✅ Industry wise category list
app.get("/api/categories", async (req, res) => {
  try {
    const categories = await EmployerProfile.aggregate([
      {
        $group: {
          _id: "$industry",         
          count: { $sum: 1 }       
        }
      },
      { $sort: { _id: 1 } }         
    ]);

    res.json({ success: true, categories });
  } catch (err) {
    console.error("❌ Error fetching categories:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});
// Industry wise companies
app.get("/api/industry/:industry", async (req, res) => {
  try {
    const { industry } = req.params;
    const employers = await EmployerProfile.find({ industry });

    res.json({ success: true, employers });
  } catch (err) {
    console.error("❌ Error fetching industry companies:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});
// app.get("/api/employers/:id", async (req, res) => {
//   try {
//     const employer = await EmployerProfile.findById(req.params.id);
//     if (!employer) return res.status(404).json({ message: "Employer not found" });
//     res.json(employer);
//   } catch (err) {
//     res.status(500).json({ message: "Server error", error: err.message });
//   }
// });
app.get("/api/employer/:id", async (req, res) => {
  try {
    const employer = await EmployerProfile.findById(req.params.id);
    if (!employer) {
      return res.status(404).json({ message: "Employer not found" });
    }
    res.json(employer);
  } catch (err) {
    res.status(500).json({ message: "Error fetching employer", error: err.message });
  }
});
app.get("/api/jobseeker/:userId", async (req, res) => {
  try {
    const jobseeker = await JobSeekerProfile.findOne({ userId: req.params.userId }).populate("userId", "name email");
    if (!jobseeker) {
      return res.status(404).json({ message: "Jobseeker profile not found" });
    }
    res.json(jobseeker);
  } catch (err) {
    res.status(500).json({ message: "Error fetching jobseeker", error: err.message });
  }
});
// Get employer count
app.get("/employers/count", async (req, res) => {
  try {
    const count = await EmployerProfile.countDocuments();
    res.json({ count });
  } catch (err) {
    res.status(500).json({ error: "Error fetching employers count" });
  }
});
app.get("/employers", async (req, res) => {
  try {
    const employers = await EmployerProfile.find().populate("userId", "firstName lastName email");
    res.json(employers);
  } catch (err) {
    res.status(500).json({ message: "❌ Error fetching employers", error: err.message });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Admin login
    if (email === "admin@jobentry.com" && password === "admin123") {
      return res.json({
        success: true,
        message: "✅ Admin login successful",
        user: { 
          firstName: "Admin", 
          lastName: "", 
          email, 
          role: "admin", 
          profileCompleted: true 
        },
      });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
      return res.status(401).json({ success: false, message: "❌ Invalid credentials" });
    }

    const normalizedRole = user.role?.toLowerCase().replace(/\s+/g, "");

    res.json({
      success: true,
      message: `✅ ${normalizedRole} login successful`,
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: normalizedRole,
        profileCompleted: user.profileCompleted || false, // important!
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "❌ Error in login", error: err.message });
  }
});

// ------------------ Forgot Password ------------------
app.post("/api/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "❌ User not found" });

    const token = crypto.randomBytes(32).toString("hex");
    user.resetToken = token;
    user.resetTokenExpiry = Date.now() + 3600000;
    await user.save();

    const resetUrl = `http://localhost:3000/reset-password?token=${token}`;
    await transporter.sendMail({ from: process.env.EMAIL_USER, to: user.email, subject: "Password Reset Request", html: `<p>Hello ${user.firstName},</p><p>Click below to reset your password:</p><a href="${resetUrl}">${resetUrl}</a><p>This link will expire in 1 hour.</p>` });

    res.json({ message: "✅ Reset link sent to your email" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "❌ Error sending reset link", error: err.message });
  }
});

// ------------------ Reset Password ------------------
app.post("/api/reset-password", async (req, res) => {
  try {
    const { token, password } = req.body;
    const user = await User.findOne({ resetToken: token, resetTokenExpiry: { $gt: Date.now() } });
    if (!user) return res.status(400).json({ message: "❌ Invalid or expired token" });

    user.password = password; // ⚠️ Use bcrypt hash in production
    user.resetToken = undefined;
    user.resetTokenExpiry = undefined;
    await user.save();

    res.json({ message: "✅ Password reset successful. Please login." });
  } catch (err) {
    res.status(500).json({ message: "❌ Error resetting password", error: err.message });
  }
});

// ------------------ Jobseeker Profile ------------------
// app.post("/api/profile/jobseeker", async (req, res) => {
//   try {
//     const { userId, location } = req.body;
//     if (!userId || !location || !location.city) return res.status(400).json({ success: false, message: "❌ userId and location required" });

//     const profile = new JobSeekerProfile(req.body);
//     await profile.save();
//     await User.findByIdAndUpdate(userId, { profileCompleted: true });

//     res.status(201).json({ success: true, message: "✅ Jobseeker profile created successfully" });
//   } catch (err) {
//     console.error("❌ Jobseeker profile error:", err);
//     res.status(500).json({ success: false, message: "❌ Error creating profile", error: err.message });
//   }
// });
// app.post("/api/profile/jobseeker", async (req, res) => {
//   try {
//     const { userId, location } = req.body;
//     if (!userId || !location || !location.city)
//       return res.status(400).json({
//         success: false,
//         message: "❌ userId and location required",
//       });

//     const profile = new JobSeekerProfile(req.body);
//     await profile.save();
//     await User.findByIdAndUpdate(userId, { profileCompleted: true });

//     res.status(201).json({
//       success: true,
//       message: "✅ Jobseeker profile created successfully",
//     });
//   } catch (err) {
//     res.status(500).json({
//       success: false,
//       message: "❌ Error creating profile",
//       error: err.message,
//     });
//   }
// });
// ------------------ Change Password ------------------
app.post("/api/change-password", async (req, res) => {
  try {
    const { userId, oldPassword, newPassword } = req.body;

    if (!userId || !oldPassword || !newPassword) {
      return res.status(400).json({ success: false, message: "❌ All fields are required" });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: "❌ User not found" });
    }

    
    if (user.password !== oldPassword) {
      return res.status(401).json({ success: false, message: "❌ Old password is incorrect" });
    }

    user.password = newPassword;
    await user.save();

    res.json({ success: true, message: "✅ Password updated successfully" });
  } catch (err) {
    console.error("❌ Change Password Error:", err);
    res.status(500).json({ success: false, message: "❌ Error changing password", error: err.message });
  }
});


app.get("/api/jobdetails/:employerId/:jobseekerId", async (req, res) => {
  try {
    const { employerId, jobseekerId } = req.params;

   
    const employer = await EmployerProfile.findById(employerId).populate("userId", "firstName lastName email");

    if (!employer) {
      return res.status(404).json({ success: false, message: "Employer not found" });
    }

    const jobseeker = await JobSeekerProfile.findOne({ userId: jobseekerId }).populate("userId", "firstName lastName email");

    if (!jobseeker) {
      return res.status(404).json({ success: false, message: "Jobseeker not found" });
    }

    res.json({ success: true, employer, jobseeker });
  } catch (err) {
    console.error("❌ JobDetails error:", err);
    res.status(500).json({ success: false, message: "Server error", error: err.message });
  }
});


app.post("/api/profile/jobseeker", async (req, res) => {
  try {
    const { userId, bio } = req.body;
    if (!userId) {
      return res.status(400).json({ success: false, message: "❌ userId required" });
    }

    const profile = new JobSeekerProfile(req.body);
    await profile.save();

   
    await User.findByIdAndUpdate(userId, { profileCompleted: true });

    res.status(201).json({ success: true, message: "✅ Job seeker profile created", profile });
  } catch (err) {
    console.error("❌ JobSeeker Profile Error:", err);
    res.status(500).json({ success: false, message: "❌ Error creating profile", error: err.message });
  }
});

app.get("/api/profile/jobseeker/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const profile = await JobSeekerProfile.findOne({ userId });

    if (!profile) {
      return res.status(404).json({ success: false, message: "❌ Job seeker profile not found" });
    }

    res.json({ success: true, profile });
  } catch (err) {
    console.error("❌ Fetch JobSeeker Profile Error:", err);
    res.status(500).json({ success: false, message: "❌ Error fetching profile", error: err.message });
  }
});

// ✅ Update Job Seeker Profile
app.put("/api/profile/jobseeker/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const updatedProfile = await JobSeekerProfile.findOneAndUpdate(
      { userId },
      req.body,
      { new: true, runValidators: true }
    );

    if (!updatedProfile) {
      return res.status(404).json({ success: false, message: "❌ Job seeker profile not found" });
    }

    res.json({ success: true, message: "✅ Profile updated", profile: updatedProfile });
  } catch (err) {
    console.error("❌ Update JobSeeker Profile Error:", err);
    res.status(500).json({ success: false, message: "❌ Error updating profile", error: err.message });
  }
});

// ------------------ Employer Profile ------------------
app.post("/api/profile/employer", async (req, res) => {
  try {
    const { userId, companyName } = req.body;
    if (!userId || !companyName) return res.status(400).json({ success: false, message: "❌ userId and companyName required" });

    const profile = new EmployerProfile(req.body);
    await profile.save();
    await User.findByIdAndUpdate(userId, { profileCompleted: true });

    res.status(201).json({ success: true, message: "✅ Employer profile created successfully" });
  } catch (err) {
    console.error("❌ Employer profile error:", err);
    res.status(500).json({ success: false, message: "❌ Error creating profile", error: err.message });
  }
});

// Get Employer Profile by userId
app.get("/api/profile/employer/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const profile = await EmployerProfile.findOne({ userId });

    if (!profile) {
      return res.status(404).json({ success: false, message: "❌ Employer profile not found" });
    }

    res.json({ success: true, profile });
  } catch (err) {
    res.status(500).json({ success: false, message: "❌ Error fetching profile", error: err.message });
  }
});

// Update Employer Profile
app.put("/api/profile/employer/:userId", async (req, res) => {
  try {
    const { userId } = req.params;

    
    const profile = await EmployerProfile.findOne({ userId });
    if (!profile) {
      return res.status(404).json({ success: false, message: "❌ Employer profile not found" });
    }

    
    const updatedProfile = await EmployerProfile.findOneAndUpdate(
      { userId },
      { $set: req.body },
      { new: true } 
    );

    res.json({ success: true, message: "✅ Profile updated successfully", profile: updatedProfile });
  } catch (err) {
    console.error("❌ Employer profile update error:", err);
    res.status(500).json({ success: false, message: "❌ Error updating profile", error: err.message });
  }
});
app.get("/counts", async (req, res) => {
  try {
    const employers = await EmployerProfile.countDocuments();
    const jobSeekers = await JobSeekerProfile.countDocuments();

    res.json({ employers, jobSeekers });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/jobseekers", async (req, res) => {
  try {
    const jobSeekers = await JobSeekerProfile
      .find()
      .populate("userId", "name email"); 
    res.json(jobSeekers);
  } catch (err) {
    console.error("Jobseekers error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// app.post("/api/contact", async (req, res) => {
//   try {
//     const { name, email, subject, message } = req.body;
//     const newContact = new Contact({ name, email, subject, message });
//     await newContact.save();
//     res.status(200).json({ success: true, message: "Message sent successfully!" });
//   } catch (error) {
//     res.status(500).json({ success: false, message: "Error saving message", error });
//   }
// });
app.post("/api/contact", async (req, res) => {
  try {
    console.log("POST /api/contact body:", req.body);
    const { name, email, subject, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ success: false, message: "Name, email and message are required" });
    }

    const newContact = new Contact({ name, email, subject, message });
    await newContact.save();

    return res.status(200).json({ success: true, message: "Message sent successfully!", contact: newContact });
  } catch (error) {
    console.error("❌ Error saving contact:", error);
    return res.status(500).json({ success: false, message: "Error saving message", error: error.message });
  }
});

// ------------------ Get all contacts (admin) ------------------
// app.get("/api/contacts", async (req, res) => {
//   try {
//     const contacts = await Contact.find().sort({ createdAt: -1 });
//     res.json({ success: true, contacts });
//   } catch (err) {
//     console.error("❌ Fetch contacts error:", err);
//     res.status(500).json({ success: false, message: "Error fetching contacts", error: err.message });
//   }
// });
// GET all contacts (admin)
app.get("/api/contacts", async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ createdAt: -1 });
    res.json({ success: true, contacts });
  } catch (err) {
    console.error("❌ Fetch contacts error:", err);
    res.status(500).json({ success: false, message: "Error fetching contacts", error: err.message });
  }
});

// ------------------ Delete a contact (admin) ------------------
// app.delete("/api/contacts/:id", async (req, res) => {
//   try {
//     const id = req.params.id;
//     const deleted = await Contact.findByIdAndDelete(id);
//     if (!deleted) return res.status(404).json({ success: false, message: "Contact not found" });
//     res.json({ success: true, message: "Contact deleted" });
//   } catch (err) {
//     console.error("❌ Delete contact error:", err);
//     res.status(500).json({ success: false, message: "Error deleting contact", error: err.message });
//   }
// });
// DELETE contact (admin)
app.delete("/api/contacts/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const deleted = await Contact.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ success: false, message: "Contact not found" });
    res.json({ success: true, message: "Contact deleted" });
  } catch (err) {
    console.error("❌ Delete contact error:", err);
    res.status(500).json({ success: false, message: "Error deleting contact", error: err.message });
  }
});

// // ✅ Get all applications for a jobseeker (user side)
// app.get("/api/user/applications/:jobseekerId", async (req, res) => {
//   try {
//     const { jobseekerId } = req.params;

//     const applications = await Application.find({ jobseekerId })
//       .populate("employerId", "companyName") // employer details (optional)
//       .sort({ createdAt: -1 });

//     res.json({ success: true, applications });
//   } catch (err) {
//     console.error("❌ Error fetching applications:", err);
//     res.status(500).json({ success: false, message: "Error fetching applications" });
//   }
// });
// // ✅ Get interviews related to jobseeker
// app.get("/api/user/interviews/:jobseekerId", async (req, res) => {
//   try {
//     const { jobseekerId } = req.params;

//     const interviews = await InterviewSchedule.find({ jobseekerId })
//       .populate("applicationId", "name email")
//       .sort({ createdAt: -1 });

//     res.json({ success: true, interviews });
//   } catch (err) {
//     console.error("❌ Error fetching interviews:", err);
//     res.status(500).json({ success: false, message: "Error fetching interviews" });
//   }
// });

// Get all applications for a jobseeker
// app.get("/api/user/applications/:jobseekerId", async (req, res) => {
//   try {
//     const { jobseekerId } = req.params;

//     const applications = await Application.find({ jobseekerId })
//       .populate("employerId", "companyName") // employer name only
//       .sort({ createdAt: -1 });

//     res.json({ success: true, applications });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ success: false, message: "Error fetching applications" });
//   }
// });

// // Get interviews for a jobseeker
// app.get("/api/user/interviews/:jobseekerId", async (req, res) => {
//   try {
//     const { jobseekerId } = req.params;

//     const interviews = await InterviewSchedule.find({ jobseekerId })
//       .populate("applicationId", "name email") // populate app info
//       .sort({ createdAt: -1 });

//     res.json({ success: true, interviews });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ success: false, message: "Error fetching interviews" });
//   }
// });


// Get all applications for a jobseeker
app.get("/api/user/applications/:jobseekerId", async (req, res) => {
  try {
    const { jobseekerId } = req.params;

    const applications = await Application.find({ jobseekerId })
      .populate("employerId", "companyName") // populate employer
      .sort({ createdAt: -1 });

    res.json({ success: true, applications });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error fetching applications" });
  }
});

// Get interviews for a jobseeker
app.get("/api/user/interviews/:jobseekerId", async (req, res) => {
  try {
    const { jobseekerId } = req.params;

    // 🔹 Populate applicationId fully so frontend can match _id
    const interviews = await InterviewSchedule.find({ jobseekerId })
      .populate("applicationId") 
      .sort({ createdAt: -1 });

    res.json({ success: true, interviews });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error fetching interviews" });
  }
});


// ------------------ Start Server ------------------
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
