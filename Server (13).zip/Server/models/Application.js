// import mongoose from "mongoose";

// // const ApplicationSchema = new mongoose.Schema(
// //   {
// //     employerId: { type: mongoose.Schema.Types.ObjectId, ref: "EmployerProfile", required: true },
// //     jobseekerId: { type: mongoose.Schema.Types.ObjectId, ref: "JobSeekerProfile", required: true },
// //     name: { type: String, required: true },
// //     email: { type: String, required: true },
// //     portfolio: { type: String },
// //     coverLetter: { type: String, required: true },
// //     resume: { type: String }, // resume file ka URL ya path store karna
// //   },
// //   { timestamps: true }
// // );
// const ApplicationSchema = new mongoose.Schema(
//   {
//     employerId: { type: mongoose.Schema.Types.ObjectId, ref: "EmployerProfile", required: true },
//     jobseekerId: { type: mongoose.Schema.Types.ObjectId, ref: "JobSeekerProfile", required: true },
//     name: { type: String, required: true },
//     email: { type: String, required: true },
//     portfolio: { type: String },
//     coverLetter: { type: String, required: true },
//     resume: { type: String },
//     status: {
//       type: String,
//       enum: ["pending", "approved", "rejected"],
//       default: "pending",
//     },
//   },
//   { timestamps: true }
// );

// export default mongoose.model("Application", ApplicationSchema);
import mongoose from "mongoose";

const ApplicationSchema = new mongoose.Schema(
  {
    employerId: { type: mongoose.Schema.Types.ObjectId, ref: "EmployerProfile", required: true },
    jobseekerId: { type: mongoose.Schema.Types.ObjectId, ref: "JobSeekerProfile", required: true },
    name: { type: String, required: true },
    email: { type: String, required: true },
    portfolio: { type: String },
    coverLetter: { type: String, required: true },
    resume: { type: String },
    status: {
      type: String,
      enum: ["pending", "approved", "rejected"],
      default: "pending",
    },
  },
  { timestamps: true }
);

export default mongoose.model("Application", ApplicationSchema);
