// import mongoose from "mongoose";

// const jobSeekerProfileSchema = new mongoose.Schema({
//   userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
//   bio: { type: String },
//   skills: { type: String },
//   experience: { type: String },
//   linkedin: { type: String },
//   github: { type: String },
//   education: { type: String },
// }, { timestamps: true });

// const JobSeekerProfile = mongoose.model("JobSeekerProfile", jobSeekerProfileSchema);
// export default JobSeekerProfile;


import mongoose from "mongoose";

const jobSeekerProfileSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "User", 
    required: true 
  },
  bio: { type: String },
  skills: { type: String },
  experience: { type: String },
  education: { type: String },
  linkedin: { type: String },
  github: { type: String },
  resume: { type: String },
  phone: { type: String },
  location: { 
    city: String,
    state: String,
    country: String
  },
  expectedSalary: { type: String },
  availability: { type: String }
}, { timestamps: true });

const JobSeekerProfile = mongoose.model("JobSeekerProfile", jobSeekerProfileSchema);
export default JobSeekerProfile;