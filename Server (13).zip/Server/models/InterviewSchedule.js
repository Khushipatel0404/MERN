// import mongoose from "mongoose";

// const interviewSchema = new mongoose.Schema({
//   applicationId: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "Application",
//     required: true,
//   },
//   employerId: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "EmployerProfile",
//     required: true,
//   },
//   jobseekerId: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "JobSeekerProfile",
//     required: true,
//   },
//   status: {
//     type: String,
//     enum: ["pending", "approved", "rejected"],
//     default: "pending",
//   },
//   interviewDate: { type: Date },
//   meetingLink: { type: String }, // Google Meet / Zoom link
// }, { timestamps: true });

// const InterviewSchedule = mongoose.model("InterviewSchedule", interviewSchema);
// export default InterviewSchedule;
import mongoose from "mongoose";

const interviewSchema = new mongoose.Schema({
  applicationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Application",
    required: true,
  },
  employerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "EmployerProfile",
    required: true,
  },
  jobseekerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "JobSeekerProfile",
    required: true,
  },
  status: {
    type: String,
    enum: ["pending", "approved", "rejected"],
    default: "pending",
  },
  interviewDate: { type: Date },
  meetingLink: { type: String }, // Google Meet / Zoom link
}, { timestamps: true });

export default mongoose.model("InterviewSchedule", interviewSchema);
