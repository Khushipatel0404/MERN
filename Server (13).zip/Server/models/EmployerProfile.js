// import mongoose from "mongoose";

// const employerProfileSchema = new mongoose.Schema({
//   userId: { 
//     type: mongoose.Schema.Types.ObjectId, 
//     ref: "User", 
//     required: true 
//   },
//   companyName: { type: String, required: true },
//   website: { type: String },
//   industry: { type: String },
//   companySize: { type: String },
//   phone: { type: String },
//   email: { type: String },
//   address: { type: String },
//   city: { type: String },
//   state: { type: String },
//   country: { type: String },
//   description: { type: String },
//   logo: { type: String },
//   linkedin: { type: String }
// }, { timestamps: true });

// const EmployerProfile = mongoose.model("EmployerProfile", employerProfileSchema);
// export default EmployerProfile;


import mongoose from "mongoose";

const employerProfileSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "User", 
    required: true 
  },
  companyName: { type: String, required: true },
  website: { type: String },
  industry: { type: String },
  companySize: { type: String },
  phone: { type: String },
  email: { type: String },
  address: { type: String },
  city: { type: String },
  state: { type: String },
  country: { type: String },
  description: { type: String },
  logo: { type: String },
  linkedin: { type: String }
}, { timestamps: true });

const EmployerProfile = mongoose.model("EmployerProfile", employerProfileSchema);
export default EmployerProfile;