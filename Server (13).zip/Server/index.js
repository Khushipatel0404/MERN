
// //single line function 
// // const fun = require('./util');
// // fun();

// const {fun,fun2} = require('./util');
// fun();
// fun2();
