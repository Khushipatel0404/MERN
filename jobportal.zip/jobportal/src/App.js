// // import logo from './logo.svg';
// // import './App.css';
// // import Home from './Components/Home';
// // import Jobdetails from './Components/Jobdetails';
// // import Contact from './Components/Contact';
// // import JobList from './Components/JobList';
// // import Category from './Components/Category';
// // import Testimonial from './Components/Testimonial';
// // import SignInSignUp from './Components/SignInSignUp';
// // import ForgotPassword from './Components/ForgotPassword';
// // import ResetPassword from './Components/ResetPassword';
// // import Test from './Components/Test';
// // import Adm_Dashboard from './AdmComponents/Adm_Dashboard';
// // import Req_DashBoard from './ReqComponents/Req_Dashboard';

// // function App() {
// //   return (
// //     <div className="App">
// //         {/* <Home/> */}
// //      {/* <Jobdetails/> */}
// //      {/* <Contact/> */}
// //       {/* <JobList/> */}
// //       {/* <Category/> */}
// //       {/* <Testimonial/> */}
// //        {/* <SignInSignUp /> */}
// //       {/* <ForgotPassword/> */}
// //       {/* <ResetPassword/> */}
// //       {/* <Test/> */}
// //       {/* <Adm_Dashboard/> */}
// //       {/* <Req_DashBoard/> */}
// //     </div>
// //   );
// // }

// // export default App;



// import logo from './logo.svg';
// import './App.css';
// import Home from './Components/Home';
// import Jobdetails from './Components/Jobdetails';
// import Contact from './Components/Contact';
// import JobList from './Components/JobList';
// import Category from './Components/Category';
// import Testimonial from './Components/Testimonial';
// import SignInSignUp from './Components/SignInSignUp';
// import ForgotPassword from './Components/ForgotPassword';
// import ResetPassword from './Components/ResetPassword';
// import Test from './Components/Test';
// import Adm_Dashboard from './AdmComponents/Adm_Dashboard';
// import Req_DashBoard from './ReqComponents/Req_Dashboard';
// import About from './Components/About';

// // Add these imports for routing
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// function App() {
//   return (
//     <div className="App">
//       <Router>
//         <Routes>
          
//           <Route path="/" element={<Home />} />
//           <Route path="/jobdetails" element={<Jobdetails />} />
//           <Route path="/contact" element={<Contact />} />
//           <Route path="/jobs" element={<JobList />} />
//           <Route path="/category" element={<Category />} />
//           <Route path="/testimonial" element={<Testimonial />} />
//           <Route path="/signin" element={<SignInSignUp />} />

//           <Route path="/forgot-password" element={<ForgotPassword />} />
//           <Route path="/reset-password" element={<ResetPassword />} />
//           <Route path="/test" element={<Test />} />
//           <Route path="/admin" element={<Adm_Dashboard />} />
//           <Route path="/recruiter" element={<Req_DashBoard />} />
//            <Route path="/about" element={<About />} />
//         </Routes>
//       </Router>
//     </div>
//   );
// }

// export default App;

import './App.css';
import Home from './Components/Home';
import Jobdetails from './Components/Jobdetails';
import Contact from './Components/Contact';
import JobList from './Components/JobList';
import Category from './Components/Category';
import Testimonial from './Components/Testimonial';
import SignInSignUp from './Components/SignInSignUp';
import ForgotPassword from './Components/ForgotPassword';
import ResetPassword from './Components/ResetPassword';
import Test from './Components/Test';
import Adm_Dashboard from './AdmComponents/Adm_Dashboard';
import Req_DashBoard from './ReqComponents/Req_Dashboard';
import About from './Components/About';
// import JobSeekerProfileForm from "./Components/JobSeekerProfileForm";
import EmployerProfileForm from "./Components/EmployerProfileForm";
// import JobSeekerProfileForm from "./Components/JobSeekerProfileForm";
import JobSeekerProfileForm from "./Components/JobSeekerProfileForm";
import MyApplications from './Components/MyApplications';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import React, { useState } from 'react';

import UsersPage from "./Components/UsersPage";
function App() {
  const [user, setUser] = useState(() => {
  try {
    const storedUser = localStorage.getItem("user");
    return storedUser ? JSON.parse(storedUser) : null;
  } catch (error) {
    console.error("Failed to parse user from localStorage:", error);
    localStorage.removeItem("user"); // cleanup invalid data
    return null;
  }
});



  

  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Home user={user} setUser={setUser} />} />
          <Route path="/jobdetails" element={<Jobdetails />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/jobs" element={<JobList />} />
          <Route path="/category" element={<Category />} />
          <Route path="/testimonial" element={<Testimonial />} />
          <Route path="/signin" element={<SignInSignUp setUser={setUser} />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/test" element={<Test />} />
          <Route path="/admin" element={<Adm_Dashboard />} />
          <Route path="/recruiter" element={<Req_DashBoard />} />
          <Route path="/about" element={<About />} />
          <Route path="/jobseeker-profile/:userId" element={<JobSeekerProfileForm />} />
          <Route path="/employer-profile/:userId" element={<EmployerProfileForm />} />
          <Route path="/jobseeker-dashboard/:id" element={<Home />} />
<Route path="/employer-dashboard/:id" element={<Req_DashBoard />} />
 <Route path="/admin/users" element={<UsersPage />} />
 <Route path="/industry/:industry" element={<JobList />} />
<Route path="/jobdetails/:employerId/:jobseekerId" element={<Jobdetails />} />
  {/* Other routes */}
  <Route path="/user/applications" element={<MyApplications />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
