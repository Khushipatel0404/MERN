// // import React, { useState } from "react";
// // import "./Adm_Dashboard.css";

// // const Adm_Dashboard = () => {
// //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

// //   return (
// //     <div className="page-wrapper">
// //       {/* Mobile Header */}
// //       <header className="header-mobile">
// //         <div className="header-mobile-bar">
// //           <div className="header-mobile-inner">
// //             <a href="#" className="logo">JOB PORTAL</a>
// //             <button
// //               className="hamburger"
// //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// //             >
// //               ☰
// //             </button>
// //           </div>
// //         </div>
// //         <nav className={`navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// //           <ul className="mobile-nav-list">
// //             <li>
// //               <a href="#" className="nav-link">
// //                 <span className="nav-icon">📊</span> Dashboard
// //               </a>
// //             </li>
// //             <li>
// //               <a href="#" className="nav-link">
// //                 <span className="nav-icon">📄</span> Pages
// //               </a>
// //             </li>
// //           </ul>
// //         </nav>
// //       </header>

// //       {/* Desktop Sidebar */}
// //       <aside className="menu-sidebar">
// //         <div className="sidebar-logo">
// //           <a href="#" className="logo">JOB PORTAL</a>
// //         </div>
// //         <div className="sidebar-content">
// //           <nav>
// //             <ul className="navbar-list">
// //               <li className="nav-item">
// //                 <a href="#" className="nav-link active">
// //                   <span className="nav-icon">📊</span> Dashboard
// //                 </a>
// //               </li>
// //               <li className="nav-item">
// //                 <a href="#" className="nav-link">
// //                   <span className="nav-icon">📄</span> Pages
// //                 </a>
// //               </li>
// //             </ul>
// //           </nav>
// //         </div>
// //       </aside>

// //       {/* Page Container */}
// //       <div className="page-container">
// //         {/* Desktop Header */}
// //         <header className="header-desktop">
// //           <div className="header-wrap">
// //             <div className="search-form">
// //               <input
// //                 className="search-input"
// //                 type="text"
// //                 placeholder="Search for datas & reports..."
// //               />
// //               <button className="search-button">🔍</button>
// //             </div>
// //             <div className="account-wrap">
// //               <div className="account-item">
// //                 <img
// //                   className="avatar"
// //                   src="https://randomuser.me/api/portraits/men/75.jpg"
// //                   alt="Profile"
// //                 />
// //                 <a href="#" className="user-name">Admin</a>
// //               </div>
// //             </div>
// //           </div>
// //         </header>

// //         {/* Main Content */}
// //         <div className="main-content">
// //           <h2 className="welcome-title">Welcome Admin..!</h2>
// //           <div className="stats-row">
// //             <div className="overview-item overview-c1">
// //               <div className="overview-box">
// //                 <div className="overview-icon">👥</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">10,368</div>
// //                   <div className="overview-label">members online</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c2">
// //               <div className="overview-box">
// //                 <div className="overview-icon">🛒</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">388,688</div>
// //                   <div className="overview-label">items sold</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c3">
// //               <div className="overview-box">
// //                 <div className="overview-icon">📅</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">1,086</div>
// //                   <div className="overview-label">this week</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c4">
// //               <div className="overview-box">
// //                 <div className="overview-icon">💰</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">$1,060,386</div>
// //                   <div className="overview-label">total earnings</div>
// //                 </div>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Adm_Dashboard;





// // import React, { useState } from "react";
// // import "./Adm_Dashboard.css";

// // const Adm_Dashboard = () => {
// //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

// //   return (
// //     <div className="page-wrapper">
// //       {/* Mobile Header */}
// //       <header className="header-mobile">
// //         <div className="header-mobile-bar">
// //           <div className="header-mobile-inner">
// //             <a href="#" className="logo">JOB PORTAL</a>
// //             <button
// //               className="hamburger"
// //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// //             >
// //               ☰
// //             </button>
// //           </div>
// //         </div>
// //         <nav className={`navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// //           <ul className="mobile-nav-list">
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📊</span> Dashboard
// //               </a>
// //             </li>
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📄</span> Pages
// //               </a>
// //             </li>
// //           </ul>
// //         </nav>
// //       </header>

// //       {/* Desktop Sidebar */}
// //       <aside className="menu-sidebar">
// //         <div className="sidebar-logo">
// //           <a href="#" className="logo">JOB PORTAL</a>
// //         </div>
// //         <div className="sidebar-content">
// //           <nav>
// //             <ul className="adm-navbar-list">
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link active">
// //                   <span className="adm-nav-icon">📊</span> Dashboard
// //                 </a>
// //               </li>
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link">
// //                   <span className="adm-nav-icon">📄</span> Pages
// //                 </a>
// //               </li>
// //             </ul>
// //           </nav>
// //         </div>
// //       </aside>

// //       {/* Page Container */}
// //       <div className="page-container">
// //         {/* Desktop Header */}
// //         <header className="header-desktop">
// //           <div className="header-wrap">
// //             <div className="search-form">
// //               <input
// //                 className="search-input"
// //                 type="text"
// //                 placeholder="Search for datas & reports..."
// //               />
// //               <button className="search-button">🔍</button>
// //             </div>
// //             <div className="account-wrap">
// //               <div className="account-item">
// //                 <img
// //                   className="avatar"
// //                   src="https://randomuser.me/api/portraits/men/75.jpg"
// //                   alt="Profile"
// //                 />
// //                 <a href="#" className="user-name">Admin</a>
// //               </div>
// //             </div>
// //           </div>
// //         </header>

// //         {/* Main Content */}
// //         <div className="main-content">
// //           <h2 className="welcome-title">Welcome Admin..!</h2>
// //           <div className="stats-row">
// //             <div className="overview-item overview-c1">
// //               <div className="overview-box">
// //                 <div className="overview-icon">👥</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">10,368</div>
// //                   <div className="overview-label">members online</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c2">
// //               <div className="overview-box">
// //                 <div className="overview-icon">🛒</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">388,688</div>
// //                   <div className="overview-label">items sold</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c3">
// //               <div className="overview-box">
// //                 <div className="overview-icon">📅</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">1,086</div>
// //                   <div className="overview-label">this week</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c4">
// //               <div className="overview-box">
// //                 <div className="overview-icon">💰</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">$1,060,386</div>
// //                   <div className="overview-label">total earnings</div>
// //                 </div>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Adm_Dashboard;




// // import React, { useState } from "react";
// // import "./Adm_Dashboard.css";

// // const Adm_Dashboard = () => {
// //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

// //   // Logout handler
// //   const handleLogout = () => {
// //     window.location.href = "/signin"; // Redirect to login page
// //   };

// //   return (
// //     <div className="page-wrapper">
// //       {/* Mobile Header */}
// //       <header className="header-mobile">
// //         <div className="header-mobile-bar">
// //           <div className="header-mobile-inner">
// //             <a href="#" className="logo">JOB PORTAL</a>
// //             <button
// //               className="hamburger"
// //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// //             >
// //               ☰
// //             </button>
// //           </div>
// //         </div>
// //         <nav className={`navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// //           <ul className="mobile-nav-list">
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📊</span> Dashboard
// //               </a>
// //             </li>
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📄</span> Pages
// //               </a>
// //             </li>
// //             <li>
// //               <button
// //                 className="adm-nav-link"
// //                 style={{ background: "none", border: "none", width: "100%", textAlign: "left", cursor: "pointer" }}
// //                 onClick={handleLogout}
// //               >
// //                 <span className="adm-nav-icon">🚪</span> Logout
// //               </button>
// //             </li>
// //           </ul>
// //         </nav>
// //       </header>

// //       {/* Desktop Sidebar */}
// //       <aside className="menu-sidebar">
// //         <div className="sidebar-logo">
// //           <a href="#" className="logo">JOB PORTAL</a>
// //         </div>
// //         <div className="sidebar-content">
// //           <nav>
// //             <ul className="adm-navbar-list">
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link active">
// //                   <span className="adm-nav-icon">📊</span> Dashboard
// //                 </a>
// //               </li>
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link">
// //                   <span className="adm-nav-icon">📄</span> Pages
// //                 </a>
// //               </li>
// //               {/* <li className="adm-nav-item">
// //                 <button
// //                   className="adm-nav-link"
// //                   style={{ background: "none", border: "none", width: "100%", textAlign: "left", cursor: "pointer" }}
// //                   onClick={handleLogout}
// //                 >
// //                   <span className="adm-nav-icon">🚪</span> Logout
// //                 </button>
// //               </li> */}
// //             </ul>
// //           </nav>
// //         </div>
// //       </aside>

// //       {/* Page Container */}
// //       <div className="page-container">
// //         {/* Desktop Header */}
// //         <header className="header-desktop">
// //           <div className="header-wrap">
// //             <div className="search-form">
// //               <input
// //                 className="search-input"
// //                 type="text"
// //                 placeholder="Search for datas & reports..."
// //               />
// //               <button className="search-button">🔍</button>
// //             </div>
// //             <div className="account-wrap">
// //               <div className="account-item">
// //                 <img
// //                   className="avatar"
// //                   src="https://randomuser.me/api/portraits/men/75.jpg"
// //                   alt="Profile"
// //                 />
// //                 <a href="#" className="user-name">Admin</a>
// //                 {/* <button
// //                   onClick={handleLogout}
// //                   style={{
// //                     marginLeft: "15px",
// //                     background: "#e74c3c",
// //                     color: "#fff",
// //                     border: "none",
// //                     borderRadius: "4px",
// //                     padding: "6px 16px",
// //                     cursor: "pointer",
// //                     fontWeight: "bold"
// //                   }}
// //                 >
// //                   Logout
// //                 </button> */}
// //                 <button className="logout-btn" onClick={handleLogout}>
// //   Logout
// // </button>

// //               </div>
// //             </div>
// //           </div>
// //         </header>

// //         {/* Main Content */}
// //         <div className="main-content">
// //           <h2 className="welcome-title">Welcome Admin..!</h2>
// //           <div className="stats-row">
// //             <div className="overview-item overview-c1">
// //               <div className="overview-box">
// //                 <div className="overview-icon">👥</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">10,368</div>
// //                   <div className="overview-label">members online</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c2">
// //               <div className="overview-box">
// //                 <div className="overview-icon">🛒</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">388,688</div>
// //                   <div className="overview-label">items sold</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c3">
// //               <div className="overview-box">
// //                 <div className="overview-icon">📅</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">1,086</div>
// //                   <div className="overview-label">this week</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c4">
// //               <div className="overview-box">
// //                 <div className="overview-icon">💰</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">$1,060,386</div>
// //                   <div className="overview-label">total earnings</div>
// //                 </div>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Adm_Dashboard; 





// // import React, { useState } from "react";
// // import "./Adm_Dashboard.css";

// // const Adm_Dashboard = () => {
// //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
// //   const [isProfileOpen, setIsProfileOpen] = useState(false);

// //   // Logout handler
// //   const handleLogout = () => {
// //     window.location.href = "/signin"; // Redirect to login page
// //   };

// //   return (
// //     <div className="page-wrapper">
// //       {/* Mobile Header */}
// //       <header className="header-mobile">
// //         <div className="header-mobile-bar">
// //           <div className="header-mobile-inner">
// //             <a href="#" className="logo">JOB PORTAL</a>
// //             <button
// //               className="hamburger"
// //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// //             >
// //               ☰
// //             </button>
// //           </div>
// //         </div>
// //         <nav className={`navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// //           <ul className="mobile-nav-list">
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📊</span> Dashboard
// //               </a>
// //             </li>
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📄</span> Pages
// //               </a>
// //             </li>
// //             <li>
// //               <button
// //                 className="adm-nav-link"
// //                 style={{ background: "none", border: "none", width: "100%", textAlign: "left", cursor: "pointer" }}
// //                 onClick={handleLogout}
// //               >
// //                 <span className="adm-nav-icon">🚪</span> Logout
// //               </button>
// //             </li>
// //           </ul>
// //         </nav>
// //       </header>

// //       {/* Desktop Sidebar */}
// //       <aside className="menu-sidebar">
// //         <div className="sidebar-logo">
// //           <a href="#" className="logo">JOB PORTAL</a>
// //         </div>
// //         <div className="sidebar-content">
// //           <nav>
// //             <ul className="adm-navbar-list">
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link active">
// //                   <span className="adm-nav-icon">📊</span> Dashboard
// //                 </a>
// //               </li>
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link">
// //                   <span className="adm-nav-icon">📄</span> Pages
// //                 </a>
// //               </li>
// //             </ul>
// //           </nav>
// //         </div>
// //       </aside>

// //       {/* Page Container */}
// //       <div className="page-container">
// //         {/* Desktop Header */}
// //         <header className="header-desktop">
// //           <div className="header-wrap">
// //             <div className="search-form">
// //               <input
// //                 className="search-input"
// //                 type="text"
// //                 placeholder="Search for datas & reports..."
// //               />
// //               <button className="search-button">🔍</button>
// //             </div>
// //             <div className="account-wrap">
// //               <div className="account-item" style={{ position: "relative" }}>
// //                 <img
// //                   className="avatar"
// //                   src="https://randomuser.me/api/portraits/men/75.jpg"
// //                   alt="Profile"
// //                   style={{ cursor: "pointer" }}
// //                   onClick={() => setIsProfileOpen((prev) => !prev)}
// //                 />
// //                 <a
// //                   href="#"
// //                   className="user-name"
// //                   onClick={e => { e.preventDefault(); setIsProfileOpen((prev) => !prev); }}
// //                   style={{ cursor: "pointer" }}
// //                 >
// //                   Admin
// //                 </a>
// //                 {isProfileOpen && (
// //                   <div
// //                     style={{
// //                       position: "absolute",
// //                       top: "45px",
// //                       right: 0,
// //                       background: "#fff",
// //                       boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
// //                       borderRadius: "6px",
// //                       minWidth: "140px",
// //                       zIndex: 100,
// //                     }}
// //                   >
// //                     <div style={{ padding: "12px 16px", borderBottom: "1px solid #eee" }}>
// //                       <strong>Admin Profile</strong>
// //                     </div>
// //                     <button
// //                       onClick={handleLogout}
// //                       style={{
// //                         width: "100%",
// //                         background: "none",
// //                         border: "none",
// //                         color: "#e74c3c",
// //                         padding: "12px 16px",
// //                         textAlign: "left",
// //                         cursor: "pointer",
// //                         fontWeight: "bold",
// //                         borderRadius: "0 0 6px 6px"
// //                       }}
// //                     >
// //                       Logout
// //                     </button>
// //                   </div>
// //                 )}
// //               </div>
// //             </div>
// //           </div>
// //         </header>

// //         {/* Main Content */}
// //         <div className="main-content">
// //           <h2 className="welcome-title">Welcome Admin..!</h2>
// //           <div className="stats-row">
// //             <div className="overview-item overview-c1">
// //               <div className="overview-box">
// //                 <div className="overview-icon">👥</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">10,368</div>
// //                   <div className="overview-label">members online</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c2">
// //               <div className="overview-box">
// //                 <div className="overview-icon">🛒</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">388,688</div>
// //                   <div className="overview-label">items sold</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c3">
// //               <div className="overview-box">
// //                 <div className="overview-icon">📅</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">1,086</div>
// //                   <div className="overview-label">this week</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c4">
// //               <div className="overview-box">
// //                 <div className="overview-icon">💰</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">$1,060,386</div>
// //                   <div className="overview-label">total earnings</div>
// //                 </div>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Adm_Dashboard;






// // import React, { useState } from "react";
// // import "./Adm_Dashboard.css";

// // const Adm_Dashboard = () => {
// //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
// //   const [isProfileOpen, setIsProfileOpen] = useState(false);

// //   // Logout handler
// //   const handleLogout = () => {
// //     window.location.href = "/signin"; // Redirect to login page
// //   };

// //   return (
// //     <div className="page-wrapper">
// //       {/* Mobile Header */}
// //       <header className="header-mobile">
// //         <div className="header-mobile-bar">
// //           <div className="header-mobile-inner">
// //             <a href="#" className="logo">JOB PORTAL</a>
// //             <button
// //               className="hamburger"
// //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// //             >
// //               ☰
// //             </button>
// //           </div>
// //         </div>
// //         <nav className={`navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// //           <ul className="mobile-nav-list">
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📊</span> Dashboard
// //               </a>
// //             </li>
// //             <li>
// //               <a href="#" className="adm-nav-link">
// //                 <span className="adm-nav-icon">📄</span> Pages
// //               </a>
// //             </li>
// //             <li>
// //               <button
// //                 className="adm-nav-link"
// //                 style={{ background: "none", border: "none", width: "100%", textAlign: "left", cursor: "pointer" }}
// //                 onClick={handleLogout}
// //               >
// //                 <span className="adm-nav-icon">🚪</span> Logout
// //               </button>
// //             </li>
// //           </ul>
// //         </nav>
// //       </header>

// //       {/* Desktop Sidebar */}
// //       <aside className="menu-sidebar">
// //         <div className="sidebar-logo">
// //           <a href="#" className="logo">JOB PORTAL</a>
// //         </div>
// //         <div className="sidebar-content">
// //           <nav>
// //             <ul className="adm-navbar-list">
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link active">
// //                   <span className="adm-nav-icon">📊</span> Dashboard
// //                 </a>
// //               </li>
// //               <li className="adm-nav-item">
// //                 <a href="#" className="adm-nav-link">
// //                   <span className="adm-nav-icon">📄</span> Pages
// //                 </a>
// //               </li>
// //             </ul>
// //           </nav>
// //         </div>
// //       </aside>

// //       {/* Page Container */}
// //       <div className="page-container">
// //         {/* Desktop Header */}
// //         <header className="header-desktop">
// //           <div className="header-wrap">
// //             <div className="search-form">
// //               <input
// //                 className="search-input"
// //                 type="text"
// //                 placeholder="Search for datas & reports..."
// //               />
// //               <button className="search-button">🔍</button>
// //             </div>
// //             <div className="account-wrap">
// //               <div className="account-item" style={{ position: "relative" }}>
// //                 <img
// //                   className="avatar"
// //                   src="https://randomuser.me/api/portraits/men/75.jpg"
// //                   alt="Profile"
// //                   style={{ cursor: "pointer" }}
// //                   onClick={() => setIsProfileOpen((prev) => !prev)}
// //                 />
// //                 <a
// //                   href="#"
// //                   className="user-name"
// //                   onClick={e => { e.preventDefault(); setIsProfileOpen((prev) => !prev); }}
// //                   style={{ cursor: "pointer" }}
// //                 >
// //                   Admin
// //                 </a>
// //                 {isProfileOpen && (
// //                   <div
// //                     style={{
// //                       position: "absolute",
// //                       top: "45px",
// //                       right: 0,
// //                       background: "#fff",
// //                       boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
// //                       borderRadius: "6px",
// //                       minWidth: "160px",
// //                       zIndex: 100,
// //                     }}
// //                   >
// //                     <div style={{ padding: "12px 16px", borderBottom: "1px solid #eee" }}>
// //                       <strong>Admin Profile</strong>
// //                       <div style={{ fontSize: "13px", color: "#888", marginTop: "4px" }}>
// //                         admin@jobentry.com
// //                       </div>
// //                     </div>
// //                     <button
// //                       onClick={handleLogout}
// //                       style={{
// //                         width: "100%",
// //                         background: "none",
// //                         border: "none",
// //                         color: "#e74c3c",
// //                         padding: "12px 16px",
// //                         textAlign: "left",
// //                         cursor: "pointer",
// //                         fontWeight: "bold",
// //                         borderRadius: "0 0 6px 6px"
// //                       }}
// //                     >
// //                       Logout
// //                     </button>
// //                   </div>
// //                 )}
// //               </div>
// //             </div>
// //           </div>
// //         </header>

// //         {/* Main Content */}
// //         <div className="main-content">
// //           <h2 className="welcome-title">Welcome Admin..!</h2>
// //           <div className="stats-row">
// //             <div className="overview-item overview-c1">
// //               <div className="overview-box">
// //                 <div className="overview-icon">👥</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">10,368</div>
// //                   <div className="overview-label">members online</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c2">
// //               <div className="overview-box">
// //                 <div className="overview-icon">🛒</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">388,688</div>
// //                   <div className="overview-label">items sold</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c3">
// //               <div className="overview-box">
// //                 <div className="overview-icon">📅</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">1,086</div>
// //                   <div className="overview-label">this week</div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div className="overview-item overview-c4">
// //               <div className="overview-box">
// //                 <div className="overview-icon">💰</div>
// //                 <div className="overview-text">
// //                   <div className="overview-number">$1,060,386</div>
// //                   <div className="overview-label">total earnings</div>
// //                 </div>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Adm_Dashboard;


// import { useNavigate } from "react-router-dom"; 

// import "./Adm_Dashboard.css";
// import React, { useState, useEffect } from "react";

// import axios from "axios";
// const Adm_Dashboard = () => {
//   const navigate = useNavigate();
//   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
//   const [isProfileOpen, setIsProfileOpen] = useState(false);
//   const [isChangePassOpen, setIsChangePassOpen] = useState(false);
//   const [oldPass, setOldPass] = useState("");
//   const [newPass, setNewPass] = useState("");
//   const [confirmPass, setConfirmPass] = useState("");
//   const [passMsg, setPassMsg] = useState("");
//  const [jobSeekers, setJobSeekers] = useState(1250);
//   const [employers, setEmployers] = useState(320);
//   // For demo: static password
//   const ADMIN_PASSWORD = "admin123";
//   const [adminPassword, setAdminPassword] = useState(ADMIN_PASSWORD);
//   const [jobSeekerList, setJobSeekerList] = useState([]);
//   // Logout handler
//   const handleLogout = () => {
//     window.location.href = "/signin";
//   };
// useEffect(() => {
//   const fetchJobSeekers = async () => {
//     try {
//       const res = await axios.get("http://localhost:5000/jobseekers");
//       console.log("👉 API Response:", res.data);   // DEBUG
//       setJobSeekerList(res.data);
//     } catch (err) {
//       console.error("Error fetching job seekers:", err);
//     }
//   };
//   fetchJobSeekers();
// }, []);
// useEffect(() => {
//   const fetchCounts = async () => {
//     try {
//       const jsRes = await axios.get("http://localhost:5000/jobseekers/count");
//       setJobSeekers(jsRes.data.count);

//       const empRes = await axios.get("http://localhost:5000/employers/count");
//       setEmployers(empRes.data.count);
//     } catch (err) {
//       console.error("Error fetching counts:", err);
//     }
//   };

//   fetchCounts();
// }, []);
// const [employerList, setEmployerList] = useState([]);

// useEffect(() => {
//   const fetchEmployers = async () => {
//     try {
//       const res = await axios.get("http://localhost:5000/employers");
//       setEmployerList(res.data);
//     } catch (err) {
//       console.error("Error fetching employers:", err);
//     }
//   };

//   fetchEmployers();
// }, []);


//   // Change password handler
//   const handleChangePassword = (e) => {
//     e.preventDefault();
//     if (oldPass !== adminPassword) {
//       setPassMsg("Old password is incorrect.");
//     } else if (!newPass || !confirmPass) {
//       setPassMsg("Please fill all fields.");
//     } else if (newPass !== confirmPass) {
//       setPassMsg("New passwords do not match.");
//     } else {
//       setAdminPassword(newPass);
//       setPassMsg("Password changed successfully!");
//       setOldPass("");
//       setNewPass("");
//       setConfirmPass("");
//       setTimeout(() => {
//         setIsChangePassOpen(false);
//         setPassMsg("");
//       }, 1200);
//     }
//   };

//   return (
//     <div className="page-wrapper">
//       {/* Mobile Header */}
//       <header className="header-mobile">
//         <div className="header-mobile-bar">
//           <div className="header-mobile-inner">
//             <a href="#" className="logo">JOB PORTAL</a>
//             <button
//               className="hamburger"
//               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
//             >
//               ☰
//             </button>
//           </div>
//         </div>
//         <nav className={`navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
//           <ul className="mobile-nav-list">
//             <li>
//               <a href="#" className="adm-nav-link">
//                 <span className="adm-nav-icon">📊</span> Dashboard
//               </a>
//             </li>
//             {/* <li>
//               <a href="#" className="adm-nav-link">
//                 <span className="adm-nav-icon">📄</span> Pages
//               </a>
//             </li> */}
//              <li>
//     <a
//       href="#"
//       className="adm-nav-link"
//       onClick={() => navigate("/admin/users")}
//     >
//       <span className="adm-nav-icon">📄</span> User Information
//     </a>
//   </li>
//             <li>
//               <button
//                 className="adm-nav-link"
//                 style={{ background: "none", border: "none", width: "100%", textAlign: "left", cursor: "pointer" }}
//                 onClick={handleLogout}
//               >
//                 <span className="adm-nav-icon">🚪</span> Logout
//               </button>
//             </li>
//           </ul>
//         </nav>
//       </header>

//       {/* Desktop Sidebar */}
//       {/* <aside className="menu-sidebar">
//         <div className="sidebar-logo">
//           <a href="#" className="logo">JOB PORTAL</a>
//         </div>
//         <div className="sidebar-content">
//           <nav>
//             <ul className="adm-navbar-list">
//               <li className="adm-nav-item">
//                 <a href="#" className="adm-nav-link active">
//                   <span className="adm-nav-icon">📊</span> Dashboard
//                 </a>
//               </li>
            
//             </ul>
//           </nav>
//         </div>
//       </aside> */}

//       {/* Page Container */}
//       <div className="page-container">
//         {/* Desktop Header */}
//         <header className="header-desktop">
//           <div className="header-wrap">
//             <div className="search-form">
//               <input
//                 className="search-input"
//                 type="text"
//                 placeholder="Search for datas & reports..."
//               />
//               <button className="search-button">🔍</button>
//             </div>
//             <div className="account-wrap">
//               <div className="account-item" style={{ position: "relative" }}>
//                 <img
//                   className="avatar"
//                   src="https://randomuser.me/api/portraits/men/75.jpg"
//                   alt="Profile"
//                   style={{ cursor: "pointer" }}
//                   onClick={() => setIsProfileOpen((prev) => !prev)}
//                 />
//                 <a
//                   href="#"
//                   className="user-name"
//                   onClick={e => { e.preventDefault(); setIsProfileOpen((prev) => !prev); }}
//                   style={{ cursor: "pointer" }}
//                 >
//                   Admin
//                 </a>
//                 {isProfileOpen && (
//                   <div
//                     style={{
//                       position: "absolute",
//                       top: "45px",
//                       right: 0,
//                       background: "#fff",
//                       boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
//                       borderRadius: "6px",
//                       minWidth: "180px",
//                       zIndex: 100,
//                     }}
//                   >
//                     <div style={{ padding: "12px 16px", borderBottom: "1px solid #eee" }}>
//                       <strong>Admin Profile</strong>
//                       <div style={{ fontSize: "13px", color: "#888", marginTop: "4px" }}>
//                         admin@jobentry.com
//                       </div>
//                     </div>
//                     <button
//                       onClick={() => {
//                         setIsChangePassOpen(true);
//                         setIsProfileOpen(false);
//                       }}
//                       style={{
//                         width: "100%",
//                         background: "none",
//                         border: "none",
//                         color: "#2980b9",
//                         padding: "12px 16px",
//                         textAlign: "left",
//                         cursor: "pointer",
//                         fontWeight: "bold",
//                         borderBottom: "1px solid #eee"
//                       }}
//                     >
//                       Change Password
//                     </button>
//                     <button
//                       onClick={handleLogout}
//                       style={{
//                         width: "100%",
//                         background: "none",
//                         border: "none",
//                         color: "#e74c3c",
//                         padding: "12px 16px",
//                         textAlign: "left",
//                         cursor: "pointer",
//                         fontWeight: "bold",
//                         borderRadius: "0 0 6px 6px"
//                       }}
//                     >
//                       Logout
//                     </button>
//                   </div>
//                 )}
//                 {/* Change Password Modal */}
//                 {isChangePassOpen && (
//                   <div
//                     style={{
//                       position: "fixed",
//                       top: 0,
//                       left: 0,
//                       width: "100vw",
//                       height: "100vh",
//                       background: "rgba(0,0,0,0.3)",
//                       zIndex: 200,
//                       display: "flex",
//                       alignItems: "center",
//                       justifyContent: "center"
//                     }}
//                     onClick={() => setIsChangePassOpen(false)}
//                   >
//                     <div
//                       style={{
//                         background: "#fff",
//                         padding: "30px 24px",
//                         borderRadius: "8px",
//                         minWidth: "320px",
//                         boxShadow: "0 2px 16px rgba(0,0,0,0.18)",
//                         position: "relative"
//                       }}
//                       onClick={e => e.stopPropagation()}
//                     >
//                       <h3 style={{ marginBottom: "18px" }}>Change Password</h3>
//                       <form onSubmit={handleChangePassword}>
//                         <div style={{ marginBottom: "12px" }}>
//                           <input
//                             type="password"
//                             placeholder="Old Password"
//                             value={oldPass}
//                             onChange={e => setOldPass(e.target.value)}
//                             style={{ width: "100%", padding: "8px" }}
//                           />
//                         </div>
//                         <div style={{ marginBottom: "12px" }}>
//                           <input
//                             type="password"
//                             placeholder="New Password"
//                             value={newPass}
//                             onChange={e => setNewPass(e.target.value)}
//                             style={{ width: "100%", padding: "8px" }}
//                           />
//                         </div>
//                         <div style={{ marginBottom: "12px" }}>
//                           <input
//                             type="password"
//                             placeholder="Confirm New Password"
//                             value={confirmPass}
//                             onChange={e => setConfirmPass(e.target.value)}
//                             style={{ width: "100%", padding: "8px" }}
//                           />
//                         </div>
//                         {passMsg && (
//                           <div style={{ color: passMsg.includes("success") ? "green" : "red", marginBottom: "10px" }}>
//                             {passMsg}
//                           </div>
//                         )}
//                         <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px" }}>
//                           <button
//                             type="button"
//                             onClick={() => setIsChangePassOpen(false)}
//                             style={{
//                               background: "#eee",
//                               border: "none",
//                               padding: "8px 18px",
//                               borderRadius: "4px",
//                               cursor: "pointer"
//                             }}
//                           >
//                             Cancel
//                           </button>
//                           <button
//                             type="submit"
//                             style={{
//                               background: "#3498db",
//                               color: "#fff",
//                               border: "none",
//                               padding: "8px 18px",
//                               borderRadius: "4px",
//                               cursor: "pointer"
//                             }}
//                           >
//                             Change
//                           </button>
//                         </div>
//                       </form>
//                     </div>
//                   </div>
//                 )}
//               </div>
//             </div>
//           </div>
//         </header>

//         {/* Main Content */}
//         <div className="main-content">
//           <h2 className="welcome-title">Welcome Admin..!</h2>
//           <div className="stats-row">
           
//             {/* Job Seekers Count */}
//           <div
//         className="overview-item overview-c1"
//         style={{ cursor: "pointer" }}
//         onClick={() => navigate("/admin/jobseekers")}
//       >
//         <div className="overview-box">
//           <div className="overview-icon">👥</div>
//           <div className="overview-text">
//             <div className="overview-number">{jobSeekers}</div>
//             <div className="overview-label">Job Seekers</div>
//           </div>
//         </div>
//       </div>

//       <div
//         className="overview-item overview-c2"
//         style={{ cursor: "pointer" }}
//         onClick={() => navigate("/admin/employers")}
//       >
//         <div className="overview-box">
//           <div className="overview-icon">🏢</div>
//           <div className="overview-text">
//             <div className="overview-number">{employers}</div>
//             <div className="overview-label">Employers</div>
//           </div>
//         </div>
//       </div>
    
               
  
//           </div>
//             <hr/>
//       <div className="jobseekers-section p-6 bg-gray-50 rounded-lg shadow-lg">
//   <h3 className="text-2xl font-bold mb-4 text-green-700">📋 Job Seekers Information</h3>

//   <div className="overflow-x-auto">
//     <table className="min-w-full border border-gray-300 rounded-lg overflow-hidden shadow">
//       <thead className="bg-green-600 !text-black">
//   <tr>
   
//     <th className="p-3 border">Email</th>
//     <th className="p-3 border">Bio</th>
//     <th className="p-3 border">Skills</th>
//     <th className="p-3 border">Experience</th>
//     <th className="p-3 border">Education</th>
//     <th className="p-3 border">Phone</th>
//     <th className="p-3 border">Location</th>
//     <th className="p-3 border">Salary</th>
//     <th className="p-3 border">Availability</th>
//     <th className="p-3 border">Links</th>
//   </tr>
// </thead>

//       <tbody>
//         {jobSeekerList.map((js, idx) => (
//           <tr
//             key={js._id}
//             className={`${
//               idx % 2 === 0 ? "bg-white" : "bg-gray-50"
//             } hover:bg-green-50 transition`}
//           >
//             {/* ✅ Fixed Name */}
           

//             <td className="p-3 border">{js.userId?.email}</td>
//             <td className="p-3 border italic">{js.bio}</td>
//             <td className="p-3 border">{js.skills}</td>
//             <td className="p-3 border">{js.experience}</td>
//             <td className="p-3 border">{js.education}</td>
//             <td className="p-3 border">{js.phone}</td>
//             <td className="p-3 border">
//               {js.location?.city}, {js.location?.state}, {js.location?.country}
//             </td>
//             <td className="p-3 border">{js.expectedSalary}</td>
//             <td className="p-3 border">{js.availability}</td>

//             <td className="p-3 border">
//               <div className="flex flex-col space-y-1">
//                 {js.linkedin && (
//                   <a
//                     href={js.linkedin}
//                     target="_blank"
//                     className="text-blue-600 hover:underline"
//                   >
//                     🔗 LinkedIn
//                   </a>
//                 )}
//                 {js.github && (
//                   <a
//                     href={js.github}
//                     target="_blank"
//                     className="text-gray-700 hover:underline"
//                   >
//                     💻 GitHub
//                   </a>
//                 )}
//                 {js.resume && (
//                   <a
//                     href={js.resume}
//                     target="_blank"
//                     className="text-green-600 hover:underline"
//                   >
//                     📄 Resume
//                   </a>
//                 )}
//               </div>
//             </td>
//           </tr>
//         ))}
//       </tbody>
//     </table>
//   </div>
// </div>

// <hr className="my-6" />

// <hr className="my-6" />

// <div className="employers-section p-6 bg-gray-50 rounded-lg shadow-lg">
//   <h3 className="text-2xl font-bold mb-4 text-blue-700">🏢 Employers Information</h3>

//   <div className="overflow-x-auto">
//     <table className="min-w-full border border-gray-300 rounded-lg overflow-hidden shadow">
//       <thead className="bg-blue-600 text-white">
//         <tr>
//           <th className="p-3 border">Company Name</th>
//           <th className="p-3 border">Email</th>
//           <th className="p-3 border">Industry</th>
//           <th className="p-3 border">Size</th>
//           <th className="p-3 border">Phone</th>
//           <th className="p-3 border">Location</th>
//           <th className="p-3 border">Website</th>
//           <th className="p-3 border">LinkedIn</th>
//         </tr>
//       </thead>

//       <tbody>
//         {employerList.map((emp, idx) => (
//           <tr
//             key={emp._id}
//             className={`${idx % 2 === 0 ? "bg-white" : "bg-gray-50"} hover:bg-blue-50 transition`}
//           >
//             <td className="p-3 border font-semibold">{emp.companyName}</td>
//             <td className="p-3 border">{emp.email || emp.userId?.email}</td>
//             <td className="p-3 border">{emp.industry}</td>
//             <td className="p-3 border">{emp.companySize}</td>
//             <td className="p-3 border">{emp.phone}</td>
//             <td className="p-3 border">
//               {emp.city}, {emp.state}, {emp.country}
//             </td>
//             <td className="p-3 border">
//               {emp.website && (
//                 <a href={emp.website} target="_blank" className="text-blue-600 hover:underline">
//                   🌐 Website
//                 </a>
//               )}
//             </td>
//             <td className="p-3 border">
//               {emp.linkedin && (
//                 <a href={emp.linkedin} target="_blank" className="text-blue-600 hover:underline">
//                   🔗 LinkedIn
//                 </a>
//               )}
//             </td>
//           </tr>
//         ))}
//       </tbody>
//     </table>
//   </div>
// </div>


//         </div>
//       </div>
//     </div>
//   );
// };

// export default Adm_Dashboard;

import { useNavigate } from "react-router-dom"; 
import "./Adm_Dashboard.css";
import React, { useState, useEffect } from "react";
import axios from "axios";

const Adm_Dashboard = () => {
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isChangePassOpen, setIsChangePassOpen] = useState(false);
  const [oldPass, setOldPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [passMsg, setPassMsg] = useState("");
  const [jobSeekers, setJobSeekers] = useState(1250);
  const [employers, setEmployers] = useState(320);
  const [jobSeekerList, setJobSeekerList] = useState([]);
  const [employerList, setEmployerList] = useState([]);
  const [currentView, setCurrentView] = useState('dashboard'); 
// Contact messages ke liye state
const [contacts, setContacts] = useState([]);
const [loading, setLoading] = useState(true);

  // For demo: static password
  const ADMIN_PASSWORD = "admin123";
  const [adminPassword, setAdminPassword] = useState(ADMIN_PASSWORD);

  // Logout handler
  const handleLogout = () => {
    window.location.href = "/signin";
  };

  useEffect(() => {
    const fetchJobSeekers = async () => {
      try {
        const res = await axios.get("http://localhost:5000/jobseekers");
        console.log("👉 API Response:", res.data);
        setJobSeekerList(res.data);
      } catch (err) {
        console.error("Error fetching job seekers:", err);
      }
    };
    fetchJobSeekers();
  }, []);

  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const jsRes = await axios.get("http://localhost:5000/jobseekers/count");
        setJobSeekers(jsRes.data.count);

        const empRes = await axios.get("http://localhost:5000/employers/count");
        setEmployers(empRes.data.count);
      } catch (err) {
        console.error("Error fetching counts:", err);
      }
    };

    fetchCounts();
  }, []);

  useEffect(() => {
    const fetchEmployers = async () => {
      try {
        const res = await axios.get("http://localhost:5000/employers");
        setEmployerList(res.data);
      } catch (err) {
        console.error("Error fetching employers:", err);
      }
    };

    fetchEmployers();
  }, []);

  // Change password handler
  const handleChangePassword = (e) => {
    e.preventDefault();
    if (oldPass !== adminPassword) {
      setPassMsg("Old password is incorrect.");
    } else if (!newPass || !confirmPass) {
      setPassMsg("Please fill all fields.");
    } else if (newPass !== confirmPass) {
      setPassMsg("New passwords do not match.");
    } else {
      setAdminPassword(newPass);
      setPassMsg("Password changed successfully!");
      setOldPass("");
      setNewPass("");
      setConfirmPass("");
      setTimeout(() => {
        setIsChangePassOpen(false);
        setPassMsg("");
      }, 1200);
    }
  };
  const fetchContacts = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/contacts");
      const data = await res.json();
      if (data.success) setContacts(data.contacts || []);
      else alert("Error: " + (data.message || "Failed to load"));
    } catch (err) {
      console.error(err);
      alert("Error fetching contacts");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContacts();
  }, []);
    const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this message?")) return;
    try {
      const res = await fetch(`http://localhost:5000/api/contacts/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setContacts(prev => prev.filter(c => c._id !== id));
      } else {
        alert("Delete failed: " + (data.message || "server error"));
      }
    } catch (err) {
      console.error(err);
      alert("Error deleting message");
    }
  };
const exportToCSV = (data, filename) => {
  if (!data || data.length === 0) {
    alert("No data available to export!");
    return;
  }

  const csvRows = [];
  const headers = Object.keys(data[0]); 
  csvRows.push(headers.join(","));

  data.forEach(item => {
    const values = headers.map(header => {
      const val = item[header] ? item[header] : "";
      return `"${val}"`; 
    });
    csvRows.push(values.join(","));
  });

  const csvContent = csvRows.join("\n");
  const blob = new Blob([csvContent], { type: "text/csv" });
  const url = window.URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.setAttribute("href", url);
  a.setAttribute("download", `${filename}.csv`);
  a.click();
};

  const renderDashboardView = () => (
    <div className="dashboard-content">
      <div className="welcome-section">
        <h2 className="welcome-title">Welcome Admin!</h2>
        <p className="welcome-subtitle">Manage your job portal efficiently</p>
      </div>

      <div className="stats-container">
        <div
          className="stat-card stat-jobseekers"
          onClick={() => setCurrentView('jobseekers')}
          style={{ cursor: "pointer" }}
        >
          <div className="stat-icon">👥</div>
          <div className="stat-info">
            <div className="stat-number">{jobSeekers}</div>
            <div className="stat-label">Job Seekers</div>
          </div>
        </div>

        <div
          className="stat-card stat-employers"
          onClick={() => setCurrentView('employers')}
          style={{ cursor: "pointer" }}
        >
          <div className="stat-icon">🏢</div>
          <div className="stat-info">
            <div className="stat-number">{employers}</div>
            <div className="stat-label">Employers</div>
          </div>
        </div>
        
      </div>

      <div className="quick-actions">
        <h3>Quick Actions</h3>
        <div className="action-buttons">
          <button 
            className="action-btn btn-primary"
            onClick={() => setCurrentView('jobseekers')}
          >
            📋 View Job Seekers
          </button>
          <button 
            className="action-btn btn-secondary"
            onClick={() => setCurrentView('employers')}
          >
            🏢 View Employers
          </button>
        </div>
      </div>
      <div className="container py-4">
      <h3>Contact Messages</h3>
      {contacts.length === 0 ? (
        <div>No messages yet.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Received At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {contacts.map(c => (
                <tr key={c._id}>
                  <td>{c.name}</td>
                  <td>{c.email}</td>
                  <td>{c.subject}</td>
                  <td style={{ maxWidth: 300, whiteSpace: "pre-wrap" }}>{c.message}</td>
                  <td>{new Date(c.createdAt).toLocaleString()}</td>
                  <td>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(c._id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
    </div>
  );

  const renderJobSeekersView = () => (
    <div className="table-section">
     <div className="section-header">
  <h3 className="section-title">📋 Job Seekers Information</h3>
  <div>
    <button 
      className="btn-back"
      onClick={() => setCurrentView('dashboard')}
    >
      ← Back to Dashboard
    </button>
    <button 
      className="btn-export"
      onClick={() => exportToCSV(jobSeekerList, "JobSeekers")}
      style={{ marginLeft: "10px" }}
    >
      ⬇️ Download CSV
    </button>
  </div>
</div>


      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              
              <th>Email</th>
              <th>Bio</th>
              <th>Skills</th>
              <th>Experience</th>
              <th>Education</th>
              <th>Phone</th>
              <th>Location</th>
              <th>Salary</th>
              <th>Availability</th>
              <th>Links</th>
            </tr>
          </thead>
          <tbody>
            {jobSeekerList.map((js, idx) => (
              <tr key={js._id} className={idx % 2 === 0 ? "row-even" : "row-odd"}>
               
                <td>{js.userId?.email}</td>
                <td className="bio-cell">{js.bio || 'N/A'}</td>
                <td>{js.skills || 'N/A'}</td>
                <td>{js.experience || 'N/A'}</td>
                <td>{js.education || 'N/A'}</td>
                <td>{js.phone || 'N/A'}</td>
                <td className="location-cell">
                  {js.location?.city ? `${js.location.city}, ${js.location.state}, ${js.location.country}` : 'N/A'}
                </td>
                <td>{js.expectedSalary || 'N/A'}</td>
                <td>{js.availability || 'N/A'}</td>
                <td className="links-cell">
                  <div className="link-buttons">
                    {js.linkedin && (
                      <a href={js.linkedin} target="_blank" rel="noopener noreferrer" className="link-btn linkedin">
                        LinkedIn
                      </a>
                    )}
                    {js.github && (
                      <a href={js.github} target="_blank" rel="noopener noreferrer" className="link-btn github">
                        GitHub
                      </a>
                    )}
                    {js.resume && (
                      <a href={js.resume} target="_blank" rel="noopener noreferrer" className="link-btn resume">
                        Resume
                      </a>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderEmployersView = () => (
    <div className="table-section">
    <div className="section-header">
  <h3 className="section-title">🏢 Employers Information</h3>
  <div>
    <button 
      className="btn-back"
      onClick={() => setCurrentView('dashboard')}
    >
      ← Back to Dashboard
    </button>
    <button 
      className="btn-export"
      onClick={() => exportToCSV(employerList, "Employers")}
      style={{ marginLeft: "10px" }}
    >
      ⬇️ Download CSV
    </button>
  </div>
</div>


      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Company Name</th>
              <th>Email</th>
              <th>Industry</th>
              <th>Size</th>
              <th>Phone</th>
              <th>Location</th>
              <th>Website</th>
              <th>LinkedIn</th>
            </tr>
          </thead>
          <tbody>
            {employerList.map((emp, idx) => (
              <tr key={emp._id} className={idx % 2 === 0 ? "row-even" : "row-odd"}>
                <td className="company-cell">{emp.companyName}</td>
                <td>{emp.email || emp.userId?.email}</td>
                <td>{emp.industry || 'N/A'}</td>
                <td>{emp.companySize || 'N/A'}</td>
                <td>{emp.phone || 'N/A'}</td>
                <td className="location-cell">
                  {emp.city ? `${emp.city}, ${emp.state}, ${emp.country}` : 'N/A'}
                </td>
                <td>
                  {emp.website && (
                    <a href={emp.website} target="_blank" rel="noopener noreferrer" className="link-btn website">
                      Website
                    </a>
                  )}
                </td>
                <td>
                  {emp.linkedin && (
                    <a href={emp.linkedin} target="_blank" rel="noopener noreferrer" className="link-btn linkedin">
                      LinkedIn
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="admin-wrapper">
      {/* Mobile Header */}
      <header className="mobile-header">
        <div className="mobile-header-content">
          <div className="logo-section">
            <h1 className="logo">JOB PORTAL</h1>
          </div>
          <button
            className="mobile-menu-btn"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            ☰
          </button>
        </div>
        
        {isMobileMenuOpen && (
          <nav className="mobile-nav">
            <ul>
              <li>
                <button onClick={() => {setCurrentView('dashboard'); setIsMobileMenuOpen(false);}}>
                  📊 Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => {setCurrentView('jobseekers'); setIsMobileMenuOpen(false);}}>
                  👥 Job Seekers
                </button>
              </li>
              <li>
                <button onClick={() => {setCurrentView('employers'); setIsMobileMenuOpen(false);}}>
                  🏢 Employers
                </button>
              </li>
              
              <li>
                <button onClick={handleLogout}>🚪 Logout</button>
              </li>
            </ul>
          </nav>
        )}
      </header>

      {/* Desktop Layout */}
      <div className="desktop-layout">
        {/* Sidebar */}
        <aside className="sidebar">
          <div className="sidebar-header">
            <h1 className="sidebar-logo">JOB PORTAL</h1>
          </div>
          <nav className="sidebar-nav">
            <ul>
              <li>
                <button 
                  className={currentView === 'dashboard' ? 'nav-btn active' : 'nav-btn'}
                  onClick={() => setCurrentView('dashboard')}
                >
                  📊 Dashboard
                </button>
              </li>
              <li>
                <button 
                  className={currentView === 'jobseekers' ? 'nav-btn active' : 'nav-btn'}
                  onClick={() => setCurrentView('jobseekers')}
                >
                  👥 Job Seekers
                </button>
              </li>
              <li>
                <button 
                  className={currentView === 'employers' ? 'nav-btn active' : 'nav-btn'}
                  onClick={() => setCurrentView('employers')}
                >
                  🏢 Employers
                </button>
              </li>
              <li>
                  <button 
                    className={currentView === 'logout' ? 'nav-btn active' : 'nav-btn'}
                    onClick={handleLogout}
                  >
                    🚪 Logout
                  </button>
                </li>

            </ul>
          </nav>
        </aside>

        {/* Main Content Area */}
        <div className="main-area">
          {/* Top Header */}
          <header className="top-header">
            <div className="search-section">
              <input
                type="text"
                placeholder="Search for data & reports..."
                className="search-input"
              />
              <button className="search-btn">🔍</button>
            </div>
            
            <div className="profile-section">
              <div className="profile-dropdown" style={{ position: "relative" }}>
                <div 
                  className="profile-trigger"
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                >
                  <img
                    src="https://randomuser.me/api/portraits/men/75.jpg"
                    alt="Admin"
                    className="profile-avatar"
                  />
                  <span className="profile-name">Admin</span>
                </div>

                {isProfileOpen && (
                  <div className="dropdown-menu">
                    <div className="dropdown-header">
                      <strong>Admin Profile</strong>
                      <div className="admin-email">admin@jobportal.com</div>
                    </div>
                    <button
                      className="dropdown-item"
                      onClick={() => {
                        setIsChangePassOpen(true);
                        setIsProfileOpen(false);
                      }}
                    >
                      🔑 Change Password
                    </button>
                    <button
                      className="dropdown-item logout"
                      onClick={handleLogout}
                    >
                      🚪 Logout
                    </button>
                  </div>
                )}
              </div>
            </div>
          </header>

          {/* Dynamic Content */}
          <main className="content-area">
            {currentView === 'dashboard' && renderDashboardView()}
            {currentView === 'jobseekers' && renderJobSeekersView()}
            {currentView === 'employers' && renderEmployersView()}
           
    
          </main>
        </div>
      </div>

      {/* Change Password Modal */}
      {isChangePassOpen && (
        <div className="modal-overlay" onClick={() => setIsChangePassOpen(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Change Password</h3>
              <button 
                className="close-btn"
                onClick={() => setIsChangePassOpen(false)}
              >
                ×
              </button>
            </div>
            
            <form onSubmit={handleChangePassword} className="modal-form">
              <div className="form-group">
                <input
                  type="password"
                  placeholder="Old Password"
                  value={oldPass}
                  onChange={e => setOldPass(e.target.value)}
                  className="form-input"
                />
              </div>
              <div className="form-group">
                <input
                  type="password"
                  placeholder="New Password"
                  value={newPass}
                  onChange={e => setNewPass(e.target.value)}
                  className="form-input"
                />
              </div>
              <div className="form-group">
                <input
                  type="password"
                  placeholder="Confirm New Password"
                  value={confirmPass}
                  onChange={e => setConfirmPass(e.target.value)}
                  className="form-input"
                />
              </div>
              
              {passMsg && (
                <div className={`message ${passMsg.includes("success") ? "success" : "error"}`}>
                  {passMsg}
                </div>
              )}
              
              <div className="modal-actions">
                <button
                  type="button"
                  onClick={() => setIsChangePassOpen(false)}
                  className="btn-cancel"
                >
                  Cancel
                </button>
                <button type="submit" className="btn-submit">
                  Change Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <style jsx>{`
        .admin-wrapper {
          min-height: 100vh;
          background: #f5f7fa;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Mobile Header */
        .mobile-header {
          display: block;
          background: white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          position: sticky;
          top: 0;
          z-index: 1000;
        }

        .mobile-header-content {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
        }

        .logo {
          color: #3498db;
          font-size: 1.5rem;
          font-weight: bold;
          margin: 0;
        }

        .mobile-menu-btn {
          background: none;
          border: none;
          font-size: 1.5rem;
          cursor: pointer;
        }

        .mobile-nav {
          background: white;
          border-top: 1px solid #eee;
        }

        .mobile-nav ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }

        .mobile-nav button {
          width: 100%;
          padding: 1rem;
          background: none;
          border: none;
          text-align: left;
          cursor: pointer;
          border-bottom: 1px solid #eee;
        }

        .mobile-nav button:hover {
          background: #f8f9fa;
        }

        /* Desktop Layout */
        .desktop-layout {
          display: none;
        }

        @media (min-width: 768px) {
          .mobile-header {
            display: none;
          }
          
          .desktop-layout {
            display: flex;
            min-height: 100vh;
          }
        }

        .sidebar {
          width: 250px;
          background: white;
          box-shadow: 2px 0 4px rgba(0,0,0,0.1);
          position: fixed;
          height: 100vh;
          overflow-y: auto;
        }

        .sidebar-header {
          padding: 2rem 1rem;
          border-bottom: 1px solid #eee;
        }

        .sidebar-logo {
          color: #3498db;
          font-size: 1.5rem;
          font-weight: bold;
          margin: 0;
        }

        .sidebar-nav ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }

        .nav-btn {
          width: 100%;
          padding: 1rem;
          background: none;
          border: none;
          text-align: left;
          cursor: pointer;
          transition: background 0.3s;
        }

        .nav-btn:hover, .nav-btn.active {
          background: #e3f2fd;
          color: #1976d2;
        }

        .main-area {
          flex: 1;
          margin-left: 250px;
        }

        .top-header {
          background: white;
          padding: 1rem 2rem;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .search-section {
          display: flex;
          align-items: center;
          flex: 1;
          max-width: 400px;
        }

        .search-input {
          flex: 1;
          padding: 0.75rem;
          border: 1px solid #ddd;
          border-radius: 4px 0 0 4px;
          outline: none;
        }

        .search-btn {
          padding: 0.75rem 1rem;
          background: #3498db;
          color: white;
          border: none;
          border-radius: 0 4px 4px 0;
          cursor: pointer;
        }

        .profile-trigger {
          display: flex;
          align-items: center;
          cursor: pointer;
          gap: 0.5rem;
        }

        .profile-avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
        }

        .dropdown-menu {
          position: absolute;
          top: 100%;
          right: 0;
          background: white;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          border-radius: 8px;
          min-width: 200px;
          z-index: 100;
        }

        .dropdown-header {
          padding: 1rem;
          border-bottom: 1px solid #eee;
        }

        .admin-email {
          font-size: 0.875rem;
          color: #666;
          margin-top: 0.25rem;
        }

        .dropdown-item {
          width: 100%;
          padding: 0.75rem 1rem;
          background: none;
          border: none;
          text-align: left;
          cursor: pointer;
        }

        .dropdown-item:hover {
          background: #f8f9fa;
        }

        .dropdown-item.logout {
          color: #e74c3c;
          border-top: 1px solid #eee;
        }

        .content-area {
          padding: 2rem;
        }

        /* Dashboard Content */
        .welcome-section {
          text-align: center;
          margin-bottom: 3rem;
        }

        .welcome-title {
          font-size: 2.5rem;
          color: #2c3e50;
          margin-bottom: 0.5rem;
        }

        .welcome-subtitle {
          color: #7f8c8d;
          font-size: 1.125rem;
        }

        .stats-container {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
          margin-bottom: 3rem;
        }

        .stat-card {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 2rem;
          border-radius: 12px;
          display: flex;
          align-items: center;
          gap: 1.5rem;
          transition: transform 0.3s;
        }

        .stat-card:hover {
          transform: translateY(-4px);
        }

        .stat-employers {
          background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .stat-icon {
          font-size: 3rem;
        }

        .stat-number {
          font-size: 2.5rem;
          font-weight: bold;
        }

        .stat-label {
          font-size: 1.125rem;
          opacity: 0.9;
        }

        .quick-actions {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .quick-actions h3 {
          margin-bottom: 1.5rem;
          color: #2c3e50;
        }

        .action-buttons {
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
        }

        .action-btn {
          padding: 0.75rem 1.5rem;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          font-weight: 500;
          transition: all 0.3s;
        }

        .btn-primary {
          background: #3498db;
          color: white;
        }

        .btn-secondary {
          background: #95a5a6;
          color: white;
        }

        .action-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        /* Table Section */
        .table-section {
          background: white;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .section-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem 2rem;
          background: #f8f9fa;
          border-bottom: 1px solid #eee;
        }

        .section-title {
          color: #2c3e50;
          margin: 0;
        }

        .btn-back {
          padding: 0.5rem 1rem;
          background: #6c757d;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
        }

        .table-container {
          overflow-x: auto;
        }

        .data-table {
          width: 100%;
          border-collapse: collapse;
        }

        .data-table th {
          background: #f8f9fa;
          padding: 1rem;
          text-align: left;
          font-weight: 600;
          border-bottom: 2px solid #dee2e6;
          white-space: nowrap;
        }

        .data-table td {
          padding: 1rem;
          border-bottom: 1px solid #dee2e6;
        }

        .row-even {
          background: #f8f9fa;
        }

        .row-odd {
          background: white;
        }

        .data-table tr:hover {
          background: #e3f2fd !important;
        }

        .name-cell, .company-cell {
          font-weight: 600;
          color: #2c3e50;
        }

        .bio-cell, .location-cell {
          max-width: 150px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .links-cell {
          min-width: 120px;
        }

        .link-buttons {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .link-btn {
          display: inline-block;
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          text-decoration: none;
          font-size: 0.875rem;
          text-align: center;
          transition: all 0.3s;
        }

        .link-btn.linkedin {
          background: #0077b5;
          color: white;
        }

        .link-btn.github {
          background: #333;
          color: white;
        }

        .link-btn.resume {
          background: #28a745;
          color: white;
        }

        .link-btn.website {
          background: #17a2b8;
          color: white;
        }

        .link-btn:hover {
          opacity: 0.8;
          transform: translateY(-1px);
        }

        /* Modal Styles */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0,0,0,0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .modal-content {
          background: white;
          border-radius: 12px;
          width: 90%;
          max-width: 400px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }

        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem;
          border-bottom: 1px solid #eee;
        }

        .close-btn {
          background: none;
          border: none;
          font-size: 1.5rem;
          cursor: pointer;
        }

        .modal-form {
          padding: 1.5rem;
        }

        .form-group {
          margin-bottom: 1rem;
        }

        .form-input {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid #ddd;
          border-radius: 6px;
          outline: none;
        }

        .message {
          padding: 0.75rem;
          border-radius: 6px;
          margin-bottom: 1rem;
        }

        .message.success {
          background: #d4edda;
          color: #155724;
          border: 1px solid #c3e6cb;
        }

        .message.error {
          background: #f8d7da;
          color: #721c24;
          border: 1px solid #f5c6cb;
        }

        .modal-actions {
          display: flex;
          gap: 1rem;
          justify-content: flex-end;
        }

        .btn-cancel {
          padding: 0.5rem 1rem;
          background: #6c757d;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
        }

        .btn-submit {
          padding: 0.5rem 1rem;
          background: #3498db;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
        }

        @media (max-width: 767px) {
          .main-area {
            margin-left: 0;
          }
          
          .content-area {
            padding: 1rem;
          }
          
          .stats-container {
            grid-template-columns: 1fr;
          }
          
          .action-buttons {
            flex-direction: column;
          }
          
          .section-header {
            flex-direction: column;
            gap: 1rem;
            align-items: flex-start;
          }
          
          .data-table {
            font-size: 0.875rem;
          }
          
          .data-table th,
          .data-table td {
            padding: 0.5rem;
          }
          
          .modal-content {
            margin: 1rem;
          }
        }
      `}</style>
    </div>
  );
};

export default Adm_Dashboard;