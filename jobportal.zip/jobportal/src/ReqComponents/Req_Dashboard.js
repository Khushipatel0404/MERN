
// // // import React, { useState, useEffect } from "react";
// // // import "./Req_Dashboard.css";

// // // const Req_Dashboard = () => {
// // //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
// // //   const [isProfileOpen, setIsProfileOpen] = useState(false);
// // //   const [recruiterName, setRecruiterName] = useState("");
// // //   const [recruiterProfile, setRecruiterProfile] = useState(null);
// // //   const [employerProfile, setEmployerProfile] = useState(null);
// // //   const [isEditOpen, setIsEditOpen] = useState(false);
// // //   const [editData, setEditData] = useState({});
// // // const [applications, setApplications] = useState([]);
// // //   const handleLogout = () => {
// // //     localStorage.removeItem("user");
// // //     window.location.href = "/";
// // //   };

// // //   useEffect(() => {
// // //   const storedUser = JSON.parse(localStorage.getItem("user"));
// // //   if (storedUser && storedUser.id) {
// // //     fetch(`http://localhost:5000/api/applications/by-user/${storedUser.id}`)
// // //       .then((res) => res.json())
// // //       .then((data) => {
// // //         if (data.success) setApplications(data.applications);
// // //       })
// // //       .catch((err) => console.error("Error fetching applications:", err));
// // //   }
// // // }, []);
// // //   useEffect(() => {
// // //     const storedUser = JSON.parse(localStorage.getItem("user"));
// // //     if (storedUser) {
// // //       const fullName = storedUser.firstName
// // //         ? `${storedUser.firstName} ${storedUser.lastName || ""}`
// // //         : storedUser.name || "";
// // //       setRecruiterName(fullName);
// // //       setRecruiterProfile(storedUser);

// // //       // Fetch employer profile
// // //       fetch(`http://localhost:5000/api/profile/employer/${storedUser.id}`)
// // //         .then((res) => res.json())
// // //         .then((data) => {
// // //           if (data.success) setEmployerProfile(data.profile);
// // //         })
// // //         .catch((err) => console.error(err));
// // //     }
// // //   }, []);

// // //   const handleSaveProfile = async () => {
// // //     try {
// // //       const res = await fetch(
// // //         `http://localhost:5000/api/profile/employer/${recruiterProfile.id}`,
// // //         {
// // //           method: "PUT",
// // //           headers: { "Content-Type": "application/json" },
// // //           body: JSON.stringify(editData),
// // //         }
// // //       );
// // //       const data = await res.json();
// // //       if (data.success) {
// // //         setEmployerProfile(data.profile);
// // //         setIsEditOpen(false);
// // //       } else {
// // //         alert("Error updating profile: " + data.message);
// // //       }
// // //     } catch (err) {
// // //       console.error(err);
// // //       alert("❌ Failed to update profile");
// // //     }
// // //   };

// // //   // Field labels
// // //   const profileFields = [
// // //     { key: "companyName", label: "🏢 Company Name" },
// // //     { key: "website", label: "🌐 Website" },
// // //     { key: "industry", label: "🏭 Industry" },
// // //     { key: "companySize", label: "👥 Company Size" },
// // //     { key: "phone", label: "📞 Phone" },
// // //     { key: "email", label: "✉️ Email" },
// // //     { key: "address", label: "📍 Address" },
// // //     { key: "city", label: "🏙️ City" },
// // //     { key: "state", label: "🗺️ State" },
// // //     { key: "country", label: "🌎 Country" },
// // //     { key: "linkedin", label: "🔗 LinkedIn" },
// // //     { key: "logo", label: "🖼️ Logo URL" },
// // //     { key: "description", label: "📝 Description" },
// // //   ];

// // //   return (
// // //     <div className="req-page-wrapper">
// // //       {/* Mobile Header */}
// // //       <header className="req-header-mobile">
// // //         <div className="req-header-mobile-bar">
// // //           <div className="req-header-mobile-inner">
// // //             <a href="#" className="req-logo">
// // //               JOB PORTAL
// // //             </a>
// // //             <button
// // //               className="req-hamburger"
// // //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// // //             >
// // //               ☰
// // //             </button>
// // //           </div>
// // //         </div>
// // //         <nav className={`req-navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// // //           <ul className="req-mobile-nav-list">
// // //             <li>
// // //               <a href="#" className="req-nav-link">
// // //                 📊 Dashboard
// // //               </a>
// // //             </li>
// // //             <li>
// // //               <a href="#" className="req-nav-link">
// // //                 📄 Pages
// // //               </a>
// // //             </li>
// // //             <li>
// // //               <button
// // //                 onClick={handleLogout}
// // //                 className="req-nav-link"
// // //                 style={{
// // //                   background: "none",
// // //                   border: "none",
// // //                   width: "100%",
// // //                   textAlign: "left",
// // //                   cursor: "pointer",
// // //                 }}
// // //               >
// // //                 🚪 Logout
// // //               </button>
// // //             </li>
// // //           </ul>
// // //         </nav>
// // //       </header>

// // //       {/* Desktop Sidebar */}
// // //       <aside className="req-menu-sidebar">
// // //         <div className="req-sidebar-logo">
// // //           <a href="#" className="req-logo">
// // //             JOB PORTAL
// // //           </a>
// // //         </div>
// // //         <nav className="req-sidebar-content">
// // //           <ul className="req-navbar-list">
// // //             <li className="req-nav-item">
// // //               <a href="#" className="req-nav-link active">
// // //                 📊 Dashboard
// // //               </a>
// // //             </li>
// // //             <li className="req-nav-item">
// // //               <a href="#" className="req-nav-link">
// // //                 📄 Pages
// // //               </a>
// // //             </li>
// // //           </ul>
// // //         </nav>
// // //       </aside>

// // //       {/* Page Container */}
// // //       <div className="req-page-container">
// // //         {/* Desktop Header */}
// // //         <header className="req-header-desktop">
// // //           <div className="req-header-wrap">
// // //             <div className="req-search-form">
// // //               <input
// // //                 type="text"
// // //                 placeholder="Search for datas & reports..."
// // //                 className="req-search-input"
// // //               />
// // //               <button className="req-search-button">🔍</button>
// // //             </div>
// // //             <div className="req-account-wrap">
// // //               <div
// // //                 className="req-account-item"
// // //                 style={{ position: "relative" }}
// // //               >
// // //                 <img
// // //                   className="req-avatar"
// // //                   src={
// // //                     recruiterProfile?.avatar ||
// // //                     "https://randomuser.me/api/portraits/men/75.jpg"
// // //                   }
// // //                   alt="Profile"
// // //                   onClick={() => setIsProfileOpen((prev) => !prev)}
// // //                   style={{ cursor: "pointer" }}
// // //                 />
// // //                 <a
// // //                   href="#"
// // //                   className="req-user-name"
// // //                   onClick={(e) => {
// // //                     e.preventDefault();
// // //                     setIsProfileOpen((prev) => !prev);
// // //                   }}
// // //                 >
// // //                   {recruiterName || "Recruiter"}
// // //                 </a>

// // //                 {/* Profile Dropdown */}
// // //                 {isProfileOpen && (
// // //                   <div
// // //                     style={{
// // //                       position: "absolute",
// // //                       top: "45px",
// // //                       right: 0,
// // //                       background: "#fff",
// // //                       boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
// // //                       borderRadius: "6px",
// // //                       minWidth: "260px",
// // //                       zIndex: 100,
// // //                     }}
// // //                   >
// // //                     {recruiterProfile && (
// // //                       <div
// // //                         style={{
// // //                           padding: "12px 16px",
// // //                           borderBottom: "1px solid #eee",
// // //                         }}
// // //                       >
// // //                         <strong>
// // //                           {recruiterProfile.firstName}{" "}
// // //                           {recruiterProfile.lastName}
// // //                         </strong>
// // //                         <div
// // //                           style={{
// // //                             fontSize: "13px",
// // //                             color: "#888",
// // //                             marginTop: "4px",
// // //                           }}
// // //                         >
// // //                           {recruiterProfile.email}
// // //                         </div>
// // //                       </div>
// // //                     )}
// // //                     {employerProfile && (
// // //                       <div
// // //                         style={{
// // //                           padding: "12px 16px",
// // //                           borderBottom: "1px solid #eee",
// // //                         }}
// // //                       >
// // //                         <p>
// // //                           <strong>🏢 {employerProfile.companyName}</strong>
// // //                         </p>
// // //                         <p style={{ fontSize: "13px" }}>
// // //                           📍 {employerProfile.address}, {employerProfile.city},{" "}
// // //                           {employerProfile.state}, {employerProfile.country}
// // //                         </p>
// // //                         <p style={{ fontSize: "13px" }}>
// // //                           📞 {employerProfile.phone}
// // //                         </p>
// // //                         <p style={{ fontSize: "13px" }}>
// // //                           🌐 {employerProfile.website}
// // //                         </p>
// // //                         <p style={{ fontSize: "13px" }}>
// // //                           🏭 {employerProfile.industry} | 👥{" "}
// // //                           {employerProfile.companySize}
// // //                         </p>
// // //                         <p style={{ fontSize: "13px" }}>
// // //                           ✉️ {employerProfile.email}
// // //                         </p>
// // //                         <p style={{ fontSize: "13px" }}>
// // //                           🔗 {employerProfile.linkedin}
// // //                         </p>
// // //                         <p style={{ fontSize: "13px" }}>
// // //                           📝 {employerProfile.description}
// // //                         </p>
// // //                       </div>
// // //                     )}
// // //                     <button
// // //                       onClick={() => {
// // //                         setEditData(employerProfile);
// // //                         setIsEditOpen(true);
// // //                       }}
// // //                       style={{
// // //                         width: "100%",
// // //                         background: "none",
// // //                         border: "none",
// // //                         color: "#3498db",
// // //                         padding: "12px 16px",
// // //                         textAlign: "left",
// // //                         cursor: "pointer",
// // //                         fontWeight: "bold",
// // //                         borderTop: "1px solid #eee",
// // //                       }}
// // //                     >
// // //                       ✏️ Edit Profile
// // //                     </button>

// // //                     <button
// // //                       onClick={handleLogout}
// // //                       style={{
// // //                         width: "100%",
// // //                         background: "none",
// // //                         border: "none",
// // //                         color: "#e74c3c",
// // //                         padding: "12px 16px",
// // //                         textAlign: "left",
// // //                         cursor: "pointer",
// // //                         fontWeight: "bold",
// // //                         borderRadius: "0 0 6px 6px",
// // //                       }}
// // //                     >
// // //                       Logout
// // //                     </button>
// // //                   </div>
// // //                 )}
// // //               </div>
// // //             </div>
// // //           </div>
// // //         </header>

// // //         {/* Main Content */}
// // //         {/* <div className="req-main-content">
// // //           <h2 className="req-welcome-title">
// // //             Welcome Recruiter{recruiterName ? ` (${recruiterName})` : ""}..!
// // //           </h2>
          
// // //         </div> */}


// // // {applications.map((app) => (
// // //   <div
// // //     key={app._id}
// // //     style={{
// // //       border: "1px solid #ddd",
// // //       padding: "15px",
// // //       marginBottom: "15px",
// // //       borderRadius: "6px",
// // //       background: "#f9f9f9",
// // //     }}
// // //   >
// // //     <h4>👤 {app.name}</h4>
// // //     <p>✉️ <strong>Email:</strong> {app.email}</p>

// // //     {app.portfolio && (
// // //       <p>
// // //         🌐 <strong>Portfolio:</strong>{" "}
// // //         <a href={app.portfolio} target="_blank" rel="noreferrer" style={{ color: "blue" }}>
// // //           {app.portfolio}
// // //         </a>
// // //       </p>
// // //     )}

// // //     <p>📝 <strong>Cover Letter:</strong> {app.coverLetter}</p>

// // //     {app.resume && (
// // //       <p>
// // //         📄 <a href={`http://localhost:5000${app.resume}`} target="_blank" rel="noreferrer">
// // //           Download Resume
// // //         </a>
// // //       </p>
// // //     )}

// // //     <small>📅 Applied on: {new Date(app.createdAt).toLocaleString()}</small>

// // //     <div style={{ marginTop: "10px" }}>
// // //       {app.status === "pending" ? (
// // //         <>
// // //           <button
// // //             onClick={() => {
// // //               const date = prompt("Enter interview date & time (YYYY-MM-DD HH:mm)");
// // //               const link = prompt("Enter Meet/Zoom link");

// // //               fetch(`http://localhost:5000/api/applications/${app._id}/approve`, {
// // //                 method: "POST",
// // //                 headers: { "Content-Type": "application/json" },
// // //                 body: JSON.stringify({ date, meetingLink: link }),
// // //               })
// // //                 .then((res) => res.json())
// // //                 .then((data) => {
// // //                   alert(data.message);
// // //                   // frontend state update
// // //                   app.status = "approved";
// // //                 });
// // //             }}
// // //             style={{ marginRight: "10px", background: "green", color: "white", padding: "6px 12px" }}
// // //           >
// // //             ✅ Approve
// // //           </button>

// // //           <button
// // //             onClick={() => {
// // //               fetch(`http://localhost:5000/api/applications/${app._id}/reject`, {
// // //                 method: "POST",
// // //               })
// // //                 .then((res) => res.json())
// // //                 .then((data) => {
// // //                   alert(data.message);
// // //                   app.status = "rejected";
// // //                 });
// // //             }}
// // //             style={{ background: "red", color: "white", padding: "6px 12px" }}
// // //           >
// // //             ❌ Reject
// // //           </button>
// // //         </>
// // //       ) : (
// // //         <p>
// // //           <strong>Status:</strong>{" "}
// // //           {app.status === "approved" ? "✅ Approved" : "❌ Rejected"}
// // //         </p>
// // //       )}
// // //     </div>
// // //   </div>
// // // ))}

// // //         {/* Edit Profile Modal */}
// // //         {isEditOpen && (
// // //           <div
// // //             style={{
// // //               position: "fixed",
// // //               top: 0,
// // //               left: 0,
// // //               right: 0,
// // //               bottom: 0,
// // //               background: "rgba(0,0,0,0.5)",
// // //               display: "flex",
// // //               justifyContent: "center",
// // //               alignItems: "center",
// // //               zIndex: 200,
// // //               overflow: "auto",
// // //             }}
// // //           >
// // //             <div
// // //               style={{
// // //                 background: "#fff",
// // //                 padding: "20px",
// // //                 borderRadius: "8px",
// // //                 width: "500px",
// // //                 maxHeight: "90vh",
// // //                 overflowY: "auto",
// // //               }}
// // //             >
// // //               <h3>Edit Employer Profile</h3>

// // //               {profileFields.map(({ key, label }) => (
// // //                 <div key={key} style={{ marginBottom: "12px" }}>
// // //                   <label
// // //                     style={{
// // //                       display: "block",
// // //                       fontWeight: "bold",
// // //                       marginBottom: "5px",
// // //                     }}
// // //                   >
// // //                     {label}
// // //                   </label>
// // //                   <input
// // //                     type="text"
// // //                     value={editData?.[key] || ""}
// // //                     onChange={(e) =>
// // //                       setEditData({ ...editData, [key]: e.target.value })
// // //                     }
// // //                     placeholder={label}
// // //                     style={{
// // //                       width: "100%",
// // //                       padding: "8px",
// // //                       border: "1px solid #ccc",
// // //                       borderRadius: "4px",
// // //                     }}
// // //                   />
// // //                 </div>
// // //               ))}

// // //               <button
// // //                 onClick={handleSaveProfile}
// // //                 style={{
// // //                   background: "#27ae60",
// // //                   color: "#fff",
// // //                   padding: "10px",
// // //                   width: "100%",
// // //                   marginTop: "10px",
// // //                   border: "none",
// // //                   borderRadius: "4px",
// // //                 }}
// // //               >
// // //                 Save Changes
// // //               </button>
// // //               <button
// // //                 onClick={() => setIsEditOpen(false)}
// // //                 style={{
// // //                   background: "#e74c3c",
// // //                   color: "#fff",
// // //                   padding: "10px",
// // //                   width: "100%",
// // //                   marginTop: "10px",
// // //                   border: "none",
// // //                   borderRadius: "4px",
// // //                 }}
// // //               >
// // //                 Cancel
// // //               </button>
// // //             </div>
// // //           </div>
// // //         )}
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default Req_Dashboard;
// // import React, { useState, useEffect } from "react";
// // import "./Req_Dashboard.css";

// // const Req_Dashboard = () => {
// //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
// //   const [isProfileOpen, setIsProfileOpen] = useState(false);
// //   const [recruiterName, setRecruiterName] = useState("");
// //   const [recruiterProfile, setRecruiterProfile] = useState(null);
// //   const [employerProfile, setEmployerProfile] = useState(null);
// //   const [isEditOpen, setIsEditOpen] = useState(false);
// //   const [editData, setEditData] = useState({});
// //   const [applications, setApplications] = useState([]);
// //   const [loading, setLoading] = useState(true);

// //   const handleLogout = () => {
// //     localStorage.removeItem("user");
// //     window.location.href = "/";
// //   };

// //   useEffect(() => {
// //     const storedUser = JSON.parse(localStorage.getItem("user"));
// //     if (storedUser && storedUser.id) {
// //       fetch(`http://localhost:5000/api/applications/by-user/${storedUser.id}`)
// //         .then((res) => res.json())
// //         .then((data) => {
// //           if (data.success) setApplications(data.applications);
// //           setLoading(false);
// //         })
// //         .catch((err) => {
// //           console.error("Error fetching applications:", err);
// //           setLoading(false);
// //         });
// //     }
// //   }, []);

// //   useEffect(() => {
// //     const storedUser = JSON.parse(localStorage.getItem("user"));
// //     if (storedUser) {
// //       const fullName = storedUser.firstName
// //         ? `${storedUser.firstName} ${storedUser.lastName || ""}`
// //         : storedUser.name || "";
// //       setRecruiterName(fullName);
// //       setRecruiterProfile(storedUser);

// //       // Fetch employer profile
// //       fetch(`http://localhost:5000/api/profile/employer/${storedUser.id}`)
// //         .then((res) => res.json())
// //         .then((data) => {
// //           if (data.success) setEmployerProfile(data.profile);
// //         })
// //         .catch((err) => console.error(err));
// //     }
// //   }, []);

// //   const handleSaveProfile = async () => {
// //     try {
// //       const res = await fetch(
// //         `http://localhost:5000/api/profile/employer/${recruiterProfile.id}`,
// //         {
// //           method: "PUT",
// //           headers: { "Content-Type": "application/json" },
// //           body: JSON.stringify(editData),
// //         }
// //       );
// //       const data = await res.json();
// //       if (data.success) {
// //         setEmployerProfile(data.profile);
// //         setIsEditOpen(false);
// //       } else {
// //         alert("Error updating profile: " + data.message);
// //       }
// //     } catch (err) {
// //       console.error(err);
// //       alert("❌ Failed to update profile");
// //     }
// //   };

// //   const handleApprove = (app) => {
// //     const date = prompt("Enter interview date & time (YYYY-MM-DD HH:mm)");
// //     const link = prompt("Enter Meet/Zoom link");

// //     if (date && link) {
// //       fetch(`http://localhost:5000/api/applications/${app._id}/approve`, {
// //         method: "POST",
// //         headers: { "Content-Type": "application/json" },
// //         body: JSON.stringify({ date, meetingLink: link }),
// //       })
// //         .then((res) => res.json())
// //         .then((data) => {
// //           alert(data.message);
// //           setApplications(prev => 
// //             prev.map(a => a._id === app._id ? { ...a, status: "approved" } : a)
// //           );
// //         })
// //         .catch(err => console.error(err));
// //     }
// //   };

// //   const handleReject = (app) => {
// //     if (window.confirm("Are you sure you want to reject this application?")) {
// //       fetch(`http://localhost:5000/api/applications/${app._id}/reject`, {
// //         method: "POST",
// //       })
// //         .then((res) => res.json())
// //         .then((data) => {
// //           alert(data.message);
// //           setApplications(prev => 
// //             prev.map(a => a._id === app._id ? { ...a, status: "rejected" } : a)
// //           );
// //         })
// //         .catch(err => console.error(err));
// //     }
// //   };

// //   // Field labels
// //   const profileFields = [
// //     { key: "companyName", label: "🏢 Company Name" },
// //     { key: "website", label: "🌐 Website" },
// //     { key: "industry", label: "🏭 Industry" },
// //     { key: "companySize", label: "👥 Company Size" },
// //     { key: "phone", label: "📞 Phone" },
// //     { key: "email", label: "✉️ Email" },
// //     { key: "address", label: "📍 Address" },
// //     { key: "city", label: "🏙️ City" },
// //     { key: "state", label: "🗺️ State" },
// //     { key: "country", label: "🌎 Country" },
// //     { key: "linkedin", label: "🔗 LinkedIn" },
// //     { key: "logo", label: "🖼️ Logo URL" },
// //     { key: "description", label: "📝 Description" },
// //   ];

// //   return (
// //     <div className="req-page-wrapper">
// //       {/* Enhanced Inline Styles */}
// //       <style jsx>{`
// //         .req-page-wrapper {
// //           font-family: 'Inter', 'Segoe UI', sans-serif;
// //           background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
// //           min-height: 100vh;
// //           position: relative;
// //         }

// //         .req-page-wrapper::before {
// //           content: '';
// //           position: absolute;
// //           top: 0;
// //           left: 0;
// //           right: 0;
// //           bottom: 0;
// //           background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
// //           pointer-events: none;
// //         }

// //         .req-header-mobile {
// //           display: none;
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(10px);
// //           box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
// //           position: sticky;
// //           top: 0;
// //           z-index: 1000;
// //         }

// //         .req-header-mobile-bar {
// //           padding: 1rem;
// //         }

// //         .req-header-mobile-inner {
// //           display: flex;
// //           justify-content: space-between;
// //           align-items: center;
// //         }

// //         .req-logo {
// //           font-size: 1.5rem;
// //           font-weight: 800;
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //           -webkit-background-clip: text;
// //           -webkit-text-fill-color: transparent;
// //           text-decoration: none;
// //           letter-spacing: -0.5px;
// //         }

// //         .req-hamburger {
// //           background: none;
// //           border: none;
// //           font-size: 1.5rem;
// //           cursor: pointer;
// //           color: #667eea;
// //           transition: transform 0.3s ease;
// //         }

// //         .req-hamburger:hover {
// //           transform: scale(1.1);
// //         }

// //         .req-navbar-mobile {
// //           max-height: 0;
// //           overflow: hidden;
// //           transition: max-height 0.3s ease;
// //           background: rgba(255, 255, 255, 0.95);
// //         }

// //         .req-navbar-mobile.open {
// //           max-height: 300px;
// //         }

// //         .req-mobile-nav-list {
// //           list-style: none;
// //           padding: 0;
// //           margin: 0;
// //         }

// //         .req-mobile-nav-list li {
// //           border-bottom: 1px solid rgba(0, 0, 0, 0.1);
// //         }

// //         .req-nav-link {
// //           display: block;
// //           padding: 1rem;
// //           color: #333;
// //           text-decoration: none;
// //           transition: all 0.3s ease;
// //           font-weight: 500;
// //         }

// //         .req-nav-link:hover {
// //           background: rgba(102, 126, 234, 0.1);
// //           color: #667eea;
// //           transform: translateX(5px);
// //         }

// //         .req-menu-sidebar {
// //           width: 280px;
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(20px);
// //           height: 100vh;
// //           position: fixed;
// //           left: 0;
// //           top: 0;
// //           z-index: 1000;
// //           box-shadow: 0 0 50px rgba(0, 0, 0, 0.1);
// //           border-right: 1px solid rgba(255, 255, 255, 0.2);
// //         }

// //         .req-sidebar-logo {
// //           padding: 2rem 1.5rem;
// //           border-bottom: 1px solid rgba(0, 0, 0, 0.1);
// //           text-align: center;
// //         }

// //         .req-sidebar-content {
// //           padding: 2rem 0;
// //         }

// //         .req-navbar-list {
// //           list-style: none;
// //           padding: 0;
// //           margin: 0;
// //         }

// //         .req-nav-item {
// //           margin-bottom: 0.5rem;
// //         }

// //         .req-nav-link.active {
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //           color: white;
// //           margin: 0 1rem;
// //           border-radius: 10px;
// //           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
// //         }

// //         .req-page-container {
// //           margin-left: 280px;
// //           min-height: 100vh;
// //           position: relative;
// //           z-index: 1;
// //         }

// //         .req-header-desktop {
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(10px);
// //           padding: 1.5rem 2rem;
// //           box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
// //           position: sticky;
// //           top: 0;
// //           z-index: 999;
// //         }

// //         .req-header-wrap {
// //           display: flex;
// //           justify-content: space-between;
// //           align-items: center;
// //         }

// //         .req-search-form {
// //           display: flex;
// //           align-items: center;
// //           background: white;
// //           border-radius: 25px;
// //           padding: 0.5rem 1rem;
// //           box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
// //           transition: all 0.3s ease;
// //           border: 2px solid transparent;
// //         }

// //         .req-search-form:focus-within {
// //           border-color: #667eea;
// //           box-shadow: 0 4px 20px rgba(102, 126, 234, 0.2);
// //         }

// //         .req-search-input {
// //           border: none;
// //           outline: none;
// //           padding: 0.5rem;
// //           width: 300px;
// //           font-size: 0.9rem;
// //         }

// //         .req-search-button {
// //           background: none;
// //           border: none;
// //           cursor: pointer;
// //           font-size: 1rem;
// //           color: #667eea;
// //         }

// //         .req-account-wrap {
// //           display: flex;
// //           align-items: center;
// //         }

// //         .req-account-item {
// //           display: flex;
// //           align-items: center;
// //           gap: 0.75rem;
// //           cursor: pointer;
// //           padding: 0.5rem 1rem;
// //           border-radius: 25px;
// //           transition: all 0.3s ease;
// //         }

// //         .req-account-item:hover {
// //           background: rgba(102, 126, 234, 0.1);
// //         }

// //         .req-avatar {
// //           width: 45px;
// //           height: 45px;
// //           border-radius: 50%;
// //           object-fit: cover;
// //           border: 3px solid #667eea;
// //           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
// //         }

// //         .req-user-name {
// //           font-weight: 600;
// //           color: #333;
// //           text-decoration: none;
// //         }

// //         .profile-dropdown {
// //           position: absolute;
// //           top: 60px;
// //           right: 0;
// //           background: white;
// //           border-radius: 15px;
// //           box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
// //           min-width: 320px;
// //           overflow: hidden;
// //           z-index: 1000;
// //           animation: slideDown 0.3s ease-out;
// //           border: 1px solid rgba(102, 126, 234, 0.1);
// //         }

// //         @keyframes slideDown {
// //           from {
// //             opacity: 0;
// //             transform: translateY(-10px);
// //           }
// //           to {
// //             opacity: 1;
// //             transform: translateY(0);
// //           }
// //         }

// //         .profile-header {
// //           background: linear-gradient(135deg, #667eea, #764ba2);
// //           color: white;
// //           padding: 1.5rem;
// //           text-align: center;
// //         }

// //         .profile-info {
// //           padding: 1.5rem;
// //           max-height: 300px;
// //           overflow-y: auto;
// //         }

// //         .profile-info p {
// //           margin: 0.5rem 0;
// //           font-size: 0.9rem;
// //           line-height: 1.5;
// //         }

// //         .profile-actions {
// //           border-top: 1px solid #f0f0f0;
// //         }

// //         .profile-action-btn {
// //           width: 100%;
// //           padding: 1rem 1.5rem;
// //           border: none;
// //           background: none;
// //           text-align: left;
// //           cursor: pointer;
// //           font-weight: 600;
// //           transition: all 0.3s ease;
// //           display: flex;
// //           align-items: center;
// //           gap: 0.75rem;
// //         }

// //         .profile-action-btn:hover {
// //           background: rgba(102, 126, 234, 0.05);
// //           transform: translateX(5px);
// //         }

// //         .profile-action-btn.edit {
// //           color: #3498db;
// //         }

// //         .profile-action-btn.logout {
// //           color: #e74c3c;
// //           border-top: 1px solid #f0f0f0;
// //         }

// //         .applications-container {
// //           padding: 2rem;
// //         }

// //         .applications-header {
// //           text-align: center;
// //           margin-bottom: 3rem;
// //         }

// //         .applications-title {
// //           font-size: 2.5rem;
// //           font-weight: 800;
// //           background: linear-gradient(45deg, #ffffffff, #ffffffff);
// //           -webkit-background-clip: text;
// //           -webkit-text-fill-color: transparent;
// //           margin-bottom: 0.5rem;
// //         }

// //         .applications-subtitle {
// //           color: rgba(255, 255, 255, 0.8);
// //           font-size: 1.1rem;
// //         }

// //         .applications-grid {
// //           display: grid;
// //           gap: 2rem;
// //           max-width: 1200px;
// //           margin: 0 auto;
// //         }

// //         .application-card {
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(10px);
// //           border-radius: 20px;
// //           padding: 2rem;
// //           box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
// //           border: 1px solid rgba(255, 255, 255, 0.2);
// //           transition: all 0.3s ease;
// //           position: relative;
// //           overflow: hidden;
// //         }

// //         .application-card::before {
// //           content: '';
// //           position: absolute;
// //           top: 0;
// //           left: 0;
// //           right: 0;
// //           height: 4px;
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //         }

// //         .application-card:hover {
// //           transform: translateY(-5px);
// //           box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
// //         }

// //         .application-header {
// //           display: flex;
// //           align-items: center;
// //           margin-bottom: 1.5rem;
// //         }

// //         .applicant-avatar {
// //           width: 60px;
// //           height: 60px;
// //           border-radius: 50%;
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //           display: flex;
// //           align-items: center;
// //           justify-content: center;
// //           color: white;
// //           font-size: 1.5rem;
// //           font-weight: bold;
// //           margin-right: 1rem;
// //         }

// //         .applicant-name {
// //           font-size: 1.5rem;
// //           font-weight: 700;
// //           color: #333;
// //           margin: 0;
// //         }

// //         .application-details {
// //           margin-bottom: 2rem;
// //         }

// //         .detail-row {
// //           display: flex;
// //           align-items: flex-start;
// //           margin-bottom: 1rem;
// //           padding: 0.75rem;
// //           background: rgba(102, 126, 234, 0.05);
// //           border-radius: 10px;
// //           border-left: 4px solid #667eea;
// //         }

// //         .detail-label {
// //           font-weight: 600;
// //           color: #667eea;
// //           min-width: 100px;
// //           margin-right: 1rem;
// //         }

// //         .detail-value {
// //           flex: 1;
// //           color: #555;
// //           line-height: 1.6;
// //         }

// //         .detail-link {
// //           color: #667eea;
// //           text-decoration: none;
// //           font-weight: 500;
// //           transition: color 0.3s ease;
// //         }

// //         .detail-link:hover {
// //           color: #764ba2;
// //           text-decoration: underline;
// //         }

// //         .application-footer {
// //           display: flex;
// //           justify-content: space-between;
// //           align-items: center;
// //           padding-top: 1.5rem;
// //           border-top: 1px solid #f0f0f0;
// //         }

// //         .application-date {
// //           color: #888;
// //           font-size: 0.9rem;
// //         }

// //         .application-actions {
// //           display: flex;
// //           gap: 1rem;
// //         }

// //         .action-btn {
// //           padding: 0.75rem 1.5rem;
// //           border: none;
// //           border-radius: 25px;
// //           font-weight: 600;
// //           cursor: pointer;
// //           transition: all 0.3s ease;
// //           font-size: 0.9rem;
// //         }

// //         .approve-btn {
// //           background: linear-gradient(45deg, #2ecc71, #27ae60);
// //           color: white;
// //           box-shadow: 0 4px 15px rgba(46, 204, 113, 0.4);
// //         }

// //         .approve-btn:hover {
// //           transform: translateY(-2px);
// //           box-shadow: 0 6px 20px rgba(46, 204, 113, 0.6);
// //         }

// //         .reject-btn {
// //           background: linear-gradient(45deg, #e74c3c, #c0392b);
// //           color: white;
// //           box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);
// //         }

// //         .reject-btn:hover {
// //           transform: translateY(-2px);
// //           box-shadow: 0 6px 20px rgba(231, 76, 60, 0.6);
// //         }

// //         .status-badge {
// //           padding: 0.5rem 1rem;
// //           border-radius: 20px;
// //           font-weight: 600;
// //           font-size: 0.9rem;
// //         }

// //         .status-approved {
// //           background: rgba(46, 204, 113, 0.1);
// //           color: #27ae60;
// //           border: 2px solid rgba(46, 204, 113, 0.3);
// //         }

// //         .status-rejected {
// //           background: rgba(231, 76, 60, 0.1);
// //           color: #c0392b;
// //           border: 2px solid rgba(231, 76, 60, 0.3);
// //         }

// //         .modal-overlay {
// //           position: fixed;
// //           top: 0;
// //           left: 0;
// //           right: 0;
// //           bottom: 0;
// //           background: rgba(0, 0, 0, 0.7);
// //           display: flex;
// //           justify-content: center;
// //           align-items: center;
// //           z-index: 2000;
// //           backdrop-filter: blur(5px);
// //         }

// //         .modal-content {
// //           background: white;
// //           border-radius: 20px;
// //           padding: 2rem;
// //           width: 90%;
// //           max-width: 600px;
// //           max-height: 90vh;
// //           overflow-y: auto;
// //           box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
// //           animation: modalSlideIn 0.3s ease-out;
// //         }

// //         @keyframes modalSlideIn {
// //           from {
// //             opacity: 0;
// //             transform: scale(0.9);
// //           }
// //           to {
// //             opacity: 1;
// //             transform: scale(1);
// //           }
// //         }

// //         .modal-header {
// //           text-align: center;
// //           margin-bottom: 2rem;
// //         }

// //         .modal-title {
// //           font-size: 1.8rem;
// //           font-weight: 700;
// //           color: #333;
// //           margin-bottom: 0.5rem;
// //         }

// //         .form-group {
// //           margin-bottom: 1.5rem;
// //         }

// //         .form-label {
// //           display: block;
// //           font-weight: 600;
// //           color: #333;
// //           margin-bottom: 0.5rem;
// //         }

// //         .form-input {
// //           width: 100%;
// //           padding: 0.75rem 1rem;
// //           border: 2px solid #e0e0e0;
// //           border-radius: 10px;
// //           font-size: 0.9rem;
// //           transition: all 0.3s ease;
// //           background: white;
// //         }

// //         .form-input:focus {
// //           border-color: #667eea;
// //           box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
// //           outline: none;
// //         }

// //         .modal-actions {
// //           display: flex;
// //           gap: 1rem;
// //           margin-top: 2rem;
// //         }

// //         .modal-btn {
// //           flex: 1;
// //           padding: 0.75rem;
// //           border: none;
// //           border-radius: 10px;
// //           font-weight: 600;
// //           cursor: pointer;
// //           transition: all 0.3s ease;
// //         }

// //         .save-btn {
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //           color: white;
// //         }

// //         .save-btn:hover {
// //           transform: translateY(-2px);
// //           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
// //         }

// //         .cancel-btn {
// //           background: #f8f9fa;
// //           color: #666;
// //           border: 2px solid #e0e0e0;
// //         }

// //         .cancel-btn:hover {
// //           background: #e9ecef;
// //           border-color: #ccc;
// //         }

// //         .loading-spinner {
// //           display: flex;
// //           justify-content: center;
// //           align-items: center;
// //           height: 200px;
// //           font-size: 1.1rem;
// //           color: rgba(255, 255, 255, 0.8);
// //         }

// //         .empty-state {
// //           text-align: center;
// //           padding: 4rem 2rem;
// //           color: rgba(255, 255, 255, 0.8);
// //         }

// //         .empty-state-icon {
// //           font-size: 4rem;
// //           margin-bottom: 1rem;
// //         }

// //         .empty-state-title {
// //           font-size: 1.5rem;
// //           font-weight: 600;
// //           margin-bottom: 0.5rem;
// //         }

// //         .empty-state-subtitle {
// //           font-size: 1rem;
// //         }

// //         @media (max-width: 768px) {
// //           .req-header-mobile {
// //             display: block;
// //           }

// //           .req-menu-sidebar {
// //             display: none;
// //           }

// //           .req-page-container {
// //             margin-left: 0;
// //           }

// //           .req-header-desktop {
// //             display: none;
// //           }

// //           .applications-container {
// //             padding: 1rem;
// //           }

// //           .applications-title {
// //             font-size: 2rem;
// //             color: white;
            
// //           }

// //           .application-card {
// //             padding: 1.5rem;
// //           }

// //           .application-actions {
// //             flex-direction: column;
// //           }

// //           .action-btn {
// //             width: 100%;
// //           }

// //           .modal-content {
// //             width: 95%;
// //             margin: 1rem;
// //           }
// //         }
// //       `}</style>

// //       {/* Mobile Header */}
// //       <header className="req-header-mobile">
// //         <div className="req-header-mobile-bar">
// //           <div className="req-header-mobile-inner">
// //             <a href="#" className="req-logo">
// //               JOB PORTAL
// //             </a>
// //             <button
// //               className="req-hamburger"
// //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// //             >
// //               ☰
// //             </button>
// //           </div>
// //         </div>
// //         <nav className={`req-navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// //           <ul className="req-mobile-nav-list">
// //             <li>
// //               <a href="#" className="req-nav-link">
// //                 📊 Dashboard
// //               </a>
// //             </li>
// //             <li>
// //               <a href="#" className="req-nav-link">
// //                 📄 Pages
// //               </a>
// //             </li>
// //             <li>
// //               <button
// //                 onClick={handleLogout}
// //                 className="req-nav-link"
// //                 style={{
// //                   background: "none",
// //                   border: "none",
// //                   width: "100%",
// //                   textAlign: "left",
// //                   cursor: "pointer",
// //                 }}
// //               >
// //                 🚪 Logout
// //               </button>
// //             </li>
// //           </ul>
// //         </nav>
// //       </header>

// //       {/* Desktop Sidebar */}
// //       <aside className="req-menu-sidebar">
// //         <div className="req-sidebar-logo">
// //           <a href="#" className="req-logo">
// //             JOB PORTAL
// //           </a>
// //         </div>
// //         <nav className="req-sidebar-content">
// //           <ul className="req-navbar-list">
// //             {/* <li className="req-nav-item">
// //               <a href="#" className="req-nav-link active">
// //                 📊 Dashboard
// //               </a>
// //             </li> */}
// //             <li className="req-nav-item">
// //               <a href="#" className="req-nav-link">
// //                 📊 Dashboard
// //               </a>
// //             </li>
// //           </ul>
// //         </nav>
// //       </aside>

// //       {/* Page Container */}
// //       <div className="req-page-container">
// //         {/* Desktop Header */}
// //         <header className="req-header-desktop">
// //           <div className="req-header-wrap">
// //             <div className="req-search-form">
// //               <input
// //                 type="text"
// //                 placeholder="Search for applications & reports..."
// //                 className="req-search-input"
// //               />
// //               <button className="req-search-button">🔍</button>
// //             </div>
// //             <div className="req-account-wrap">
// //               <div
// //                 className="req-account-item"
// //                 style={{ position: "relative" }}
// //               >
// //                 <img
// //                   className="req-avatar"
// //                   src={
// //                     recruiterProfile?.avatar ||
// //                     "https://randomuser.me/api/portraits/men/75.jpg"
// //                   }
// //                   alt="Profile"
// //                   onClick={() => setIsProfileOpen((prev) => !prev)}
// //                   style={{ cursor: "pointer" }}
// //                 />
// //                 <a
// //                   href="#"
// //                   className="req-user-name"
// //                   onClick={(e) => {
// //                     e.preventDefault();
// //                     setIsProfileOpen((prev) => !prev);
// //                   }}
// //                 >
// //                   {recruiterName || "Recruiter"}
// //                 </a>

// //                 {/* Enhanced Profile Dropdown */}
// //                 {isProfileOpen && (
// //                   <>
// //                     <div
// //                       style={{
// //                         position: "fixed",
// //                         top: 0,
// //                         left: 0,
// //                         width: "100vw",
// //                         height: "100vh",
// //                         background: "transparent",
// //                         zIndex: 999
// //                       }}
// //                       onClick={() => setIsProfileOpen(false)}
// //                     />
// //                     <div className="profile-dropdown">
// //                       {recruiterProfile && (
// //                         <div className="profile-header">
// //                           <strong>
// //                             {recruiterProfile.firstName}{" "}
// //                             {recruiterProfile.lastName}
// //                           </strong>
// //                           <div style={{ opacity: 0.9, marginTop: "0.5rem" }}>
// //                             {recruiterProfile.email}
// //                           </div>
// //                         </div>
// //                       )}
                      
// //                       {employerProfile ? (
// //                         <div className="profile-info">
// //                           <div className="detail-row">
// //                             <span className="detail-label">🏢</span>
// //                             <strong>{employerProfile.companyName}</strong>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">📍</span>
// //                             <span>{employerProfile.address}, {employerProfile.city}, {employerProfile.state}, {employerProfile.country}</span>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">📞</span>
// //                             <span>{employerProfile.phone}</span>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">🌐</span>
// //                             <a href={employerProfile.website} target="_blank" rel="noreferrer" className="detail-link">{employerProfile.website}</a>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">🏭</span>
// //                             <span>{employerProfile.industry} | 👥 {employerProfile.companySize}</span>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">🔗</span>
// //                             <a href={employerProfile.linkedin} target="_blank" rel="noreferrer" className="detail-link">LinkedIn</a>
// //                           </div>
// //                           {employerProfile.description && (
// //                             <div className="detail-row">
// //                               <span className="detail-label">📝</span>
// //                               <span>{employerProfile.description}</span>
// //                             </div>
// //                           )}
// //                         </div>
// //                       ) : (
// //                         <div className="profile-info">
// //                           <div style={{ 
// //                             textAlign: "center", 
// //                             color: "#888",
// //                             padding: "2rem" 
// //                           }}>
// //                             ⚠️ No employer profile found
// //                             <div style={{ fontSize: "0.9rem", marginTop: "0.5rem" }}>
// //                               Complete your profile to get started
// //                             </div>
// //                           </div>
// //                         </div>
// //                       )}

// //                       <div className="profile-actions">
// //                         <button
// //                           className="profile-action-btn edit"
// //                           onClick={() => {
// //                             setEditData(employerProfile || {});
// //                             setIsEditOpen(true);
// //                             setIsProfileOpen(false);
// //                           }}
// //                         >
// //                           <span>✏️</span>
// //                           Edit Profile
// //                         </button>

// //                         <button
// //                           className="profile-action-btn logout"
// //                           onClick={() => {
// //                             handleLogout();
// //                             setIsProfileOpen(false);
// //                           }}
// //                         >
// //                           <span>🚪</span>
// //                           Logout
// //                         </button>
// //                       </div>
// //                     </div>
// //                   </>
// //                 )}
// //               </div>
// //             </div>
// //           </div>
// //         </header>

// //         {/* Main Content - Applications */}
// //         <div className="applications-container">
// //           <div className="applications-header">
// //             <h1 className="applications-title" >
// //               Welcome back, {recruiterName || "Recruiter"}!
// //             </h1>
// //             <p className="applications-subtitle">
// //               Manage your job applications and find the perfect candidates
// //             </p>
// //           </div>

// //           {loading ? (
// //             <div className="loading-spinner">
// //               <div>🔄 Loading applications...</div>
// //             </div>
// //           ) : applications.length === 0 ? (
// //             <div className="empty-state">
// //               <div className="empty-state-icon">📋</div>
// //               <h3 className="empty-state-title">No Applications Yet</h3>
// //               <p className="empty-state-subtitle">
// //                 Applications for your job posts will appear here
// //               </p>
// //             </div>
// //           ) : (
// //             <div className="applications-grid">
// //               {applications.map((app) => (
// //                 <div key={app._id} className="application-card">
// //                   <div className="application-header">
// //                     <div className="applicant-avatar">
// //                       {app.name ? app.name.charAt(0).toUpperCase() : '👤'}
// //                     </div>
// //                     <div>
// //                       <h3 className="applicant-name">{app.name}</h3>
// //                     </div>
// //                   </div>

// //                   <div className="application-details">
// //                     <div className="detail-row">
// //                       <span className="detail-label">✉️ Email:</span>
// //                       <span className="detail-value">
// //                         <a href={`mailto:${app.email}`} className="detail-link">
// //                           {app.email}
// //                         </a>
// //                       </span>
// //                     </div>

// //                     {app.portfolio && (
// //                       <div className="detail-row">
// //                         <span className="detail-label">🌐 Portfolio:</span>
// //                         <span className="detail-value">
// //                           <a href={app.portfolio} target="_blank" rel="noreferrer" className="detail-link">
// //                             View Portfolio
// //                           </a>
// //                         </span>
// //                       </div>
// //                     )}

// //                     <div className="detail-row">
// //                       <span className="detail-label">📝 Cover Letter:</span>
// //                       <span className="detail-value">{app.coverLetter}</span>
// //                     </div>

// //                     {app.resume && (
// //                       <div className="detail-row">
// //                         <span className="detail-label">📄 Resume:</span>
// //                         <span className="detail-value">
// //                           <a 
// //                             href={`http://localhost:5000${app.resume}`} 
// //                             target="_blank" 
// //                             rel="noreferrer" 
// //                             className="detail-link"
// //                           >
// //                             Download Resume
// //                           </a>
// //                         </span>
// //                       </div>
// //                     )}
// //                   </div>

// //                   <div className="application-footer">
// //                     <div className="application-date">
// //                       📅 Applied on: {new Date(app.createdAt).toLocaleDateString('en-US', {
// //                         year: 'numeric',
// //                         month: 'long',
// //                         day: 'numeric',
// //                         hour: '2-digit',
// //                         minute: '2-digit'
// //                       })}
// //                     </div>

// //                     <div className="application-actions">
// //                       {app.status === "pending" ? (
// //                         <>
// //                           <button
// //                             className="action-btn approve-btn"
// //                             onClick={() => handleApprove(app)}
// //                           >
// //                             ✅ Approve
// //                           </button>
// //                           <button
// //                             className="action-btn reject-btn"
// //                             onClick={() => handleReject(app)}
// //                           >
// //                             ❌ Reject
// //                           </button>
// //                         </>
// //                       ) : (
// //                         <div className={`status-badge ${
// //                           app.status === "approved" ? "status-approved" : "status-rejected"
// //                         }`}>
// //                           {app.status === "approved" ? "✅ Approved" : "❌ Rejected"}
// //                         </div>
// //                       )}
// //                     </div>
// //                   </div>
// //                 </div>
// //               ))}
// //             </div>
// //           )}
// //         </div>

// //         {/* Enhanced Edit Profile Modal */}
// //         {isEditOpen && (
// //           <div className="modal-overlay">
// //             <div className="modal-content">
// //               <div className="modal-header">
// //                 <h3 className="modal-title">✏️ Edit Employer Profile</h3>
                
// //               </div>
// // <p style={{ color: "#666", marginTop: "0.5rem" }}>
// //                   Update your company information to attract better candidates
// //                 </p>
// //               <form onSubmit={(e) => {
// //                 e.preventDefault();
// //                 handleSaveProfile();
// //               }}>
// //                 {profileFields.map(({ key, label }) => (
// //                   <div key={key} className="form-group">
// //                     <label className="form-label">{label}</label>
// //                     {key === 'description' ? (
// //                       <textarea
// //                         className="form-input"
// //                         value={editData?.[key] || ""}
// //                         onChange={(e) =>
// //                           setEditData({ ...editData, [key]: e.target.value })
// //                         }
// //                         placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
// //                         rows="4"
// //                         style={{ resize: 'vertical', minHeight: '100px' }}
// //                       />
// //                     ) : (
// //                       <input
// //                         type={key === 'email' ? 'email' : key === 'website' || key === 'linkedin' ? 'url' : 'text'}
// //                         className="form-input"
// //                         value={editData?.[key] || ""}
// //                         onChange={(e) =>
// //                           setEditData({ ...editData, [key]: e.target.value })
// //                         }
// //                         placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
// //                       />
// //                     )}
// //                   </div>
// //                 ))}

// //                 <div className="modal-actions">
// //                   <button type="submit" className="modal-btn save-btn">
// //                     💾 Save Changes
// //                   </button>
// //                   <button
// //                     type="button"
// //                     onClick={() => setIsEditOpen(false)}
// //                     className="modal-btn cancel-btn"
// //                   >
// //                     ✖️ Cancel
// //                   </button>
// //                 </div>
// //               </form>
// //             </div>
// //           </div>
// //         )}
// //       </div>
// //     </div>
// //   );
// // };

// // export default Req_Dashboard;

// // import React, { useState, useEffect } from "react";
// // import "./Req_Dashboard.css";

// // const Req_Dashboard = () => {
// //   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
// //   const [isProfileOpen, setIsProfileOpen] = useState(false);
// //   const [recruiterName, setRecruiterName] = useState("");
// //   const [recruiterProfile, setRecruiterProfile] = useState(null);
// //   const [employerProfile, setEmployerProfile] = useState(null);
// //   const [isEditOpen, setIsEditOpen] = useState(false);
// //   const [editData, setEditData] = useState({});
// //   const [applications, setApplications] = useState([]);
// //   const [loading, setLoading] = useState(true);
// //   const [statusFilter, setStatusFilter] = useState('all');
// //   const [searchTerm, setSearchTerm] = useState('');

// //   const handleLogout = () => {
// //     localStorage.removeItem("user");
// //     window.location.href = "/";
// //   };

// //   // Fetch applications
// //   useEffect(() => {
// //     const storedUser = JSON.parse(localStorage.getItem("user"));
// //     if (storedUser && storedUser.id) {
// //       fetch(`http://localhost:5000/api/applications/by-user/${storedUser.id}`)
// //         .then((res) => res.json())
// //         .then((data) => {
// //           if (data.success) setApplications(data.applications);
// //           setLoading(false);
// //         })
// //         .catch((err) => {
// //           console.error("Error fetching applications:", err);
// //           setLoading(false);
// //         });
// //     }
// //   }, []);

// //   // Fetch user profile
// //   useEffect(() => {
// //     const storedUser = JSON.parse(localStorage.getItem("user"));
// //     if (storedUser) {
// //       const fullName = storedUser.firstName
// //         ? `${storedUser.firstName} ${storedUser.lastName || ""}`
// //         : storedUser.name || "";
// //       setRecruiterName(fullName);
// //       setRecruiterProfile(storedUser);

// //       // Fetch employer profile
// //       fetch(`http://localhost:5000/api/profile/employer/${storedUser.id}`)
// //         .then((res) => res.json())
// //         .then((data) => {
// //           if (data.success) setEmployerProfile(data.profile);
// //         })
// //         .catch((err) => console.error(err));
// //     }
// //   }, []);

// //   const handleSaveProfile = async () => {
// //     try {
// //       const res = await fetch(
// //         `http://localhost:5000/api/profile/employer/${recruiterProfile.id}`,
// //         {
// //           method: "PUT",
// //           headers: { "Content-Type": "application/json" },
// //           body: JSON.stringify(editData),
// //         }
// //       );
// //       const data = await res.json();
// //       if (data.success) {
// //         setEmployerProfile(data.profile);
// //         setIsEditOpen(false);
// //         // Show success message
// //         showNotification("Profile updated successfully! ✅", "success");
// //       } else {
// //         showNotification("Error updating profile: " + data.message, "error");
// //       }
// //     } catch (err) {
// //       console.error(err);
// //       showNotification("❌ Failed to update profile", "error");
// //     }
// //   };

// //   const handleApprove = (app) => {
// //     const date = prompt("Enter interview date & time (YYYY-MM-DD HH:mm):");
// //     const link = prompt("Enter Meet/Zoom link:");

// //     if (date && link) {
// //       setApplications(prev => 
// //         prev.map(a => a._id === app._id ? { ...a, status: "processing" } : a)
// //       );

// //       fetch(`http://localhost:5000/api/applications/${app._id}/approve`, {
// //         method: "POST",
// //         headers: { "Content-Type": "application/json" },
// //         body: JSON.stringify({ date, meetingLink: link }),
// //       })
// //         .then((res) => res.json())
// //         .then((data) => {
// //           if (data.success) {
// //             setApplications(prev => 
// //               prev.map(a => a._id === app._id ? { 
// //                 ...a, 
// //                 status: "approved", 
// //                 interviewDate: date, 
// //                 meetingLink: link 
// //               } : a)
// //             );
// //             showNotification("Application approved successfully! ✅", "success");
// //           } else {
// //             setApplications(prev => 
// //               prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
// //             );
// //             showNotification("Error: " + data.message, "error");
// //           }
// //         })
// //         .catch(err => {
// //           console.error(err);
// //           setApplications(prev => 
// //             prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
// //           );
// //           showNotification("Failed to approve application ❌", "error");
// //         });
// //     }
// //   };

// //   const handleReject = (app) => {
// //     if (window.confirm("Are you sure you want to reject this application?")) {
// //       setApplications(prev => 
// //         prev.map(a => a._id === app._id ? { ...a, status: "processing" } : a)
// //       );

// //       fetch(`http://localhost:5000/api/applications/${app._id}/reject`, {
// //         method: "POST",
// //       })
// //         .then((res) => res.json())
// //         .then((data) => {
// //           if (data.success) {
// //             setApplications(prev => 
// //               prev.map(a => a._id === app._id ? { ...a, status: "rejected" } : a)
// //             );
// //             showNotification("Application rejected", "info");
// //           } else {
// //             setApplications(prev => 
// //               prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
// //             );
// //             showNotification("Error: " + data.message, "error");
// //           }
// //         })
// //         .catch(err => {
// //           console.error(err);
// //           setApplications(prev => 
// //             prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
// //           );
// //           showNotification("Failed to reject application ❌", "error");
// //         });
// //     }
// //   };

// //   // Notification system
// //   const showNotification = (message, type = "info") => {
// //     const notification = document.createElement('div');
// //     notification.className = `notification notification-${type}`;
// //     notification.innerHTML = message;
// //     document.body.appendChild(notification);
    
// //     setTimeout(() => {
// //       notification.classList.add('show');
// //     }, 100);

// //     setTimeout(() => {
// //       notification.classList.remove('show');
// //       setTimeout(() => {
// //         document.body.removeChild(notification);
// //       }, 300);
// //     }, 3000);
// //   };

// //   // Filter applications
// //   const filteredApplications = applications.filter(app => {
// //     const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
// //     const matchesSearch = app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
// //                          app.email.toLowerCase().includes(searchTerm.toLowerCase());
// //     return matchesStatus && matchesSearch;
// //   });

// //   // Get status counts
// //   const statusCounts = {
// //     total: applications.length,
// //     pending: applications.filter(app => app.status === 'pending').length,
// //     approved: applications.filter(app => app.status === 'approved').length,
// //     rejected: applications.filter(app => app.status === 'rejected').length,
// //     processing: applications.filter(app => app.status === 'processing').length,
// //   };

// //   // Field labels
// //   const profileFields = [
// //     { key: "companyName", label: "🏢 Company Name" },
// //     { key: "website", label: "🌐 Website" },
// //     { key: "industry", label: "🏭 Industry" },
// //     { key: "companySize", label: "👥 Company Size" },
// //     { key: "phone", label: "📞 Phone" },
// //     { key: "email", label: "✉ Email" },
// //     { key: "address", label: "📍 Address" },
// //     { key: "city", label: "🏙 City" },
// //     { key: "state", label: "🗺 State" },
// //     { key: "country", label: "🌎 Country" },
// //     { key: "linkedin", label: "🔗 LinkedIn" },
// //     { key: "logo", label: "🖼 Logo URL" },
// //     { key: "description", label: "📝 Description" },
// //   ];

// //   return (
// //     <div className="req-page-wrapper">
// //       {/* Enhanced Inline Styles */}
// //       <style jsx>{`
// //         .req-page-wrapper {
// //           font-family: 'Inter', 'Segoe UI', sans-serif;
// //           background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
// //           min-height: 100vh;
// //           position: relative;
// //         }

// //         .req-page-wrapper::before {
// //           content: '';
// //           position: absolute;
// //           top: 0;
// //           left: 0;
// //           right: 0;
// //           bottom: 0;
// //           background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
// //           pointer-events: none;
// //         }

// //         .notification {
// //           position: fixed;
// //           top: 20px;
// //           right: 20px;
// //           padding: 1rem 1.5rem;
// //           border-radius: 10px;
// //           color: white;
// //           font-weight: 600;
// //           z-index: 10000;
// //           transform: translateX(400px);
// //           transition: transform 0.3s ease;
// //           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
// //           max-width: 300px;
// //         }

// //         .notification.show {
// //           transform: translateX(0);
// //         }

// //         .notification-success {
// //           background: linear-gradient(45deg, #2ecc71, #27ae60);
// //         }

// //         .notification-error {
// //           background: linear-gradient(45deg, #e74c3c, #c0392b);
// //         }

// //         .notification-info {
// //           background: linear-gradient(45deg, #3498db, #2980b9);
// //         }

// //         .req-header-mobile {
// //           display: none;
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(10px);
// //           box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
// //           position: sticky;
// //           top: 0;
// //           z-index: 1000;
// //         }

// //         .req-header-mobile-bar {
// //           padding: 1rem;
// //         }

// //         .req-header-mobile-inner {
// //           display: flex;
// //           justify-content: space-between;
// //           align-items: center;
// //         }

// //         .req-logo {
// //           font-size: 1.5rem;
// //           font-weight: 800;
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //           -webkit-background-clip: text;
// //           -webkit-text-fill-color: transparent;
// //           text-decoration: none;
// //           letter-spacing: -0.5px;
// //         }

// //         .req-hamburger {
// //           background: none;
// //           border: none;
// //           font-size: 1.5rem;
// //           cursor: pointer;
// //           color: #667eea;
// //           transition: transform 0.3s ease;
// //         }

// //         .req-hamburger:hover {
// //           transform: scale(1.1);
// //         }

// //         .req-navbar-mobile {
// //           max-height: 0;
// //           overflow: hidden;
// //           transition: max-height 0.3s ease;
// //           background: rgba(255, 255, 255, 0.95);
// //         }

// //         .req-navbar-mobile.open {
// //           max-height: 300px;
// //         }

// //         .req-mobile-nav-list {
// //           list-style: none;
// //           padding: 0;
// //           margin: 0;
// //         }

// //         .req-mobile-nav-list li {
// //           border-bottom: 1px solid rgba(0, 0, 0, 0.1);
// //         }

// //         .req-nav-link {
// //           display: block;
// //           padding: 1rem;
// //           color: #333;
// //           text-decoration: none;
// //           transition: all 0.3s ease;
// //           font-weight: 500;
// //         }

// //         .req-nav-link:hover {
// //           background: rgba(102, 126, 234, 0.1);
// //           color: #667eea;
// //           transform: translateX(5px);
// //         }

// //         .req-menu-sidebar {
// //           width: 280px;
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(20px);
// //           height: 100vh;
// //           position: fixed;
// //           left: 0;
// //           top: 0;
// //           z-index: 1000;
// //           box-shadow: 0 0 50px rgba(0, 0, 0, 0.1);
// //           border-right: 1px solid rgba(255, 255, 255, 0.2);
// //         }

// //         .req-sidebar-logo {
// //           padding: 2rem 1.5rem;
// //           border-bottom: 1px solid rgba(0, 0, 0, 0.1);
// //           text-align: center;
// //         }

// //         .req-sidebar-content {
// //           padding: 2rem 0;
// //         }

// //         .req-navbar-list {
// //           list-style: none;
// //           padding: 0;
// //           margin: 0;
// //         }

// //         .req-nav-item {
// //           margin-bottom: 0.5rem;
// //         }

// //         .req-nav-link.active {
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //           color: white;
// //           margin: 0 1rem;
// //           border-radius: 10px;
// //           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
// //         }

// //         .req-page-container {
// //           margin-left: 280px;
// //           min-height: 100vh;
// //           position: relative;
// //           z-index: 1;
// //         }

// //         .req-header-desktop {
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(10px);
// //           padding: 1.5rem 2rem;
// //           box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
// //           position: sticky;
// //           top: 0;
// //           z-index: 999;
// //         }

// //         .req-header-wrap {
// //           display: flex;
// //           justify-content: space-between;
// //           align-items: center;
// //         }

// //         .req-search-form {
// //           display: flex;
// //           align-items: center;
// //           background: white;
// //           border-radius: 25px;
// //           padding: 0.5rem 1rem;
// //           box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
// //           transition: all 0.3s ease;
// //           border: 2px solid transparent;
// //         }

// //         .req-search-form:focus-within {
// //           border-color: #667eea;
// //           box-shadow: 0 4px 20px rgba(102, 126, 234, 0.2);
// //         }

// //         .req-search-input {
// //           border: none;
// //           outline: none;
// //           padding: 0.5rem;
// //           width: 300px;
// //           font-size: 0.9rem;
// //         }

// //         .req-search-button {
// //           background: none;
// //           border: none;
// //           cursor: pointer;
// //           font-size: 1rem;
// //           color: #667eea;
// //         }

// //         .req-account-wrap {
// //           display: flex;
// //           align-items: center;
// //         }

// //         .req-account-item {
// //           display: flex;
// //           align-items: center;
// //           gap: 0.75rem;
// //           cursor: pointer;
// //           padding: 0.5rem 1rem;
// //           border-radius: 25px;
// //           transition: all 0.3s ease;
// //         }

// //         .req-account-item:hover {
// //           background: rgba(102, 126, 234, 0.1);
// //         }

// //         .req-avatar {
// //           width: 45px;
// //           height: 45px;
// //           border-radius: 50%;
// //           object-fit: cover;
// //           border: 3px solid #667eea;
// //           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
// //         }

// //         .req-user-name {
// //           font-weight: 600;
// //           color: #333;
// //           text-decoration: none;
// //         }

// //         .profile-dropdown {
// //           position: absolute;
// //           top: 60px;
// //           right: 0;
// //           background: white;
// //           border-radius: 15px;
// //           box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
// //           min-width: 320px;
// //           overflow: hidden;
// //           z-index: 1000;
// //           animation: slideDown 0.3s ease-out;
// //           border: 1px solid rgba(102, 126, 234, 0.1);
// //         }

// //         @keyframes slideDown {
// //           from {
// //             opacity: 0;
// //             transform: translateY(-10px);
// //           }
// //           to {
// //             opacity: 1;
// //             transform: translateY(0);
// //           }
// //         }

// //         .profile-header {
// //           background: linear-gradient(135deg, #667eea, #764ba2);
// //           color: white;
// //           padding: 1.5rem;
// //           text-align: center;
// //         }

// //         .profile-info {
// //           padding: 1.5rem;
// //           max-height: 300px;
// //           overflow-y: auto;
// //         }

// //         .profile-info p {
// //           margin: 0.5rem 0;
// //           font-size: 0.9rem;
// //           line-height: 1.5;
// //         }

// //         .profile-actions {
// //           border-top: 1px solid #f0f0f0;
// //         }

// //         .profile-action-btn {
// //           width: 100%;
// //           padding: 1rem 1.5rem;
// //           border: none;
// //           background: none;
// //           text-align: left;
// //           cursor: pointer;
// //           font-weight: 600;
// //           transition: all 0.3s ease;
// //           display: flex;
// //           align-items: center;
// //           gap: 0.75rem;
// //         }

// //         .profile-action-btn:hover {
// //           background: rgba(102, 126, 234, 0.05);
// //           transform: translateX(5px);
// //         }

// //         .profile-action-btn.edit {
// //           color: #3498db;
// //         }

// //         .profile-action-btn.logout {
// //           color: #e74c3c;
// //           border-top: 1px solid #f0f0f0;
// //         }

// //         .applications-container {
// //           padding: 2rem;
// //         }

// //         .applications-header {
// //           text-align: center;
// //           margin-bottom: 3rem;
// //         }

// //         .applications-title {
// //           font-size: 2.5rem;
// //           font-weight: 800;
// //           color: white;
// //           margin-bottom: 0.5rem;
// //           text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
// //         }

// //         .applications-subtitle {
// //           color: rgba(255, 255, 255, 0.9);
// //           font-size: 1.1rem;
// //           margin-bottom: 2rem;
// //         }

// //         .stats-grid {
// //           display: grid;
// //           grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
// //           gap: 1.5rem;
// //           margin-bottom: 2rem;
// //           max-width: 800px;
// //           margin-left: auto;
// //           margin-right: auto;
// //         }

// //         .stat-card {
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(10px);
// //           border-radius: 15px;
// //           padding: 1.5rem;
// //           text-align: center;
// //           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
// //           transition: transform 0.3s ease;
// //           border: 1px solid rgba(255, 255, 255, 0.2);
// //         }

// //         .stat-card:hover {
// //           transform: translateY(-2px);
// //         }

// //         .stat-number {
// //           font-size: 2rem;
// //           font-weight: 800;
// //           margin-bottom: 0.5rem;
// //         }

// //         .stat-label {
// //           font-size: 0.9rem;
// //           color: #666;
// //           font-weight: 600;
// //         }

// //         .stat-total { color: #667eea; }
// //         .stat-pending { color: #f39c12; }
// //         .stat-approved { color: #27ae60; }
// //         .stat-rejected { color: #e74c3c; }

// //         .filters-section {
// //           background: rgba(255, 255, 255, 0.95);
// //           backdrop-filter: blur(10px);
// //           border-radius: 15px;
// //           padding: 1.5rem;
// //           margin-bottom: 2rem;
// //           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
// //           max-width: 1200px;
// //           margin-left: auto;
// //           margin-right: auto;
// //         }

// //         .filters-header {
// //           display: flex;
// //           justify-content: space-between;
// //           align-items: center;
// //           margin-bottom: 1rem;
// //         }

// //         .filters-title {
// //           font-size: 1.2rem;
// //           font-weight: 700;
// //           color: #333;
// //         }

// //         .filters-controls {
// //           display: flex;
// //           gap: 1rem;
// //           flex-wrap: wrap;
// //           align-items: center;
// //         }

// //         .filter-group {
// //           display: flex;
// //           align-items: center;
// //           gap: 0.5rem;
// //         }

// //         .filter-label {
// //           font-weight: 600;
// //           color: #555;
// //           font-size: 0.9rem;
// //         }

// //         .filter-select {
// //           padding: 0.5rem 1rem;
// //           border: 2px solid #e0e0e0;
// //           border-radius: 8px;
// //           background: white;
// //           font-size: 0.9rem;
// //           transition: all 0.3s ease;
// //         }

// //         .filter-select:focus {
// //           border-color: #667eea;
// //           outline: none;
// //           box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
// //         }

// //         .search-box {
// //           flex: 1;
// //           min-width: 250px;
// //           position: relative;
// //         }

// //         .search-input {
// //           width: 100%;
// //           padding: 0.75rem 1rem 0.75rem 2.5rem;
// //           border: 2px solid #e0e0e0;
// //           border-radius: 10px;
// //           font-size: 0.9rem;
// //           transition: all 0.3s ease;
// //         }

// //         .search-input:focus {
// //           border-color: #667eea;
// //           outline: none;
// //           box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
// //         }

// //         .search-icon {
// //           position: absolute;
// //           left: 0.75rem;
// //           top: 50%;
// //           transform: translateY(-50%);
// //           color: #999;
// //           font-size: 1rem;
// //         }

// //         .applications-grid {
// //           display: grid;
// //           gap: 2rem;
// //           max-width: 1200px;
// //           margin: 0 auto;
// //         }

// //         .application-card {
// //           background: linear-gradient(145deg, rgba(255, 255, 255, 0.98), rgba(255, 255, 255, 0.92));
// //           backdrop-filter: blur(20px);
// //           border-radius: 24px;
// //           padding: 2.5rem;
// //           box-shadow: 
// //             0 8px 32px rgba(0, 0, 0, 0.08),
// //             0 4px 16px rgba(0, 0, 0, 0.04),
// //             inset 0 1px 0 rgba(255, 255, 255, 0.8);
// //           border: 1px solid rgba(255, 255, 255, 0.4);
// //           transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
// //           position: relative;
// //           overflow: hidden;
// //         }

// //         .application-card::before {
// //           content: '';
// //           position: absolute;
// //           top: 0;
// //           left: 0;
// //           right: 0;
// //           height: 5px;
// //           background: linear-gradient(90deg, #667eea 0%, #764ba2 50%, #667eea 100%);
// //           background-size: 200% 100%;
// //           animation: shimmer 3s ease-in-out infinite;
// //         }

// //         .application-card::after {
// //           content: '';
// //           position: absolute;
// //           top: -2px;
// //           left: -2px;
// //           right: -2px;
// //           bottom: -2px;
// //           background: linear-gradient(45deg, transparent, rgba(102, 126, 234, 0.1), transparent);
// //           border-radius: 26px;
// //           opacity: 0;
// //           transition: opacity 0.4s ease;
// //           z-index: -1;
// //         }

// //         @keyframes shimmer {
// //           0% { background-position: -200% 0; }
// //           100% { background-position: 200% 0; }
// //         }

// //         .application-card:hover {
// //           transform: translateY(-8px) scale(1.02);
// //           box-shadow: 
// //             0 20px 60px rgba(102, 126, 234, 0.15),
// //             0 12px 40px rgba(0, 0, 0, 0.08),
// //             inset 0 1px 0 rgba(255, 255, 255, 0.9);
// //           border-color: rgba(102, 126, 234, 0.3);
// //         }

// //         .application-card:hover::after {
// //           opacity: 1;
// //         }

// //         .application-header {
// //           display: flex;
// //           align-items: center;
// //           justify-content: space-between;
// //           margin-bottom: 2rem;
// //           padding-bottom: 1rem;
// //           border-bottom: 2px solid rgba(102, 126, 234, 0.08);
// //           position: relative;
// //         }

// //         .application-header::after {
// //           content: '';
// //           position: absolute;
// //           bottom: -2px;
// //           left: 0;
// //           width: 60px;
// //           height: 2px;
// //           background: linear-gradient(90deg, #667eea, #764ba2);
// //           border-radius: 1px;
// //         }

// //         .applicant-info {
// //           display: flex;
// //           align-items: center;
// //           gap: 1.5rem;
// //         }

// //         .applicant-avatar {
// //           width: 72px;
// //           height: 72px;
// //           border-radius: 50%;
// //           background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
// //           display: flex;
// //           align-items: center;
// //           justify-content: center;
// //           color: white;
// //           font-size: 1.8rem;
// //           font-weight: 800;
// //           box-shadow: 
// //             0 8px 24px rgba(102, 126, 234, 0.3),
// //             0 4px 12px rgba(118, 75, 162, 0.2);
// //           border: 3px solid rgba(255, 255, 255, 0.9);
// //           transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
// //           position: relative;
// //           overflow: hidden;
// //         }

// //         .applicant-avatar::before {
// //           content: '';
// //           position: absolute;
// //           top: -50%;
// //           left: -50%;
// //           width: 200%;
// //           height: 200%;
// //           background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
// //           transform: rotate(45deg);
// //           transition: transform 0.6s ease;
// //         }

// //         .application-card:hover .applicant-avatar {
// //           transform: scale(1.1);
// //           box-shadow: 
// //             0 12px 32px rgba(102, 126, 234, 0.4),
// //             0 6px 16px rgba(118, 75, 162, 0.3);
// //         }

// //         .application-card:hover .applicant-avatar::before {
// //           transform: rotate(45deg) translateX(100%);
// //         }

// //         .applicant-name {
// //           font-size: 1.6rem;
// //           font-weight: 800;
// //           color: #2c3e50;
// //           margin: 0;
// //           line-height: 1.2;
// //           text-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
// //           transition: color 0.3s ease;
// //         }

// //         .application-card:hover .applicant-name {
// //           color: #667eea;
// //         }

// //         .status-badge {
// //           padding: 0.5rem 1rem;
// //           border-radius: 20px;
// //           font-weight: 600;
// //           font-size: 0.9rem;
// //           text-transform: uppercase;
// //           letter-spacing: 0.5px;
// //         }

// //         .status-pending {
// //           background: rgba(243, 156, 18, 0.1);
// //           color: #f39c12;
// //           border: 2px solid rgba(243, 156, 18, 0.3);
// //         }

// //         .status-approved {
// //           background: rgba(46, 204, 113, 0.1);
// //           color: #27ae60;
// //           border: 2px solid rgba(46, 204, 113, 0.3);
// //         }

// //         .status-rejected {
// //           background: rgba(231, 76, 60, 0.1);
// //           color: #c0392b;
// //           border: 2px solid rgba(231, 76, 60, 0.3);
// //         }

// //         .status-processing {
// //           background: rgba(52, 152, 219, 0.1);
// //           color: #3498db;
// //           border: 2px solid rgba(52, 152, 219, 0.3);
// //           animation: pulse 2s infinite;
// //         }

// //         @keyframes pulse {
// //           0% { opacity: 1; }
// //           50% { opacity: 0.6; }
// //           100% { opacity: 1; }
// //         }

// //         .application-details {
// //           margin-bottom: 2rem;
// //         }

// //         .detail-row {
// //           display: flex;
// //           align-items: flex-start;
// //           margin-bottom: 1rem;
// //           padding: 0.75rem;
// //           background: rgba(102, 126, 234, 0.05);
// //           border-radius: 10px;
// //           border-left: 4px solid #667eea;
// //         }

// //         .detail-label {
// //           font-weight: 600;
// //           color: #667eea;
// //           min-width: 100px;
// //           margin-right: 1rem;
// //         }

// //         .detail-value {
// //           flex: 1;
// //           color: #555;
// //           line-height: 1.6;
// //         }

// //         .detail-link {
// //           color: #667eea;
// //           text-decoration: none;
// //           font-weight: 500;
// //           transition: color 0.3s ease;
// //         }

// //         .detail-link:hover {
// //           color: #764ba2;
// //           text-decoration: underline;
// //         }

// //         .interview-info {
// //           background: rgba(46, 204, 113, 0.1);
// //           border: 1px solid rgba(46, 204, 113, 0.3);
// //           border-radius: 10px;
// //           padding: 1rem;
// //           margin-top: 1rem;
// //         }

// //         .interview-title {
// //           font-weight: 700;
// //           color: #27ae60;
// //           margin-bottom: 0.5rem;
// //           display: flex;
// //           align-items: center;
// //           gap: 0.5rem;
// //         }

// //         .application-footer {
// //           display: flex;
// //           justify-content: space-between;
// //           align-items: center;
// //           padding-top: 1.5rem;
// //           border-top: 1px solid #f0f0f0;
// //         }

// //         .application-date {
// //           color: #888;
// //           font-size: 0.9rem;
// //         }

// //         .application-actions {
// //           display: flex;
// //           gap: 1rem;
// //         }

// //         .action-btn {
// //           padding: 0.75rem 1.5rem;
// //           border: none;
// //           border-radius: 25px;
// //           font-weight: 600;
// //           cursor: pointer;
// //           transition: all 0.3s ease;
// //           font-size: 0.9rem;
// //           display: flex;
// //           align-items: center;
// //           gap: 0.5rem;
// //         }

// //         .action-btn:disabled {
// //           opacity: 0.6;
// //           cursor: not-allowed;
// //         }

// //         .approve-btn {
// //           background: linear-gradient(45deg, #2ecc71, #27ae60);
// //           color: white;
// //           box-shadow: 0 4px 15px rgba(46, 204, 113, 0.4);
// //         }

// //         .approve-btn:hover:not(:disabled) {
// //           transform: translateY(-2px);
// //           box-shadow: 0 6px 20px rgba(46, 204, 113, 0.6);
// //         }

// //         .reject-btn {
// //           background: linear-gradient(45deg, #e74c3c, #c0392b);
// //           color: white;
// //           box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);
// //         }

// //         .reject-btn:hover:not(:disabled) {
// //           transform: translateY(-2px);
// //           box-shadow: 0 6px 20px rgba(231, 76, 60, 0.6);
// //         }

// //         .modal-overlay {
// //           position: fixed;
// //           top: 0;
// //           left: 0;
// //           right: 0;
// //           bottom: 0;
// //           background: rgba(0, 0, 0, 0.7);
// //           display: flex;
// //           justify-content: center;
// //           align-items: center;
// //           z-index: 2000;
// //           backdrop-filter: blur(5px);
// //         }

// //         .modal-content {
// //           background: white;
// //           border-radius: 20px;
// //           padding: 2rem;
// //           width: 90%;
// //           max-width: 600px;
// //           max-height: 90vh;
// //           overflow-y: auto;
// //           box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
// //           animation: modalSlideIn 0.3s ease-out;
// //         }

// //         @keyframes modalSlideIn {
// //           from {
// //             opacity: 0;
// //             transform: scale(0.9);
// //           }
// //           to {
// //             opacity: 1;
// //             transform: scale(1);
// //           }
// //         }

// //         .modal-header {
// //           text-align: center;
// //           margin-bottom: 2rem;
// //         }

// //         .modal-title {
// //           font-size: 1.8rem;
// //           font-weight: 700;
// //           color: #333;
// //           margin-bottom: 0.5rem;
// //         }

// //         .form-group {
// //           margin-bottom: 1.5rem;
// //         }

// //         .form-label {
// //           display: block;
// //           font-weight: 600;
// //           color: #333;
// //           margin-bottom: 0.5rem;
// //         }

// //         .form-input {
// //           width: 100%;
// //           padding: 0.75rem 1rem;
// //           border: 2px solid #e0e0e0;
// //           border-radius: 10px;
// //           font-size: 0.9rem;
// //           transition: all 0.3s ease;
// //           background: white;
// //         }

// //         .form-input:focus {
// //           border-color: #667eea;
// //           box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
// //           outline: none;
// //         }

// //         .modal-actions {
// //           display: flex;
// //           gap: 1rem;
// //           margin-top: 2rem;
// //         }

// //         .modal-btn {
// //           flex: 1;
// //           padding: 0.75rem;
// //           border: none;
// //           border-radius: 10px;
// //           font-weight: 600;
// //           cursor: pointer;
// //           transition: all 0.3s ease;
// //         }

// //         .save-btn {
// //           background: linear-gradient(45deg, #667eea, #764ba2);
// //           color: white;
// //         }

// //         .save-btn:hover {
// //           transform: translateY(-2px);
// //           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
// //         }

// //         .cancel-btn {
// //           background: #f8f9fa;
// //           color: #666;
// //           border: 2px solid #e0e0e0;
// //         }

// //         .cancel-btn:hover {
// //           background: #e9ecef;
// //           border-color: #ccc;
// //         }

// //         .loading-spinner {
// //           display: flex;
// //           justify-content: center;
// //           align-items: center;
// //           height: 200px;
// //           font-size: 1.1rem;
// //           color: rgba(255, 255, 255, 0.8);
// //         }

// //         .empty-state {
// //           text-align: center;
// //           padding: 4rem 2rem;
// //           color: rgba(255, 255, 255, 0.8);
// //         }

// //         .empty-state-icon {
// //           font-size: 4rem;
// //           margin-bottom: 1rem;
// //         }

// //         .empty-state-title {
// //           font-size: 1.5rem;
// //           font-weight: 600;
// //           margin-bottom: 0.5rem;
// //         }

// //         .empty-state-subtitle {
// //           font-size: 1rem;
// //         }

// //         @media (max-width: 768px) {
// //           .req-header-mobile {
// //             display: block;
// //           }

// //           .req-menu-sidebar {
// //             display: none;
// //           }

// //           .req-page-container {
// //             margin-left: 0;
// //           }

// //           .req-header-desktop {
// //             display: none;
// //           }

// //           .applications-container {
// //             padding: 1rem;
// //           }

// //           .applications-title {
// //             font-size: 2rem;
// //           }

// //           .stats-grid {
// //             grid-template-columns: repeat(2, 1fr);
// //             gap: 1rem;
// //           }

// //           .filters-controls {
// //             flex-direction: column;
// //             align-items: stretch;
// //           }

// //           .search-box {
// //             min-width: auto;
// //           }

// //           .application-card {
// //             padding: 1.5rem;
// //           }

// //           .application-header {
// //             flex-direction: column;
// //             align-items: flex-start;
// //             gap: 1rem;
// //           }

// //           .application-actions {
// //             flex-direction: column;
// //             width: 100%;
// //           }

// //           .action-btn {
// //             width: 100%;
// //             justify-content: center;
// //           }

// //           .modal-content {
// //             width: 95%;
// //             margin: 1rem;
// //           }

// //           .modal-actions {
// //             flex-direction: column;
// //           }
// //         }

// //         @media (max-width: 480px) {
// //           .stats-grid {
// //             grid-template-columns: 1fr;
// //           }

// //           .applications-title {
// //             font-size: 1.8rem;
// //           }

// //           .stat-card {
// //             padding: 1rem;
// //           }

// //           .filters-section {
// //             padding: 1rem;
// //           }
// //         }
// //       `}</style>

// //       {/* Mobile Header */}
// //       <header className="req-header-mobile">
// //         <div className="req-header-mobile-bar">
// //           <div className="req-header-mobile-inner">
// //             <a href="#" className="req-logo">
// //               JOB PORTAL
// //             </a>
// //             <button
// //               className="req-hamburger"
// //               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
// //             >
// //               ☰
// //             </button>
// //           </div>
// //         </div>
// //         <nav className={`req-navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
// //           <ul className="req-mobile-nav-list">
// //             <li>
// //               <a href="#" className="req-nav-link">
// //                 📊 Dashboard
// //               </a>
// //             </li>
// //             <li>
// //               <a href="#" className="req-nav-link">
// //                 📄 Pages
// //               </a>
// //             </li>
// //             <li>
// //               <button
// //                 onClick={handleLogout}
// //                 className="req-nav-link"
// //                 style={{
// //                   background: "none",
// //                   border: "none",
// //                   width: "100%",
// //                   textAlign: "left",
// //                   cursor: "pointer",
// //                 }}
// //               >
// //                 🚪 Logout
// //               </button>
// //             </li>
// //           </ul>
// //         </nav>
// //       </header>

// //       {/* Desktop Sidebar */}
// //       <aside className="req-menu-sidebar">
// //         <div className="req-sidebar-logo">
// //           <a href="#" className="req-logo">
// //             JOB PORTAL
// //           </a>
// //         </div>
// //         <nav className="req-sidebar-content">
// //           <ul className="req-navbar-list">
// //             <li className="req-nav-item">
// //               <a href="#" className="req-nav-link active">
// //                 📊 Dashboard
// //               </a>
// //             </li>
// //           </ul>
// //         </nav>
// //       </aside>

// //       {/* Page Container */}
// //       <div className="req-page-container">
// //         {/* Desktop Header */}
// //         <header className="req-header-desktop">
// //           <div className="req-header-wrap">
// //             <div className="req-search-form">
// //               <input
// //                 type="text"
// //                 placeholder="Search for applications & reports..."
// //                 className="req-search-input"
// //                 value={searchTerm}
// //                 onChange={(e) => setSearchTerm(e.target.value)}
// //               />
// //               <button className="req-search-button">🔍</button>
// //             </div>
// //             <div className="req-account-wrap">
// //               <div
// //                 className="req-account-item"
// //                 style={{ position: "relative" }}
// //               >
// //                 <img
// //                   className="req-avatar"
// //                   src={
// //                     recruiterProfile?.avatar ||
// //                     "https://randomuser.me/api/portraits/men/75.jpg"
// //                   }
// //                   alt="Profile"
// //                   onClick={() => setIsProfileOpen((prev) => !prev)}
// //                   style={{ cursor: "pointer" }}
// //                 />
// //                 <a
// //                   href="#"
// //                   className="req-user-name"
// //                   onClick={(e) => {
// //                     e.preventDefault();
// //                     setIsProfileOpen((prev) => !prev);
// //                   }}
// //                 >
// //                   {recruiterName || "Recruiter"}
// //                 </a>

// //                 {/* Enhanced Profile Dropdown */}
// //                 {isProfileOpen && (
// //                   <>
// //                     <div
// //                       style={{
// //                         position: "fixed",
// //                         top: 0,
// //                         left: 0,
// //                         width: "100vw",
// //                         height: "100vh",
// //                         background: "transparent",
// //                         zIndex: 999
// //                       }}
// //                       onClick={() => setIsProfileOpen(false)}
// //                     />
// //                     <div className="profile-dropdown">
// //                       {recruiterProfile && (
// //                         <div className="profile-header">
// //                           <strong>
// //                             {recruiterProfile.firstName}{" "}
// //                             {recruiterProfile.lastName}
// //                           </strong>
// //                           <div style={{ opacity: 0.9, marginTop: "0.5rem" }}>
// //                             {recruiterProfile.email}
// //                           </div>
// //                         </div>
// //                       )}
                      
// //                       {employerProfile ? (
// //                         <div className="profile-info">
// //                           <div className="detail-row">
// //                             <span className="detail-label">🏢</span>
// //                             <strong>{employerProfile.companyName}</strong>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">📍</span>
// //                             <span>{employerProfile.address}, {employerProfile.city}, {employerProfile.state}, {employerProfile.country}</span>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">📞</span>
// //                             <span>{employerProfile.phone}</span>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">🌐</span>
// //                             <a href={employerProfile.website} target="_blank" rel="noreferrer" className="detail-link">{employerProfile.website}</a>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">🏭</span>
// //                             <span>{employerProfile.industry} | 👥 {employerProfile.companySize}</span>
// //                           </div>
// //                           <div className="detail-row">
// //                             <span className="detail-label">🔗</span>
// //                             <a href={employerProfile.linkedin} target="_blank" rel="noreferrer" className="detail-link">LinkedIn</a>
// //                           </div>
// //                           {employerProfile.description && (
// //                             <div className="detail-row">
// //                               <span className="detail-label">📝</span>
// //                               <span>{employerProfile.description}</span>
// //                             </div>
// //                           )}
// //                         </div>
// //                       ) : (
// //                         <div className="profile-info">
// //                           <div style={{ 
// //                             textAlign: "center", 
// //                             color: "#888",
// //                             padding: "2rem" 
// //                           }}>
// //                             ⚠ No employer profile found
// //                             <div style={{ fontSize: "0.9rem", marginTop: "0.5rem" }}>
// //                               Complete your profile to get started
// //                             </div>
// //                           </div>
// //                         </div>
// //                       )}

// //                       <div className="profile-actions">
// //                         <button
// //                           className="profile-action-btn edit"
// //                           onClick={() => {
// //                             setEditData(employerProfile || {});
// //                             setIsEditOpen(true);
// //                             setIsProfileOpen(false);
// //                           }}
// //                         >
// //                           <span>✏</span>
// //                           Edit Profile
// //                         </button>

// //                         <button
// //                           className="profile-action-btn logout"
// //                           onClick={() => {
// //                             handleLogout();
// //                             setIsProfileOpen(false);
// //                           }}
// //                         >
// //                           <span>🚪</span>
// //                           Logout
// //                         </button>
// //                       </div>
// //                     </div>
// //                   </>
// //                 )}
// //               </div>
// //             </div>
// //           </div>
// //         </header>

// //         {/* Main Content - Applications */}
// //         <div className="applications-container">
// //           <div className="applications-header">
// //             <h1 className="applications-title">
// //               Welcome back, {recruiterName || "Recruiter"}!
// //             </h1>
// //             <p className="applications-subtitle">
// //               Manage your job applications and find the perfect candidates
// //             </p>

// //             {/* Statistics Cards */}
// //             <div className="stats-grid">
// //               <div className="stat-card">
// //                 <div className="stat-number stat-total">{statusCounts.total}</div>
// //                 <div className="stat-label">Total Applications</div>
// //               </div>
// //               <div className="stat-card">
// //                 <div className="stat-number stat-pending">{statusCounts.pending}</div>
// //                 <div className="stat-label">Pending Review</div>
// //               </div>
// //               <div className="stat-card">
// //                 <div className="stat-number stat-approved">{statusCounts.approved}</div>
// //                 <div className="stat-label">Approved</div>
// //               </div>
// //               <div className="stat-card">
// //                 <div className="stat-number stat-rejected">{statusCounts.rejected}</div>
// //                 <div className="stat-label">Rejected</div>
// //               </div>
// //             </div>
// //           </div>

// //           {/* Filters Section */}
// //           <div className="filters-section">
// //             <div className="filters-header">
// //               <div className="filters-title">📋 Application Management</div>
// //             </div>
// //             <div className="filters-controls">
// //               <div className="filter-group">
// //                 <label className="filter-label">Status:</label>
// //                 <select
// //                   className="filter-select"
// //                   value={statusFilter}
// //                   onChange={(e) => setStatusFilter(e.target.value)}
// //                 >
// //                   <option value="all">All Applications</option>
// //                   <option value="pending">Pending ({statusCounts.pending})</option>
// //                   <option value="approved">Approved ({statusCounts.approved})</option>
// //                   <option value="rejected">Rejected ({statusCounts.rejected})</option>
// //                   <option value="processing">Processing ({statusCounts.processing})</option>
// //                 </select>
// //               </div>
              
// //               <div className="search-box">
// //                 <div className="search-icon">🔍</div>
// //                 <input
// //                   type="text"
// //                   className="search-input"
// //                   placeholder="Search by name or email..."
// //                   value={searchTerm}
// //                   onChange={(e) => setSearchTerm(e.target.value)}
// //                 />
// //               </div>
// //             </div>
// //           </div>

// //           {loading ? (
// //             <div className="loading-spinner">
// //               <div>🔄 Loading applications...</div>
// //             </div>
// //           ) : filteredApplications.length === 0 ? (
// //             <div className="empty-state">
// //               <div className="empty-state-icon">
// //                 {searchTerm || statusFilter !== 'all' ? '🔍' : '📋'}
// //               </div>
// //               <h3 className="empty-state-title">
// //                 {searchTerm || statusFilter !== 'all' 
// //                   ? 'No Applications Found' 
// //                   : 'No Applications Yet'
// //                 }
// //               </h3>
// //               <p className="empty-state-subtitle">
// //                 {searchTerm || statusFilter !== 'all'
// //                   ? 'Try adjusting your search or filter criteria'
// //                   : 'Applications for your job posts will appear here'
// //                 }
// //               </p>
// //             </div>
// //           ) : (
// //             <div className="applications-grid">
// //               {filteredApplications.map((app) => (
// //                 <div key={app._id} className="application-card">
// //                   <div className="application-header">
// //                     <div className="applicant-info">
// //                       <div className="applicant-avatar">
// //                         {app.name ? app.name.charAt(0).toUpperCase() : '👤'}
// //                       </div>
// //                       <div>
// //                         <h3 className="applicant-name">{app.name}</h3>
// //                       </div>
// //                     </div>
// //                     <div className={`status-badge status-${app.status}`}>
// //                       {app.status === 'pending' && '⏳ Pending'}
// //                       {app.status === 'approved' && '✅ Approved'}
// //                       {app.status === 'rejected' && '❌ Rejected'}
// //                       {app.status === 'processing' && '⚙️ Processing'}
// //                     </div>
// //                   </div>

// //                   <div className="application-details">
// //                     <div className="detail-row">
// //                       <span className="detail-label">✉ Email:</span>
// //                       <span className="detail-value">
// //                         <a href={`mailto:${app.email}`} className="detail-link">
// //                           {app.email}
// //                         </a>
// //                       </span>
// //                     </div>

// //                     {app.portfolio && (
// //                       <div className="detail-row">
// //                         <span className="detail-label">🌐 Portfolio:</span>
// //                         <span className="detail-value">
// //                           <a href={app.portfolio} target="_blank" rel="noreferrer" className="detail-link">
// //                             View Portfolio
// //                           </a>
// //                         </span>
// //                       </div>
// //                     )}

// //                     <div className="detail-row">
// //                       <span className="detail-label">📝 Cover Letter:</span>
// //                       <span className="detail-value">{app.coverLetter}</span>
// //                     </div>

// //                     {app.resume && (
// //                       <div className="detail-row">
// //                         <span className="detail-label">📄 Resume:</span>
// //                         <span className="detail-value">
// //                           <a 
// //                             href={`http://localhost:5000${app.resume}`} 
// //                             target="_blank" 
// //                             rel="noreferrer" 
// //                             className="detail-link"
// //                           >
// //                             Download Resume
// //                           </a>
// //                         </span>
// //                       </div>
// //                     )}

// //                     {/* Interview Information for Approved Applications */}
// //                     {app.status === 'approved' && (app.interviewDate || app.meetingLink) && (
// //                       <div className="interview-info">
// //                         <div className="interview-title">
// //                           📅 Interview Scheduled
// //                         </div>
// //                         {app.interviewDate && (
// //                           <div><strong>Date & Time:</strong> {app.interviewDate}</div>
// //                         )}
// //                         {app.meetingLink && (
// //                           <div>
// //                             <strong>Meeting Link:</strong> 
// //                             <a href={app.meetingLink} target="_blank" rel="noreferrer" className="detail-link">
// //                               Join Interview
// //                             </a>
// //                           </div>
// //                         )}
// //                       </div>
// //                     )}
// //                   </div>

// //                   <div className="application-footer">
// //                     <div className="application-date">
// //                       📅 Applied on: {new Date(app.createdAt).toLocaleDateString('en-US', {
// //                         year: 'numeric',
// //                         month: 'long',
// //                         day: 'numeric',
// //                         hour: '2-digit',
// //                         minute: '2-digit'
// //                       })}
// //                     </div>

// //                     <div className="application-actions">
// //                       {app.status === "pending" ? (
// //                         <>
// //                           <button
// //                             className="action-btn approve-btn"
// //                             onClick={() => handleApprove(app)}
// //                           >
// //                             <span>✅</span> Approve
// //                           </button>
// //                           <button
// //                             className="action-btn reject-btn"
// //                             onClick={() => handleReject(app)}
// //                           >
// //                             <span>❌</span> Reject
// //                           </button>
// //                         </>
// //                       ) : app.status === "processing" ? (
// //                         <div className={`status-badge status-${app.status}`}>
// //                           <span>⚙️</span> Processing...
// //                         </div>
// //                       ) : (
// //                         <div className={`status-badge status-${app.status}`}>
// //                           {app.status === "approved" ? "✅ Interview Scheduled" : "❌ Application Rejected"}
// //                         </div>
// //                       )}
// //                     </div>
// //                   </div>
// //                 </div>
// //               ))}
// //             </div>
// //           )}
// //         </div>

// //         {/* Enhanced Edit Profile Modal */}
// //         {isEditOpen && (
// //           <div className="modal-overlay">
// //             <div className="modal-content">
// //               <div className="modal-header">
// //                 <h3 className="modal-title">✏ Edit Employer Profile</h3>
// //                 <p style={{ color: "#666", marginTop: "0.5rem" }}>
// //                   Update your company information to attract better candidates
// //                 </p>
// //               </div>
// //               <form onSubmit={(e) => {
// //                 e.preventDefault();
// //                 handleSaveProfile();
// //               }}>
// //                 {profileFields.map(({ key, label }) => (
// //                   <div key={key} className="form-group">
// //                     <label className="form-label">{label}</label>
// //                     {key === 'description' ? (
// //                       <textarea
// //                         className="form-input"
// //                         value={editData?.[key] || ""}
// //                         onChange={(e) =>
// //                           setEditData({ ...editData, [key]: e.target.value })
// //                         }
// //                         placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
// //                         rows="4"
// //                         style={{ resize: 'vertical', minHeight: '100px' }}
// //                       />
// //                     ) : (
// //                       <input
// //                         type={key === 'email' ? 'email' : key === 'website' || key === 'linkedin' ? 'url' : 'text'}
// //                         className="form-input"
// //                         value={editData?.[key] || ""}
// //                         onChange={(e) =>
// //                           setEditData({ ...editData, [key]: e.target.value })
// //                         }
// //                         placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
// //                       />
// //                     )}
// //                   </div>
// //                 ))}

// //                 <div className="modal-actions">
// //                   <button type="submit" className="modal-btn save-btn">
// //                     💾 Save Changes
// //                   </button>
// //                   <button
// //                     type="button"
// //                     onClick={() => setIsEditOpen(false)}
// //                     className="modal-btn cancel-btn"
// //                   >
// //                     ✖ Cancel
// //                   </button>
// //                 </div>
// //               </form>
// //             </div>
// //           </div>
// //         )}
// //       </div>
// //     </div>
// //   );
// // };

// // export default Req_Dashboard;

// import React, { useState, useEffect } from "react";

// const Req_Dashboard = () => {
//   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
//   const [isProfileOpen, setIsProfileOpen] = useState(false);
//   const [recruiterName, setRecruiterName] = useState("");
//   const [recruiterProfile, setRecruiterProfile] = useState(null);
//   const [employerProfile, setEmployerProfile] = useState(null);
//   const [isEditOpen, setIsEditOpen] = useState(false);
//   const [editData, setEditData] = useState({});
//   const [applications, setApplications] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [statusFilter, setStatusFilter] = useState('all');
//   const [searchTerm, setSearchTerm] = useState('');
  
//   // New state for interview scheduling modal
//   const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
//   const [selectedApplication, setSelectedApplication] = useState(null);
//   const [interviewData, setInterviewData] = useState({
//     date: '',
//     time: '',
//     meetingLink: ''
//   });

//   const handleLogout = () => {
//     localStorage.removeItem("user");
//     window.location.href = "/";
//   };

//   // Fetch applications
//   useEffect(() => {
//     const storedUser = JSON.parse(localStorage.getItem("user"));
//     if (storedUser && storedUser.id) {
//       fetch(`http://localhost:5000/api/applications/by-user/${storedUser.id}`)
//         .then((res) => res.json())
//         .then((data) => {
//           if (data.success) setApplications(data.applications);
//           setLoading(false);
//         })
//         .catch((err) => {
//           console.error("Error fetching applications:", err);
//           setLoading(false);
//         });
//     }
//   }, []);

//   // Fetch user profile
//   useEffect(() => {
//     const storedUser = JSON.parse(localStorage.getItem("user"));
//     if (storedUser) {
//       const fullName = storedUser.firstName
//         ? `${storedUser.firstName} ${storedUser.lastName || ""}`
//         : storedUser.name || "";
//       setRecruiterName(fullName);
//       setRecruiterProfile(storedUser);

//       // Fetch employer profile
//       fetch(`http://localhost:5000/api/profile/employer/${storedUser.id}`)
//         .then((res) => res.json())
//         .then((data) => {
//           if (data.success) setEmployerProfile(data.profile);
//         })
//         .catch((err) => console.error(err));
//     }
//   }, []);

//   const handleSaveProfile = async () => {
//     try {
//       const res = await fetch(
//         `http://localhost:5000/api/profile/employer/${recruiterProfile.id}`,
//         {
//           method: "PUT",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify(editData),
//         }
//       );
//       const data = await res.json();
//       if (data.success) {
//         setEmployerProfile(data.profile);
//         setIsEditOpen(false);
//         showNotification("Profile updated successfully! ✅", "success");
//       } else {
//         showNotification("Error updating profile: " + data.message, "error");
//       }
//     } catch (err) {
//       console.error(err);
//       showNotification("❌ Failed to update profile", "error");
//     }
//   };

//   const openScheduleModal = (app) => {
//     setSelectedApplication(app);
//     setInterviewData({
//       date: '',
//       time: '',
//       meetingLink: ''
//     });
//     setIsScheduleModalOpen(true);
//   };

//   const handleScheduleInterview = () => {
//     const { date, time, meetingLink } = interviewData;

//     if (!date || !time || !meetingLink) {
//       showNotification("Please fill in all interview details", "error");
//       return;
//     }

//     const dateTime = `${date}T${time}`;

//     setApplications(prev => 
//       prev.map(a => a._id === selectedApplication._id ? { ...a, status: "processing" } : a)
//     );

//     fetch(`http://localhost:5000/api/applications/${selectedApplication._id}/approve`, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ date: dateTime, meetingLink }),
//     })
//       .then((res) => res.json())
//       .then((data) => {
//         if (data.success) {
//           setApplications(prev => 
//             prev.map(a => a._id === selectedApplication._id ? { 
//               ...a, 
//               status: "approved", 
//               interviewDate: dateTime, 
//               meetingLink: meetingLink 
//             } : a)
//           );
//           showNotification("Interview scheduled successfully! ✅", "success");
//           setIsScheduleModalOpen(false);
//           setSelectedApplication(null);
//         } else {
//           setApplications(prev => 
//             prev.map(a => a._id === selectedApplication._id ? { ...a, status: "pending" } : a)
//           );
//           showNotification("Error: " + data.message, "error");
//         }
//       })
//       .catch(err => {
//         console.error(err);
//         setApplications(prev => 
//           prev.map(a => a._id === selectedApplication._id ? { ...a, status: "pending" } : a)
//         );
//         showNotification("Failed to schedule interview ❌", "error");
//       });
//   };

//   const handleReject = (app) => {
//     if (window.confirm("Are you sure you want to reject this application?")) {
//       setApplications(prev => 
//         prev.map(a => a._id === app._id ? { ...a, status: "processing" } : a)
//       );

//       fetch(`http://localhost:5000/api/applications/${app._id}/reject`, {
//         method: "POST",
//       })
//         .then((res) => res.json())
//         .then((data) => {
//           if (data.success) {
//             setApplications(prev => 
//               prev.map(a => a._id === app._id ? { ...a, status: "rejected" } : a)
//             );
//             showNotification("Application rejected", "info");
//           } else {
//             setApplications(prev => 
//               prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
//             );
//             showNotification("Error: " + data.message, "error");
//           }
//         })
//         .catch(err => {
//           console.error(err);
//           setApplications(prev => 
//             prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
//           );
//           showNotification("Failed to reject application ❌", "error");
//         });
//     }
//   };

//   const showNotification = (message, type = "info") => {
//     const notification = document.createElement('div');
//     notification.className = `notification notification-${type}`;
//     notification.innerHTML = message;
//     document.body.appendChild(notification);
    
//     setTimeout(() => {
//       notification.classList.add('show');
//     }, 100);

//     setTimeout(() => {
//       notification.classList.remove('show');
//       setTimeout(() => {
//         document.body.removeChild(notification);
//       }, 300);
//     }, 3000);
//   };

//   const filteredApplications = applications.filter(app => {
//     const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
//     const matchesSearch = app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//                          app.email.toLowerCase().includes(searchTerm.toLowerCase());
//     return matchesStatus && matchesSearch;
//   });

//   const statusCounts = {
//     total: applications.length,
//     pending: applications.filter(app => app.status === 'pending').length,
//     approved: applications.filter(app => app.status === 'approved').length,
//     rejected: applications.filter(app => app.status === 'rejected').length,
//     processing: applications.filter(app => app.status === 'processing').length,
//   };

//   const profileFields = [
//     { key: "companyName", label: "🏢 Company Name" },
//     { key: "website", label: "🌐 Website" },
//     { key: "industry", label: "🏭 Industry" },
//     { key: "companySize", label: "👥 Company Size" },
//     { key: "phone", label: "📞 Phone" },
//     { key: "email", label: "✉ Email" },
//     { key: "address", label: "📍 Address" },
//     { key: "city", label: "🏙 City" },
//     { key: "state", label: "🗺 State" },
//     { key: "country", label: "🌎 Country" },
//     { key: "linkedin", label: "🔗 LinkedIn" },
//     { key: "logo", label: "🖼 Logo URL" },
//     { key: "description", label: "📝 Description" },
//   ];

//   const getTodayDate = () => {
//     const today = new Date();
//     return today.toISOString().split('T')[0];
//   };

//   return (
//     <div className="req-page-wrapper">
//       <style>{`
//         * {
//           margin: 0;
//           padding: 0;
//           box-sizing: border-box;
//         }

//         .req-page-wrapper {
//           font-family: 'Inter', 'Segoe UI', sans-serif;
//           background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
//           min-height: 100vh;
//           position: relative;
//         }

//         .req-page-wrapper::before {
//           content: '';
//           position: absolute;
//           top: 0;
//           left: 0;
//           right: 0;
//           bottom: 0;
//           background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
//           pointer-events: none;
//         }

//         .notification {
//           position: fixed;
//           top: 20px;
//           right: 20px;
//           padding: 1rem 1.5rem;
//           border-radius: 10px;
//           color: white;
//           font-weight: 600;
//           z-index: 10000;
//           transform: translateX(400px);
//           transition: transform 0.3s ease;
//           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
//           max-width: 300px;
//         }

//         .notification.show {
//           transform: translateX(0);
//         }

//         .notification-success {
//           background: linear-gradient(45deg, #2ecc71, #27ae60);
//         }

//         .notification-error {
//           background: linear-gradient(45deg, #e74c3c, #c0392b);
//         }

//         .notification-info {
//           background: linear-gradient(45deg, #3498db, #2980b9);
//         }

//         .req-header-mobile {
//           display: none;
//           background: rgba(255, 255, 255, 0.95);
//           backdrop-filter: blur(10px);
//           box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
//           position: sticky;
//           top: 0;
//           z-index: 1000;
//         }

//         .req-header-mobile-bar {
//           padding: 1rem;
//         }

//         .req-header-mobile-inner {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//         }

//         .req-logo {
//           font-size: 1.5rem;
//           font-weight: 800;
//           background: linear-gradient(45deg, #667eea, #764ba2);
//           -webkit-background-clip: text;
//           -webkit-text-fill-color: transparent;
//           text-decoration: none;
//           letter-spacing: -0.5px;
//         }

//         .req-hamburger {
//           background: none;
//           border: none;
//           font-size: 1.5rem;
//           cursor: pointer;
//           color: #667eea;
//           transition: transform 0.3s ease;
//         }

//         .req-hamburger:hover {
//           transform: scale(1.1);
//         }

//         .req-navbar-mobile {
//           max-height: 0;
//           overflow: hidden;
//           transition: max-height 0.3s ease;
//           background: rgba(255, 255, 255, 0.95);
//         }

//         .req-navbar-mobile.open {
//           max-height: 300px;
//         }

//         .req-mobile-nav-list {
//           list-style: none;
//           padding: 0;
//           margin: 0;
//         }

//         .req-mobile-nav-list li {
//           border-bottom: 1px solid rgba(0, 0, 0, 0.1);
//         }

//         .req-nav-link {
//           display: block;
//           padding: 1rem;
//           color: #333;
//           text-decoration: none;
//           transition: all 0.3s ease;
//           font-weight: 500;
//         }

//         .req-nav-link:hover {
//           background: rgba(102, 126, 234, 0.1);
//           color: #667eea;
//           transform: translateX(5px);
//         }

//         .req-menu-sidebar {
//           width: 280px;
//           background: rgba(255, 255, 255, 0.95);
//           backdrop-filter: blur(20px);
//           height: 100vh;
//           position: fixed;
//           left: 0;
//           top: 0;
//           z-index: 1000;
//           box-shadow: 0 0 50px rgba(0, 0, 0, 0.1);
//           border-right: 1px solid rgba(255, 255, 255, 0.2);
//         }

//         .req-sidebar-logo {
//           padding: 2rem 1.5rem;
//           border-bottom: 1px solid rgba(0, 0, 0, 0.1);
//           text-align: center;
//         }

//         .req-sidebar-content {
//           padding: 2rem 0;
//         }

//         .req-navbar-list {
//           list-style: none;
//           padding: 0;
//           margin: 0;
//         }

//         .req-nav-item {
//           margin-bottom: 0.5rem;
//         }

//         .req-nav-link.active {
//           background: linear-gradient(45deg, #667eea, #764ba2);
//           color: white;
//           margin: 0 1rem;
//           border-radius: 10px;
//           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
//         }

//         .req-page-container {
//           margin-left: 280px;
//           min-height: 100vh;
//           position: relative;
//           z-index: 1;
//         }

//         .req-header-desktop {
//           background: rgba(255, 255, 255, 0.95);
//           backdrop-filter: blur(10px);
//           padding: 1.5rem 2rem;
//           box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
//           position: sticky;
//           top: 0;
//           z-index: 999;
//         }

//         .req-header-wrap {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//         }

//         .req-search-form {
//           display: flex;
//           align-items: center;
//           background: white;
//           border-radius: 25px;
//           padding: 0.5rem 1rem;
//           box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
//           transition: all 0.3s ease;
//           border: 2px solid transparent;
//         }

//         .req-search-form:focus-within {
//           border-color: #667eea;
//           box-shadow: 0 4px 20px rgba(102, 126, 234, 0.2);
//         }

//         .req-search-input {
//           border: none;
//           outline: none;
//           padding: 0.5rem;
//           width: 300px;
//           font-size: 0.9rem;
//         }

//         .req-search-button {
//           background: none;
//           border: none;
//           cursor: pointer;
//           font-size: 1rem;
//           color: #667eea;
//         }

//         .req-account-wrap {
//           display: flex;
//           align-items: center;
//         }

//         .req-account-item {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//           cursor: pointer;
//           padding: 0.5rem 1rem;
//           border-radius: 25px;
//           transition: all 0.3s ease;
//           position: relative;
//         }

//         .req-account-item:hover {
//           background: rgba(102, 126, 234, 0.1);
//         }

//         .req-avatar {
//           width: 45px;
//           height: 45px;
//           border-radius: 50%;
//           object-fit: cover;
//           border: 3px solid #667eea;
//           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
//         }

//         .req-user-name {
//           font-weight: 600;
//           color: #333;
//           text-decoration: none;
//         }

//         .profile-dropdown {
//           position: absolute;
//           top: 60px;
//           right: 0;
//           background: white;
//           border-radius: 15px;
//           box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
//           min-width: 320px;
//           overflow: hidden;
//           z-index: 1000;
//           animation: slideDown 0.3s ease-out;
//           border: 1px solid rgba(102, 126, 234, 0.1);
//         }

//         @keyframes slideDown {
//           from {
//             opacity: 0;
//             transform: translateY(-10px);
//           }
//           to {
//             opacity: 1;
//             transform: translateY(0);
//           }
//         }

//         .profile-header {
//           background: linear-gradient(135deg, #667eea, #764ba2);
//           color: white;
//           padding: 1.5rem;
//           text-align: center;
//         }

//         .profile-info {
//           padding: 1.5rem;
//           max-height: 300px;
//           overflow-y: auto;
//         }

//         .profile-info p {
//           margin: 0.5rem 0;
//           font-size: 0.9rem;
//           line-height: 1.5;
//         }

//         .profile-actions {
//           border-top: 1px solid #f0f0f0;
//         }

//         .profile-action-btn {
//           width: 100%;
//           padding: 1rem 1.5rem;
//           border: none;
//           background: none;
//           text-align: left;
//           cursor: pointer;
//           font-weight: 600;
//           transition: all 0.3s ease;
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//         }

//         .profile-action-btn:hover {
//           background: rgba(102, 126, 234, 0.05);
//           transform: translateX(5px);
//         }

//         .profile-action-btn.edit {
//           color: #3498db;
//         }

//         .profile-action-btn.logout {
//           color: #e74c3c;
//           border-top: 1px solid #f0f0f0;
//         }

//         .applications-container {
//           padding: 2rem;
//         }

//         .applications-header {
//           text-align: center;
//           margin-bottom: 3rem;
//         }

//         .applications-title {
//           font-size: 2.5rem;
//           font-weight: 800;
//           color: white;
//           margin-bottom: 0.5rem;
//           text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
//         }

//         .applications-subtitle {
//           color: rgba(255, 255, 255, 0.9);
//           font-size: 1.1rem;
//           margin-bottom: 2rem;
//         }

//         .stats-grid {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
//           gap: 1.5rem;
//           margin-bottom: 2rem;
//           max-width: 800px;
//           margin-left: auto;
//           margin-right: auto;
//         }

//         .stat-card {
//           background: rgba(255, 255, 255, 0.95);
//           backdrop-filter: blur(10px);
//           border-radius: 15px;
//           padding: 1.5rem;
//           text-align: center;
//           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//           transition: transform 0.3s ease;
//           border: 1px solid rgba(255, 255, 255, 0.2);
//         }

//         .stat-card:hover {
//           transform: translateY(-2px);
//         }

//         .stat-number {
//           font-size: 2rem;
//           font-weight: 800;
//           margin-bottom: 0.5rem;
//         }

//         .stat-label {
//           font-size: 0.9rem;
//           color: #666;
//           font-weight: 600;
//         }

//         .stat-total { color: #667eea; }
//         .stat-pending { color: #f39c12; }
//         .stat-approved { color: #27ae60; }
//         .stat-rejected { color: #e74c3c; }

//         .filters-section {
//           background: rgba(255, 255, 255, 0.95);
//           backdrop-filter: blur(10px);
//           border-radius: 15px;
//           padding: 1.5rem;
//           margin-bottom: 2rem;
//           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//           max-width: 1200px;
//           margin-left: auto;
//           margin-right: auto;
//         }

//         .filters-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           margin-bottom: 1rem;
//         }

//         .filters-title {
//           font-size: 1.2rem;
//           font-weight: 700;
//           color: #333;
//         }

//         .filters-controls {
//           display: flex;
//           gap: 1rem;
//           flex-wrap: wrap;
//           align-items: center;
//         }

//         .filter-group {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//         }

//         .filter-label {
//           font-weight: 600;
//           color: #555;
//           font-size: 0.9rem;
//         }

//         .filter-select {
//           padding: 0.5rem 1rem;
//           border: 2px solid #e0e0e0;
//           border-radius: 8px;
//           background: white;
//           font-size: 0.9rem;
//           transition: all 0.3s ease;
//         }

//         .filter-select:focus {
//           border-color: #667eea;
//           outline: none;
//           box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
//         }

//         .search-box {
//           flex: 1;
//           min-width: 250px;
//           position: relative;
//         }

//         .search-input {
//           width: 100%;
//           padding: 0.75rem 1rem 0.75rem 2.5rem;
//           border: 2px solid #e0e0e0;
//           border-radius: 10px;
//           font-size: 0.9rem;
//           transition: all 0.3s ease;
//         }

//         .search-input:focus {
//           border-color: #667eea;
//           outline: none;
//           box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
//         }

//         .search-icon {
//           position: absolute;
//           left: 0.75rem;
//           top: 50%;
//           transform: translateY(-50%);
//           color: #999;
//           font-size: 1rem;
//         }

//         .applications-grid {
//           display: grid;
//           gap: 2rem;
//           max-width: 1200px;
//           margin: 0 auto;
//         }

//         .application-card {
//           background: linear-gradient(145deg, rgba(255, 255, 255, 0.98), rgba(255, 255, 255, 0.92));
//           backdrop-filter: blur(20px);
//           border-radius: 24px;
//           padding: 2.5rem;
//           box-shadow: 
//             0 8px 32px rgba(0, 0, 0, 0.08),
//             0 4px 16px rgba(0, 0, 0, 0.04),
//             inset 0 1px 0 rgba(255, 255, 255, 0.8);
//           border: 1px solid rgba(255, 255, 255, 0.4);
//           transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
//           position: relative;
//           overflow: hidden;
//         }

//         .application-card::before {
//           content: '';
//           position: absolute;
//           top: 0;
//           left: 0;
//           right: 0;
//           height: 5px;
//           background: linear-gradient(90deg, #667eea 0%, #764ba2 50%, #667eea 100%);
//           background-size: 200% 100%;
//           animation: shimmer 3s ease-in-out infinite;
//         }

//         @keyframes shimmer {
//           0% { background-position: -200% 0; }
//           100% { background-position: 200% 0; }
//         }

//         .application-card:hover {
//           transform: translateY(-8px) scale(1.02);
//           box-shadow: 
//             0 20px 60px rgba(102, 126, 234, 0.15),
//             0 12px 40px rgba(0, 0, 0, 0.08);
//         }

//         .application-header {
//           display: flex;
//           align-items: center;
//           justify-content: space-between;
//           margin-bottom: 2rem;
//           padding-bottom: 1rem;
//           border-bottom: 2px solid rgba(102, 126, 234, 0.08);
//         }

//         .applicant-info {
//           display: flex;
//           align-items: center;
//           gap: 1.5rem;
//         }

//         .applicant-avatar {
//           width: 72px;
//           height: 72px;
//           border-radius: 50%;
//           background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           color: white;
//           font-size: 1.8rem;
//           font-weight: 800;
//           box-shadow: 0 8px 24px rgba(102, 126, 234, 0.3);
//           border: 3px solid rgba(255, 255, 255, 0.9);
//         }

//         .applicant-name {
//           font-size: 1.6rem;
//           font-weight: 800;
//           color: #2c3e50;
//           margin: 0;
//         }

//         .status-badge {
//           padding: 0.5rem 1rem;
//           border-radius: 20px;
//           font-weight: 600;
//           font-size: 0.9rem;
//           text-transform: uppercase;
//           letter-spacing: 0.5px;
//         }

//         .status-pending {
//           background: rgba(243, 156, 18, 0.1);
//           color: #f39c12;
//           border: 2px solid rgba(243, 156, 18, 0.3);
//         }

//         .status-approved {
//           background: rgba(46, 204, 113, 0.1);
//           color: #27ae60;
//           border: 2px solid rgba(46, 204, 113, 0.3);
//         }

//         .status-rejected {
//           background: rgba(231, 76, 60, 0.1);
//           color: #c0392b;
//           border: 2px solid rgba(231, 76, 60, 0.3);
//         }

//         .status-processing {
//           background: rgba(52, 152, 219, 0.1);
//           color: #3498db;
//           border: 2px solid rgba(52, 152, 219, 0.3);
//           animation: pulse 2s infinite;
//         }

//         @keyframes pulse {
//           0% { opacity: 1; }
//           50% { opacity: 0.6; }
//           100% { opacity: 1; }
//         }

//         .application-details {
//           margin-bottom: 2rem;
//         }

//         .detail-row {
//           display: flex;
//           align-items: flex-start;
//           margin-bottom: 1rem;
//           padding: 0.75rem;
//           background: rgba(102, 126, 234, 0.05);
//           border-radius: 10px;
//           border-left: 4px solid #667eea;
//         }

//         .detail-label {
//           font-weight: 600;
//           color: #667eea;
//           min-width: 120px;
//           margin-right: 1rem;
//         }

//         .detail-value {
//           flex: 1;
//           color: #555;
//           line-height: 1.6;
//         }

//         .detail-link {
//           color: #667eea;
//           text-decoration: none;
//           font-weight: 500;
//           transition: color 0.3s ease;
//         }

//         .detail-link:hover {
//           color: #764ba2;
//           text-decoration: underline;
//         }

//         .interview-info {
//           background: rgba(46, 204, 113, 0.1);
//           border: 2px solid rgba(46, 204, 113, 0.3);
//           border-radius: 12px;
//           padding: 1.25rem;
//           margin-top: 1rem;
//         }

//         .interview-title {
//           font-weight: 700;
//           color: #27ae60;
//           margin-bottom: 0.75rem;
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           font-size: 1.1rem;
//         }

//         .interview-detail {
//           margin: 0.5rem 0;
//           color: #333;
//         }

//         .application-footer {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           padding-top: 1.5rem;
//           border-top: 1px solid #f0f0f0;
//         }

//         .application-date {
//           color: #888;
//           font-size: 0.9rem;
//         }

//         .application-actions {
//           display: flex;
//           gap: 1rem;
//         }

//         .action-btn {
//           padding: 0.75rem 1.5rem;
//           border: none;
//           border-radius: 25px;
//           font-weight: 600;
//           cursor: pointer;
//           transition: all 0.3s ease;
//           font-size: 0.9rem;
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//         }

//         .action-btn:disabled {
//           opacity: 0.6;
//           cursor: not-allowed;
//         }

//         .approve-btn {
//           background: linear-gradient(45deg, #2ecc71, #27ae60);
//           color: white;
//           box-shadow: 0 4px 15px rgba(46, 204, 113, 0.4);
//         }

//         .approve-btn:hover:not(:disabled) {
//           transform: translateY(-2px);
//           box-shadow: 0 6px 20px rgba(46, 204, 113, 0.6);
//         }

//         .reject-btn {
//           background: linear-gradient(45deg, #e74c3c, #c0392b);
//           color: white;
//           box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);
//         }

//         .reject-btn:hover:not(:disabled) {
//           transform: translateY(-2px);
//           box-shadow: 0 6px 20px rgba(231, 76, 60, 0.6);
//         }

//         .modal-overlay {
//           position: fixed;
//           top: 0;
//           left: 0;
//           right: 0;
//           bottom: 0;
//           background: rgba(0, 0, 0, 0.7);
//           display: flex;
//           justify-content: center;
//           align-items: center;
//           z-index: 2000;
//           backdrop-filter: blur(5px);
//         }

//         .modal-content {
//           background: white;
//           border-radius: 20px;
//           padding: 2.5rem;
//           width: 90%;
//           max-width: 600px;
//           max-height: 90vh;
//           overflow-y: auto;
//           box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
//           animation: modalSlideIn 0.3s ease-out;
//         }

//         @keyframes modalSlideIn {
//           from {
//             opacity: 0;
//             transform: scale(0.9);
//           }
//           to {
//             opacity: 1;
//             transform: scale(1);
//           }
//         }

//         .modal-header {
//           text-align: center;
//           margin-bottom: 2rem;
//           border-bottom: 2px solid rgba(102, 126, 234, 0.1);
//           padding-bottom: 1.5rem;
//         }

//         .modal-title {
//           font-size: 1.8rem;
//           font-weight: 700;
//           color: #333;
//           margin-bottom: 0.5rem;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           gap: 0.5rem;
//         }

//         .modal-subtitle {
//           color: #666;
//           font-size: 0.95rem;
//         }

//         .form-group {
//           margin-bottom: 1.5rem;
//         }

//         .form-label {
//           display: block;
//           font-weight: 600;
//           color: #333;
//           margin-bottom: 0.5rem;
//           font-size: 0.95rem;
//         }

//         .form-input, .form-textarea {
//           width: 100%;
//           padding: 0.75rem 1rem;
//           border: 2px solid #e0e0e0;
//           border-radius: 10px;
//           font-size: 0.9rem;
//           transition: all 0.3s ease;
//           background: white;
//           font-family: inherit;
//         }

//         .form-input:focus, .form-textarea:focus {
//           border-color: #667eea;
//           box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
//           outline: none;
//         }

//         .form-textarea {
//           resize: vertical;
//           min-height: 100px;
//         }

//         .date-time-row {
//           display: grid;
//           grid-template-columns: 1fr 1fr;
//           gap: 1rem;
//         }

//         .modal-actions {
//           display: flex;
//           gap: 1rem;
//           margin-top: 2rem;
//           padding-top: 1.5rem;
//           border-top: 1px solid #f0f0f0;
//         }

//         .modal-btn {
//           flex: 1;
//           padding: 0.875rem;
//           border: none;
//           border-radius: 10px;
//           font-weight: 600;
//           cursor: pointer;
//           transition: all 0.3s ease;
//           font-size: 0.95rem;
//         }

//         .save-btn {
//           background: linear-gradient(45deg, #667eea, #764ba2);
//           color: white;
//         }

//         .save-btn:hover {
//           transform: translateY(-2px);
//           box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
//         }

//         .cancel-btn {
//           background: #f8f9fa;
//           color: #666;
//           border: 2px solid #e0e0e0;
//         }

//         .cancel-btn:hover {
//           background: #e9ecef;
//           border-color: #ccc;
//         }

//         .loading-spinner {
//           display: flex;
//           justify-content: center;
//           align-items: center;
//           height: 200px;
//           font-size: 1.1rem;
//           color: rgba(255, 255, 255, 0.8);
//         }

//         .empty-state {
//           text-align: center;
//           padding: 4rem 2rem;
//           color: rgba(255, 255, 255, 0.8);
//         }

//         .empty-state-icon {
//           font-size: 4rem;
//           margin-bottom: 1rem;
//         }

//         .empty-state-title {
//           font-size: 1.5rem;
//           font-weight: 600;
//           margin-bottom: 0.5rem;
//         }

//         .empty-state-subtitle {
//           font-size: 1rem;
//         }

//         @media (max-width: 768px) {
//           .req-header-mobile {
//             display: block;
//           }

//           .req-menu-sidebar {
//             display: none;
//           }

//           .req-page-container {
//             margin-left: 0;
//           }

//           .req-header-desktop {
//             display: none;
//           }

//           .applications-container {
//             padding: 1rem;
//           }

//           .applications-title {
//             font-size: 2rem;
//           }

//           .stats-grid {
//             grid-template-columns: repeat(2, 1fr);
//             gap: 1rem;
//           }

//           .filters-controls {
//             flex-direction: column;
//             align-items: stretch;
//           }

//           .search-box {
//             min-width: auto;
//           }

//           .application-card {
//             padding: 1.5rem;
//           }

//           .application-header {
//             flex-direction: column;
//             align-items: flex-start;
//             gap: 1rem;
//           }

//           .application-actions {
//             flex-direction: column;
//             width: 100%;
//           }

//           .action-btn {
//             width: 100%;
//             justify-content: center;
//           }

//           .modal-content {
//             width: 95%;
//             margin: 1rem;
//             padding: 1.5rem;
//           }

//           .modal-actions {
//             flex-direction: column;
//           }

//           .date-time-row {
//             grid-template-columns: 1fr;
//           }
//         }

//         @media (max-width: 480px) {
//           .stats-grid {
//             grid-template-columns: 1fr;
//           }

//           .applications-title {
//             font-size: 1.8rem;
//           }

//           .stat-card {
//             padding: 1rem;
//           }

//           .filters-section {
//             padding: 1rem;
//           }
//         }
//       `}</style>

//       {/* Mobile Header */}
//       <header className="req-header-mobile">
//         <div className="req-header-mobile-bar">
//           <div className="req-header-mobile-inner">
//             <a href="#" className="req-logo">
//               JOB PORTAL
//             </a>
//             <button
//               className="req-hamburger"
//               onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
//             >
//               ☰
//             </button>
//           </div>
//         </div>
//         <nav className={`req-navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
//           <ul className="req-mobile-nav-list">
//             <li>
//               <a href="#" className="req-nav-link">
//                 📊 Dashboard
//               </a>
//             </li>
//             <li>
//               <a href="#" className="req-nav-link">
//                 📄 Pages
//               </a>
//             </li>
//             <li>
//               <button
//                 onClick={handleLogout}
//                 className="req-nav-link"
//                 style={{
//                   background: "none",
//                   border: "none",
//                   width: "100%",
//                   textAlign: "left",
//                   cursor: "pointer",
//                 }}
//               >
//                 🚪 Logout
//               </button>
//             </li>
//           </ul>
//         </nav>
//       </header>

//       {/* Desktop Sidebar */}
//       <aside className="req-menu-sidebar">
//         <div className="req-sidebar-logo">
//           <a href="#" className="req-logo">
//             JOB PORTAL
//           </a>
//         </div>
//         <nav className="req-sidebar-content">
//           <ul className="req-navbar-list">
//             <li className="req-nav-item">
//               <a href="#" className="req-nav-link active">
//                 📊 Dashboard
//               </a>
//             </li>
//           </ul>
//         </nav>
//       </aside>

//       {/* Page Container */}
//       <div className="req-page-container">
//         {/* Desktop Header */}
//         <header className="req-header-desktop">
//           <div className="req-header-wrap">
//             <div className="req-search-form">
//               <input
//                 type="text"
//                 placeholder="Search for applications & reports..."
//                 className="req-search-input"
//                 value={searchTerm}
//                 onChange={(e) => setSearchTerm(e.target.value)}
//               />
//               <button className="req-search-button">🔍</button>
//             </div>
//             <div className="req-account-wrap">
//               <div className="req-account-item">
//                 <img
//                   className="req-avatar"
//                   src={recruiterProfile?.avatar || "https://randomuser.me/api/portraits/men/75.jpg"}
//                   alt="Profile"
//                   onClick={() => setIsProfileOpen((prev) => !prev)}
//                   style={{ cursor: "pointer" }}
//                 />
//                 <a
//                   href="#"
//                   className="req-user-name"
//                   onClick={(e) => {
//                     e.preventDefault();
//                     setIsProfileOpen((prev) => !prev);
//                   }}
//                 >
//                   {recruiterName || "Recruiter"}
//                 </a>

//                 {isProfileOpen && (
//                   <>
//                     <div
//                       style={{
//                         position: "fixed",
//                         top: 0,
//                         left: 0,
//                         width: "100vw",
//                         height: "100vh",
//                         background: "transparent",
//                         zIndex: 999
//                       }}
//                       onClick={() => setIsProfileOpen(false)}
//                     />
//                     <div className="profile-dropdown">
//                       {recruiterProfile && (
//                         <div className="profile-header">
//                           <strong>
//                             {recruiterProfile.firstName}{" "}
//                             {recruiterProfile.lastName}
//                           </strong>
//                           <div style={{ opacity: 0.9, marginTop: "0.5rem" }}>
//                             {recruiterProfile.email}
//                           </div>
//                         </div>
//                       )}
                      
//                       {employerProfile ? (
//                         <div className="profile-info">
//                           <div className="detail-row">
//                             <span className="detail-label">🏢</span>
//                             <strong>{employerProfile.companyName}</strong>
//                           </div>
//                           <div className="detail-row">
//                             <span className="detail-label">📍</span>
//                             <span>{employerProfile.address}, {employerProfile.city}</span>
//                           </div>
//                           <div className="detail-row">
//                             <span className="detail-label">📞</span>
//                             <span>{employerProfile.phone}</span>
//                           </div>
//                         </div>
//                       ) : (
//                         <div className="profile-info">
//                           <div style={{ textAlign: "center", color: "#888", padding: "2rem" }}>
//                             ⚠ No employer profile found
//                           </div>
//                         </div>
//                       )}

//                       <div className="profile-actions">
//                         <button
//                           className="profile-action-btn edit"
//                           onClick={() => {
//                             setEditData(employerProfile || {});
//                             setIsEditOpen(true);
//                             setIsProfileOpen(false);
//                           }}
//                         >
//                           <span>✏</span>
//                           Edit Profile
//                         </button>

//                         <button
//                           className="profile-action-btn logout"
//                           onClick={() => {
//                             handleLogout();
//                             setIsProfileOpen(false);
//                           }}
//                         >
//                           <span>🚪</span>
//                           Logout
//                         </button>
//                       </div>
//                     </div>
//                   </>
//                 )}
//               </div>
//             </div>
//           </div>
//         </header>

//         {/* Main Content */}
//         <div className="applications-container">
//           <div className="applications-header">
//             <h1 className="applications-title">
//               Welcome back, {recruiterName || "Recruiter"}!
//             </h1>
//             <p className="applications-subtitle">
//               Manage your job applications and find the perfect candidates
//             </p>

//             <div className="stats-grid">
//               <div className="stat-card">
//                 <div className="stat-number stat-total">{statusCounts.total}</div>
//                 <div className="stat-label">Total Applications</div>
//               </div>
//               <div className="stat-card">
//                 <div className="stat-number stat-pending">{statusCounts.pending}</div>
//                 <div className="stat-label">Pending Review</div>
//               </div>
//               <div className="stat-card">
//                 <div className="stat-number stat-approved">{statusCounts.approved}</div>
//                 <div className="stat-label">Approved</div>
//               </div>
//               <div className="stat-card">
//                 <div className="stat-number stat-rejected">{statusCounts.rejected}</div>
//                 <div className="stat-label">Rejected</div>
//               </div>
//             </div>
//           </div>

//           <div className="filters-section">
//             <div className="filters-header">
//               <div className="filters-title">📋 Application Management</div>
//             </div>
//             <div className="filters-controls">
//               <div className="filter-group">
//                 <label className="filter-label">Status:</label>
//                 <select
//                   className="filter-select"
//                   value={statusFilter}
//                   onChange={(e) => setStatusFilter(e.target.value)}
//                 >
//                   <option value="all">All Applications</option>
//                   <option value="pending">Pending ({statusCounts.pending})</option>
//                   <option value="approved">Approved ({statusCounts.approved})</option>
//                   <option value="rejected">Rejected ({statusCounts.rejected})</option>
//                 </select>
//               </div>
              
//               <div className="search-box">
//                 <div className="search-icon">🔍</div>
//                 <input
//                   type="text"
//                   className="search-input"
//                   placeholder="Search by name or email..."
//                   value={searchTerm}
//                   onChange={(e) => setSearchTerm(e.target.value)}
//                 />
//               </div>
//             </div>
//           </div>

//           {loading ? (
//             <div className="loading-spinner">
//               <div>🔄 Loading applications...</div>
//             </div>
//           ) : filteredApplications.length === 0 ? (
//             <div className="empty-state">
//               <div className="empty-state-icon">
//                 {searchTerm || statusFilter !== 'all' ? '🔍' : '📋'}
//               </div>
//               <h3 className="empty-state-title">
//                 {searchTerm || statusFilter !== 'all' 
//                   ? 'No Applications Found' 
//                   : 'No Applications Yet'
//                 }
//               </h3>
//               <p className="empty-state-subtitle">
//                 {searchTerm || statusFilter !== 'all'
//                   ? 'Try adjusting your search or filter criteria'
//                   : 'Applications for your job posts will appear here'
//                 }
//               </p>
//             </div>
//           ) : (
//             <div className="applications-grid">
//               {filteredApplications.map((app) => (
//                 <div key={app._id} className="application-card">
//                   <div className="application-header">
//                     <div className="applicant-info">
//                       <div className="applicant-avatar">
//                         {app.name ? app.name.charAt(0).toUpperCase() : '👤'}
//                       </div>
//                       <div>
//                         <h3 className="applicant-name">{app.name}</h3>
//                       </div>
//                     </div>
//                     <div className={`status-badge status-${app.status}`}>
//                       {app.status === 'pending' && '⏳ Pending'}
//                       {app.status === 'approved' && '✅ Approved'}
//                       {app.status === 'rejected' && '❌ Rejected'}
//                       {app.status === 'processing' && '⚙️ Processing'}
//                     </div>
//                   </div>

//                   <div className="application-details">
//                     <div className="detail-row">
//                       <span className="detail-label">✉ Email:</span>
//                       <span className="detail-value">
//                         <a href={`mailto:${app.email}`} className="detail-link">
//                           {app.email}
//                         </a>
//                       </span>
//                     </div>

//                     {app.portfolio && (
//                       <div className="detail-row">
//                         <span className="detail-label">🌐 Portfolio:</span>
//                         <span className="detail-value">
//                           <a href={app.portfolio} target="_blank" rel="noreferrer" className="detail-link">
//                             View Portfolio
//                           </a>
//                         </span>
//                       </div>
//                     )}

//                     <div className="detail-row">
//                       <span className="detail-label">📝 Cover Letter:</span>
//                       <span className="detail-value">{app.coverLetter}</span>
//                     </div>

//                     {app.resume && (
//                       <div className="detail-row">
//                         <span className="detail-label">📄 Resume:</span>
//                         <span className="detail-value">
//                           <a href={`http://localhost:5000${app.resume}`} target="_blank" rel="noreferrer" className="detail-link">
//                             Download Resume
//                           </a>
//                         </span>
//                       </div>
//                     )}

//                     {app.status === 'approved' && (app.interviewDate || app.meetingLink) && (
//                       <div className="interview-info">
//                         <div className="interview-title">
//                           📅 Interview Scheduled
//                         </div>
//                         {app.interviewDate && (
//                           <div className="interview-detail">
//                             <strong>Date & Time:</strong> {new Date(app.interviewDate).toLocaleString('en-US', {
//                               year: 'numeric',
//                               month: 'long',
//                               day: 'numeric',
//                               hour: '2-digit',
//                               minute: '2-digit'
//                             })}
//                           </div>
//                         )}
//                         {app.meetingLink && (
//                           <div className="interview-detail">
//                             <strong>Meeting Link:</strong>{' '}
//                             <a href={app.meetingLink} target="_blank" rel="noreferrer" className="detail-link">
//                               Join Interview
//                             </a>
//                           </div>
//                         )}
//                       </div>
//                     )}
//                   </div>

//                   <div className="application-footer">
//                     <div className="application-date">
//                       📅 Applied: {new Date(app.createdAt).toLocaleDateString('en-US', {
//                         year: 'numeric',
//                         month: 'long',
//                         day: 'numeric'
//                       })}
//                     </div>

//                     <div className="application-actions">
//                       {app.status === "pending" ? (
//                         <>
//                           <button
//                             className="action-btn approve-btn"
//                             onClick={() => openScheduleModal(app)}
//                           >
//                             <span>✅</span> Schedule Interview
//                           </button>
//                           <button
//                             className="action-btn reject-btn"
//                             onClick={() => handleReject(app)}
//                           >
//                             <span>❌</span> Reject
//                           </button>
//                         </>
//                       ) : app.status === "processing" ? (
//                         <div className={`status-badge status-${app.status}`}>
//                           <span>⚙️</span> Processing...
//                         </div>
//                       ) : (
//                         <div className={`status-badge status-${app.status}`}>
//                           {app.status === "approved" ? "✅ Interview Scheduled" : "❌ Application Rejected"}
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           )}
//         </div>

//         {/* Interview Scheduling Modal */}
//         {isScheduleModalOpen && selectedApplication && (
//           <div className="modal-overlay" onClick={() => setIsScheduleModalOpen(false)}>
//             <div className="modal-content" onClick={(e) => e.stopPropagation()}>
//               <div className="modal-header">
//                 <h3 className="modal-title">
//                   <span>📅</span> Schedule Interview
//                 </h3>
//                 <p className="modal-subtitle">
//                   Schedule an interview with {selectedApplication.name}
//                 </p>
//               </div>
              
//               <form onSubmit={(e) => {
//                 e.preventDefault();
//                 handleScheduleInterview();
//               }}>
//                 <div className="date-time-row">
//                   <div className="form-group">
//                     <label className="form-label">📅 Interview Date</label>
//                     <input
//                       type="date"
//                       className="form-input"
//                       value={interviewData.date}
//                       min={getTodayDate()}
//                       onChange={(e) => setInterviewData({...interviewData, date: e.target.value})}
//                       required
//                     />
//                   </div>

//                   <div className="form-group">
//                     <label className="form-label">🕐 Interview Time</label>
//                     <input
//                       type="time"
//                       className="form-input"
//                       value={interviewData.time}
//                       onChange={(e) => setInterviewData({...interviewData, time: e.target.value})}
//                       required
//                     />
//                   </div>
//                 </div>

//                 <div className="form-group">
//                   <label className="form-label">🔗 Meeting Link</label>
//                   <input
//                     type="url"
//                     className="form-input"
//                     value={interviewData.meetingLink}
//                     onChange={(e) => setInterviewData({...interviewData, meetingLink: e.target.value})}
//                     placeholder="https://meet.google.com/abc-def-ghi"
//                     required
//                   />
//                   <small style={{ color: '#666', fontSize: '0.85rem', marginTop: '0.5rem', display: 'block' }}>
//                     Provide a Google Meet, Zoom, or Teams link for the interview
//                   </small>
//                 </div>

//                 <div className="modal-actions">
//                   <button type="submit" className="modal-btn save-btn">
//                     ✅ Schedule Interview
//                   </button>
//                   <button
//                     type="button"
//                     onClick={() => setIsScheduleModalOpen(false)}
//                     className="modal-btn cancel-btn"
//                   >
//                     ✖ Cancel
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         )}

//         {/* Edit Profile Modal */}
//         {isEditOpen && (
//           <div className="modal-overlay" onClick={() => setIsEditOpen(false)}>
//             <div className="modal-content" onClick={(e) => e.stopPropagation()}>
//               <div className="modal-header">
//                 <h3 className="modal-title">
//                   <span>✏</span> Edit Employer Profile
//                 </h3>
//                 <p className="modal-subtitle">
//                   Update your company information
//                 </p>
//               </div>
              
//               <form onSubmit={(e) => {
//                 e.preventDefault();
//                 handleSaveProfile();
//               }}>
//                 {profileFields.map(({ key, label }) => (
//                   <div key={key} className="form-group">
//                     <label className="form-label">{label}</label>
//                     {key === 'description' ? (
//                       <textarea
//                         className="form-textarea"
//                         value={editData?.[key] || ""}
//                         onChange={(e) => setEditData({ ...editData, [key]: e.target.value })}
//                         placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
//                       />
//                     ) : (
//                       <input
//                         type={key === 'email' ? 'email' : key === 'website' || key === 'linkedin' ? 'url' : 'text'}
//                         className="form-input"
//                         value={editData?.[key] || ""}
//                         onChange={(e) => setEditData({ ...editData, [key]: e.target.value })}
//                         placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
//                       />
//                     )}
//                   </div>
//                 ))}

//                 <div className="modal-actions">
//                   <button type="submit" className="modal-btn save-btn">
//                     💾 Save Changes
//                   </button>
//                   <button
//                     type="button"
//                     onClick={() => setIsEditOpen(false)}
//                     className="modal-btn cancel-btn"
//                   >
//                     ✖ Cancel
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Req_Dashboard;

import React, { useState, useEffect } from "react";

const Req_Dashboard = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [recruiterName, setRecruiterName] = useState("");
  const [recruiterProfile, setRecruiterProfile] = useState(null);
  const [employerProfile, setEmployerProfile] = useState(null);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editData, setEditData] = useState({});
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentView, setCurrentView] = useState('dashboard');
  
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [interviewData, setInterviewData] = useState({
    date: '',
    time: '',
    meetingLink: ''
  });

  const handleLogout = () => {
    localStorage.removeItem("user");
    window.location.href = "/";
  };

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser && storedUser.id) {
      fetch(`http://localhost:5000/api/applications/by-user/${storedUser.id}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success) setApplications(data.applications);
          setLoading(false);
        })
        .catch((err) => {
          console.error("Error fetching applications:", err);
          setLoading(false);
        });
    }
  }, []);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      const fullName = storedUser.firstName
        ? `${storedUser.firstName} ${storedUser.lastName || ""}`
        : storedUser.name || "";
      setRecruiterName(fullName);
      setRecruiterProfile(storedUser);

      fetch(`http://localhost:5000/api/profile/employer/${storedUser.id}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success) setEmployerProfile(data.profile);
        })
        .catch((err) => console.error(err));
    }
  }, []);

  const handleSaveProfile = async () => {
    try {
      const res = await fetch(
        `http://localhost:5000/api/profile/employer/${recruiterProfile.id}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(editData),
        }
      );
      const data = await res.json();
      if (data.success) {
        setEmployerProfile(data.profile);
        setIsEditOpen(false);
        showNotification("Profile updated successfully! ✅", "success");
      } else {
        showNotification("Error updating profile: " + data.message, "error");
      }
    } catch (err) {
      console.error(err);
      showNotification("❌ Failed to update profile", "error");
    }
  };

  const openScheduleModal = (app) => {
    setSelectedApplication(app);
    setInterviewData({
      date: '',
      time: '',
      meetingLink: ''
    });
    setIsScheduleModalOpen(true);
  };

  const handleScheduleInterview = () => {
    const { date, time, meetingLink } = interviewData;

    if (!date || !time || !meetingLink) {
      showNotification("Please fill in all interview details", "error");
      return;
    }

    const dateTime = `${date}T${time}`;

    setApplications(prev => 
      prev.map(a => a._id === selectedApplication._id ? { ...a, status: "processing" } : a)
    );

    fetch(`http://localhost:5000/api/applications/${selectedApplication._id}/approve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ date: dateTime, meetingLink }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setApplications(prev => 
            prev.map(a => a._id === selectedApplication._id ? { 
              ...a, 
              status: "approved", 
              interviewDate: dateTime, 
              meetingLink: meetingLink 
            } : a)
          );
          showNotification("Interview scheduled successfully! ✅", "success");
          setIsScheduleModalOpen(false);
          setSelectedApplication(null);
        } else {
          setApplications(prev => 
            prev.map(a => a._id === selectedApplication._id ? { ...a, status: "pending" } : a)
          );
          showNotification("Error: " + data.message, "error");
        }
      })
      .catch(err => {
        console.error(err);
        setApplications(prev => 
          prev.map(a => a._id === selectedApplication._id ? { ...a, status: "pending" } : a)
        );
        showNotification("Failed to schedule interview ❌", "error");
      });
  };

  const handleReject = (app) => {
    if (window.confirm("Are you sure you want to reject this application?")) {
      setApplications(prev => 
        prev.map(a => a._id === app._id ? { ...a, status: "processing" } : a)
      );

      fetch(`http://localhost:5000/api/applications/${app._id}/reject`, {
        method: "POST",
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            setApplications(prev => 
              prev.map(a => a._id === app._id ? { ...a, status: "rejected" } : a)
            );
            showNotification("Application rejected", "info");
          } else {
            setApplications(prev => 
              prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
            );
            showNotification("Error: " + data.message, "error");
          }
        })
        .catch(err => {
          console.error(err);
          setApplications(prev => 
            prev.map(a => a._id === app._id ? { ...a, status: "pending" } : a)
          );
          showNotification("Failed to reject application ❌", "error");
        });
    }
  };

  const showNotification = (message, type = "info") => {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.classList.add('show');
    }, 100);

    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 300);
    }, 3000);
  };

  const filteredApplications = applications.filter(app => {
    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    const matchesSearch = app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.email.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const statusCounts = {
    total: applications.length,
    pending: applications.filter(app => app.status === 'pending').length,
    approved: applications.filter(app => app.status === 'approved').length,
    rejected: applications.filter(app => app.status === 'rejected').length,
    processing: applications.filter(app => app.status === 'processing').length,
  };

  const profileFields = [
    { key: "companyName", label: "🏢 Company Name" },
    { key: "website", label: "🌐 Website" },
    { key: "industry", label: "🏭 Industry" },
    { key: "companySize", label: "👥 Company Size" },
    { key: "phone", label: "📞 Phone" },
    { key: "email", label: "✉ Email" },
    { key: "address", label: "📍 Address" },
    { key: "city", label: "🏙 City" },
    { key: "state", label: "🗺 State" },
    { key: "country", label: "🌎 Country" },
    { key: "linkedin", label: "🔗 LinkedIn" },
    { key: "logo", label: "🖼 Logo URL" },
    { key: "description", label: "📝 Description" },
  ];

  const getTodayDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  return (
    <div className="req-page-wrapper">
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          overflow-x: hidden;
        }

        .req-page-wrapper {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          background: #f8f9fe;
          min-height: 100vh;
        }

        .notification {
          position: fixed;
          top: 20px;
          right: 20px;
          padding: 1rem 1.5rem;
          border-radius: 12px;
          color: white;
          font-weight: 600;
          z-index: 10000;
          transform: translateX(400px);
          transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
          max-width: 350px;
        }

        .notification.show {
          transform: translateX(0);
        }

        .notification-success {
          background: linear-gradient(135deg, #10b981, #059669);
        }

        .notification-error {
          background: linear-gradient(135deg, #ef4444, #dc2626);
        }

        .notification-info {
          background: linear-gradient(135deg, #3b82f6, #2563eb);
        }

        .req-header-mobile {
          display: none;
        }

        .req-menu-sidebar {
          width: 280px;
          background: white;
          height: 100vh;
          position: fixed;
          left: 0;
          top: 0;
          z-index: 1000;
          box-shadow: 2px 0 20px rgba(0, 0, 0, 0.05);
          border-right: 1px solid #e5e7eb;
          overflow-y: auto;
        }

        .req-sidebar-logo {
          padding: 2rem 1.5rem;
          border-bottom: 1px solid #e5e7eb;
        }

        .req-logo {
          font-size: 1.5rem;
          font-weight: 800;
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          text-decoration: none;
          letter-spacing: -0.5px;
        }

        .req-sidebar-content {
          padding: 1.5rem 0;
        }

        .req-navbar-list {
          list-style: none;
          padding: 0;
          margin: 0;
        }

        .req-nav-item {
          margin-bottom: 0.5rem;
        }

        .req-nav-link {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 0.875rem 1.5rem;
          color: #64748b;
          text-decoration: none;
          transition: all 0.2s ease;
          font-weight: 500;
          font-size: 0.95rem;
          border: none;
          background: none;
          width: 100%;
          text-align: left;
          cursor: pointer;
        }

        .req-nav-link:hover {
          background: #f1f5f9;
          color: #6366f1;
        }

        .req-nav-link.active {
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          color: white;
          margin: 0 0.75rem;
          border-radius: 12px;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.25);
        }

        .nav-divider {
          height: 1px;
          background: #e5e7eb;
          margin: 1rem 1.5rem;
        }

        .nav-section-title {
          padding: 1rem 1.5rem 0.5rem;
          font-size: 0.75rem;
          font-weight: 700;
          color: #94a3b8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .req-page-container {
          margin-left: 280px;
          min-height: 100vh;
          background: #f8f9fe;
        }

        .req-header-desktop {
          background: white;
          padding: 1.25rem 2rem;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          position: sticky;
          top: 0;
          z-index: 999;
          border-bottom: 1px solid #e5e7eb;
        }

        .req-header-wrap {
          display: flex;
          justify-content: space-between;
          align-items: center;
          max-width: 1600px;
          margin: 0 auto;
        }

        .req-search-form {
          display: flex;
          align-items: center;
          background: #f8f9fe;
          border-radius: 12px;
          padding: 0.625rem 1rem;
          transition: all 0.2s ease;
          border: 2px solid transparent;
          width: 400px;
        }

        .req-search-form:focus-within {
          border-color: #6366f1;
          background: white;
          box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
        }

        .req-search-input {
          border: none;
          outline: none;
          background: transparent;
          padding: 0.5rem;
          width: 100%;
          font-size: 0.9rem;
          color: #1e293b;
        }

        .req-search-input::placeholder {
          color: #94a3b8;
        }

        .req-search-button {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 1.1rem;
          color: #6366f1;
          transition: transform 0.2s ease;
        }

        .req-search-button:hover {
          transform: scale(1.1);
        }

        .req-account-wrap {
          display: flex;
          align-items: center;
        }

        .req-account-item {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          cursor: pointer;
          padding: 0.5rem 1rem;
          border-radius: 12px;
          transition: all 0.2s ease;
          position: relative;
        }

        .req-account-item:hover {
          background: #f8f9fe;
        }

        .req-avatar {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          object-fit: cover;
          border: 2px solid #6366f1;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.2);
        }

        .req-user-name {
          font-weight: 600;
          color: #1e293b;
          text-decoration: none;
          font-size: 0.95rem;
        }

        .profile-dropdown {
          position: absolute;
          top: 65px;
          right: 0;
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
          min-width: 320px;
          overflow: hidden;
          z-index: 1000;
          animation: slideDown 0.3s ease-out;
          border: 1px solid #e5e7eb;
        }

        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .profile-header {
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          color: white;
          padding: 1.75rem;
          text-align: center;
        }

        .profile-info {
          padding: 1.5rem;
          max-height: 300px;
          overflow-y: auto;
        }

        .profile-info p {
          margin: 0.5rem 0;
          font-size: 0.9rem;
          line-height: 1.6;
          color: #475569;
        }

        .profile-actions {
          border-top: 1px solid #e5e7eb;
        }

        .profile-action-btn {
          width: 100%;
          padding: 1rem 1.5rem;
          border: none;
          background: none;
          text-align: left;
          cursor: pointer;
          font-weight: 600;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          gap: 0.75rem;
          font-size: 0.9rem;
        }

        .profile-action-btn:hover {
          background: #f8f9fe;
        }

        .profile-action-btn.edit {
          color: #3b82f6;
        }

        .profile-action-btn.logout {
          color: #ef4444;
          border-top: 1px solid #e5e7eb;
        }

        .applications-container {
          padding: 2.5rem;
          max-width: 1600px;
          margin: 0 auto;
        }

        .applications-header {
          margin-bottom: 2.5rem;
        }

        .applications-title {
          font-size: 2rem;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 0.5rem;
        }

        .applications-subtitle {
          color: #64748b;
          font-size: 1rem;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 1.5rem;
          margin: 2rem 0;
        }

        .stat-card {
          background: white;
          border-radius: 16px;
          padding: 1.75rem;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          border: 1px solid #e5e7eb;
          position: relative;
          overflow: hidden;
        }

        .stat-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          transition: opacity 0.3s ease;
          opacity: 0;
        }

        .stat-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
        }

        .stat-card:hover::before {
          opacity: 1;
        }

        .stat-card:nth-child(1)::before {
          background: linear-gradient(90deg, #6366f1, #8b5cf6);
        }

        .stat-card:nth-child(2)::before {
          background: linear-gradient(90deg, #f59e0b, #ef4444);
        }

        .stat-card:nth-child(3)::before {
          background: linear-gradient(90deg, #10b981, #059669);
        }

        .stat-card:nth-child(4)::before {
          background: linear-gradient(90deg, #ef4444, #dc2626);
        }

        .stat-number {
          font-size: 2.5rem;
          font-weight: 800;
          margin-bottom: 0.5rem;
          line-height: 1;
        }

        .stat-label {
          font-size: 0.875rem;
          color: #64748b;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .stat-total { color: #6366f1; }
        .stat-pending { color: #f59e0b; }
        .stat-approved { color: #10b981; }
        .stat-rejected { color: #ef4444; }

        .quick-actions-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1.5rem;
          margin-top: 2rem;
        }

        .action-card {
          background: white;
          border-radius: 16px;
          padding: 2rem;
          border: 1px solid #e5e7eb;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .action-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
        }

        .action-card-icon {
          font-size: 3rem;
          margin-bottom: 1rem;
        }

        .action-card-title {
          font-size: 1.25rem;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 0.5rem;
        }

        .action-card-desc {
          color: #64748b;
          font-size: 0.95rem;
        }

        .section-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin: 2.5rem 0 1.5rem;
        }

        .section-title {
          font-size: 1.5rem;
          font-weight: 700;
          color: #0f172a;
        }

        .view-all-btn {
          background: none;
          border: none;
          color: #6366f1;
          fontWeight: 600;
          cursor: pointer;
          fontSize: 0.95rem;
          transition: color 0.2s ease;
        }

        .view-all-btn:hover {
          color: #8b5cf6;
        }

        .filters-section {
          background: white;
          border-radius: 16px;
          padding: 1.5rem;
          margin-bottom: 2rem;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          border: 1px solid #e5e7eb;
        }

        .filters-controls {
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
          align-items: center;
        }

        .filter-group {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .filter-label {
          font-weight: 600;
          color: #475569;
          font-size: 0.875rem;
        }

        .filter-select {
          padding: 0.625rem 1rem;
          border: 2px solid #e5e7eb;
          border-radius: 10px;
          background: white;
          font-size: 0.875rem;
          transition: all 0.2s ease;
          color: #1e293b;
          font-weight: 500;
        }

        .filter-select:focus {
          border-color: #6366f1;
          outline: none;
          box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
        }

        .search-box {
          flex: 1;
          min-width: 280px;
          position: relative;
        }

        .search-input {
          width: 100%;
          padding: 0.75rem 1rem 0.75rem 2.75rem;
          border: 2px solid #e5e7eb;
          border-radius: 12px;
          font-size: 0.875rem;
          transition: all 0.2s ease;
          background: #f8f9fe;
        }

        .search-input:focus {
          border-color: #6366f1;
          outline: none;
          background: white;
          box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
        }

        .search-icon {
          position: absolute;
          left: 1rem;
          top: 50%;
          transform: translateY(-50%);
          color: #94a3b8;
          font-size: 1rem;
        }

        .applications-grid {
          display: grid;
          gap: 1.5rem;
        }

        .application-card {
          background: white;
          border-radius: 16px;
          padding: 2rem;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          border: 1px solid #e5e7eb;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .application-card:hover {
          box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
          transform: translateY(-2px);
        }

        .application-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 1.5rem;
          padding-bottom: 1.5rem;
          border-bottom: 1px solid #e5e7eb;
        }

        .applicant-info {
          display: flex;
          align-items: center;
          gap: 1.25rem;
        }

        .applicant-avatar {
          width: 56px;
          height: 56px;
          border-radius: 12px;
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.5rem;
          font-weight: 700;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.25);
        }

        .applicant-name {
          font-size: 1.25rem;
          font-weight: 700;
          color: #0f172a;
          margin: 0;
        }

        .status-badge {
          padding: 0.5rem 1rem;
          border-radius: 10px;
          font-weight: 600;
          font-size: 0.8rem;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .status-pending {
          background: #fef3c7;
          color: #92400e;
        }

        .status-approved {
          background: #d1fae5;
          color: #065f46;
        }

        .status-rejected {
          background: #fee2e2;
          color: #991b1b;
        }

        .status-processing {
          background: #dbeafe;
          color: #1e40af;
          animation: pulse 2s infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }

        .application-details {
          margin-bottom: 1.5rem;
        }

        .detail-row {
          display: flex;
          align-items: flex-start;
          margin-bottom: 1rem;
          padding: 1rem;
          background: #f8f9fe;
          border-radius: 10px;
          border-left: 3px solid #6366f1;
        }

        .detail-label {
          font-weight: 600;
          color: #6366f1;
          min-width: 140px;
          margin-right: 1rem;
          font-size: 0.875rem;
        }

        .detail-value {
          flex: 1;
          color: #475569;
          line-height: 1.6;
          font-size: 0.875rem;
        }

        .detail-link {
          color: #6366f1;
          text-decoration: none;
          font-weight: 600;
          transition: color 0.2s ease;
        }

        .detail-link:hover {
          color: #8b5cf6;
          text-decoration: underline;
        }

        .interview-info {
          background: linear-gradient(135deg, #ecfdf5, #d1fae5);
          border: 2px solid #a7f3d0;
          border-radius: 12px;
          padding: 1.25rem;
          margin-top: 1rem;
        }

        .interview-title {
          font-weight: 700;
          color: #065f46;
          margin-bottom: 0.75rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 1rem;
        }

        .interview-detail {
          margin: 0.5rem 0;
          color: #064e3b;
          font-size: 0.875rem;
        }

        .application-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: 1.5rem;
          border-top: 1px solid #e5e7eb;
        }

        .application-date {
          color: #94a3b8;
          font-size: 0.875rem;
          font-weight: 500;
        }

        .application-actions {
          display: flex;
          gap: 0.75rem;
        }

        .action-btn {
          padding: 0.625rem 1.25rem;
          border: none;
          border-radius: 10px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          font-size: 0.875rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .action-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .approve-btn {
          background: linear-gradient(135deg, #10b981, #059669);
          color: white;
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
        }

        .approve-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(16, 185, 129, 0.4);
        }

        .reject-btn {
          background: linear-gradient(135deg, #ef4444, #dc2626);
          color: white;
          box-shadow: 0 4px 12px rgba(239, 68, 68, 0.25);
        }

        .reject-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(239, 68, 68, 0.4);
        }

        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.6);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 2000;
          backdrop-filter: blur(4px);
        }

        .modal-content {
          background: white;
          border-radius: 20px;
          padding: 2.5rem;
          width: 90%;
          max-width: 600px;
          max-height: 90vh;
          overflow-y: auto;
          box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
          animation: modalSlideIn 0.3s ease-out;
        }

        @keyframes modalSlideIn {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        .modal-header {
          text-align: center;
          margin-bottom: 2rem;
          padding-bottom: 1.5rem;
          border-bottom: 2px solid #e5e7eb;
        }

        .modal-title {
          font-size: 1.75rem;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 0.5rem;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
        }

        .modal-subtitle {
          color: #64748b;
          font-size: 0.95rem;
        }

        .form-group {
          margin-bottom: 1.5rem;
        }

        .form-label {
          display: block;
          font-weight: 600;
          color: #0f172a;
          margin-bottom: 0.5rem;
          font-size: 0.9rem;
        }

        .form-input, .form-textarea {
          width: 100%;
          padding: 0.875rem 1rem;
          border: 2px solid #e5e7eb;
          border-radius: 12px;
          font-size: 0.9rem;
          transition: all 0.2s ease;
          background: white;
          font-family: inherit;
          color: #1e293b;
        }

        .form-input:focus, .form-textarea:focus {
          border-color: #6366f1;
          box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
          outline: none;
        }

        .form-textarea {
          resize: vertical;
          min-height: 120px;
        }

        .date-time-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .modal-actions {
          display: flex;
          gap: 1rem;
          margin-top: 2rem;
          padding-top: 1.5rem;
          border-top: 1px solid #e5e7eb;
        }

        .modal-btn {
          flex: 1;
          padding: 1rem;
          border: none;
          border-radius: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          font-size: 0.95rem;
        }

        .save-btn {
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          color: white;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }

        .save-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(99, 102, 241, 0.4);
        }

        .cancel-btn {
          background: #f1f5f9;
          color: #64748b;
          border: 2px solid #e5e7eb;
        }

        .cancel-btn:hover {
          background: #e2e8f0;
          color: #475569;
        }

        .loading-spinner {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 300px;
          font-size: 1.1rem;
          color: #64748b;
        }

        .empty-state {
          text-align: center;
          padding: 4rem 2rem;
          background: white;
          border-radius: 16px;
          border: 2px dashed #e5e7eb;
        }

        .empty-state-icon {
          font-size: 4rem;
          margin-bottom: 1rem;
          opacity: 0.5;
        }

        .empty-state-title {
          font-size: 1.5rem;
          font-weight: 700;
          margin-bottom: 0.5rem;
          color: #0f172a;
        }

        .empty-state-subtitle {
          font-size: 1rem;
          color: #64748b;
        }

        @media (max-width: 1024px) {
          .stats-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 768px) {
          .req-header-mobile {
            display: block;
            background: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid #e5e7eb;
          }

          .req-header-mobile-bar {
            padding: 1rem;
          }

          .req-header-mobile-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
          }

          .req-hamburger {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #6366f1;
            transition: transform 0.2s ease;
          }

          .req-hamburger:hover {
            transform: scale(1.1);
          }

          .req-navbar-mobile {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            background: white;
          }

          .req-navbar-mobile.open {
            max-height: 300px;
            border-top: 1px solid #e5e7eb;
          }

          .req-mobile-nav-list {
            list-style: none;
            padding: 0;
            margin: 0;
          }

          .req-mobile-nav-list li {
            border-bottom: 1px solid #f1f5f9;
          }

          .req-menu-sidebar {
            display: none;
          }

          .req-page-container {
            margin-left: 0;
          }

          .req-header-desktop {
            display: none;
          }

          .applications-container {
            padding: 1.5rem;
          }

          .applications-title {
            font-size: 1.75rem;
          }

          .stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
          }

          .stat-card {
            padding: 1.25rem;
          }

          .stat-number {
            font-size: 2rem;
          }

          .filters-controls {
            flex-direction: column;
            align-items: stretch;
          }

          .filter-group {
            width: 100%;
          }

          .filter-select {
            width: 100%;
          }

          .search-box {
            min-width: auto;
          }

          .application-card {
            padding: 1.5rem;
          }

          .application-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }

          .application-actions {
            flex-direction: column;
            width: 100%;
          }

          .action-btn {
            width: 100%;
            justify-content: center;
          }

          .modal-content {
            width: 95%;
            margin: 1rem;
            padding: 1.5rem;
          }

          .modal-actions {
            flex-direction: column;
          }

          .date-time-row {
            grid-template-columns: 1fr;
          }

          .quick-actions-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 480px) {
          .stats-grid {
            grid-template-columns: 1fr;
          }

          .applications-title {
            font-size: 1.5rem;
          }

          .stat-card {
            padding: 1rem;
          }

          .filters-section {
            padding: 1rem;
          }

          .application-card {
            padding: 1.25rem;
          }

          .applicant-name {
            font-size: 1.1rem;
          }
        }
      `}</style>

      {/* Mobile Header */}
      <header className="req-header-mobile">
        <div className="req-header-mobile-bar">
          <div className="req-header-mobile-inner">
            <a href="#" className="req-logo">
              JOB PORTAL
            </a>
            <button
              className="req-hamburger"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              ☰
            </button>
          </div>
        </div>
        <nav className={`req-navbar-mobile ${isMobileMenuOpen ? "open" : ""}`}>
          <ul className="req-mobile-nav-list">
            <li>
              <button
                onClick={() => {
                  setCurrentView('dashboard');
                  setIsMobileMenuOpen(false);
                }}
                className="req-nav-link"
                style={{
                  background: "none",
                  border: "none",
                  width: "100%",
                  textAlign: "left",
                  cursor: "pointer",
                }}
              >
                📊 Dashboard
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  setCurrentView('applications');
                  setIsMobileMenuOpen(false);
                }}
                className="req-nav-link"
                style={{
                  background: "none",
                  border: "none",
                  width: "100%",
                  textAlign: "left",
                  cursor: "pointer",
                }}
              >
                📋 Applications
              </button>
            </li>
            <li>
              <button
                onClick={handleLogout}
                className="req-nav-link"
                style={{
                  background: "none",
                  border: "none",
                  width: "100%",
                  textAlign: "left",
                  cursor: "pointer",
                }}
              >
                🚪 Logout
              </button>
            </li>
          </ul>
        </nav>
      </header>

      {/* Desktop Sidebar */}
      <aside className="req-menu-sidebar">
        <div className="req-sidebar-logo">
          <a href="#" className="req-logo">
            JOB PORTAL
          </a>
        </div>
        <nav className="req-sidebar-content">
          <ul className="req-navbar-list">
            <li className="req-nav-item">
              <button 
                className={`req-nav-link ${currentView === 'dashboard' ? 'active' : ''}`}
                onClick={() => setCurrentView('dashboard')}
              >
                📊 Dashboard
              </button>
            </li>
            <li className="req-nav-item">
              <button 
                className={`req-nav-link ${currentView === 'applications' ? 'active' : ''}`}
                onClick={() => setCurrentView('applications')}
              >
                📋 Applications
              </button>
            </li>
          </ul>
          
          <div className="nav-divider"></div>
          
          <div className="nav-section-title">Quick Actions</div>
          {/* <ul className="req-navbar-list">
            <li className="req-nav-item">
              <button className="req-nav-link">
                ➕ Post New Job
              </button>
            </li>
            <li className="req-nav-item">
              <button className="req-nav-link">
                👥 View Candidates
              </button>
            </li>
            <li className="req-nav-item">
              <button className="req-nav-link">
                📊 Reports
              </button>
            </li>
          </ul> */}
          <ul className="req-navbar-list">
            <li className="req-nav-item">
              <button className="req-nav-link">
                ⚙️ Settings
              </button>
            </li>
            <li className="req-nav-item">
              <button className="req-nav-link" onClick={handleLogout}>
                🚪 Logout
              </button>
            </li>
          </ul>
          <div className="nav-divider"></div>
          
          
        </nav>
      </aside>

      {/* Page Container */}
      <div className="req-page-container">
        {/* Desktop Header */}
        <header className="req-header-desktop">
          <div className="req-header-wrap">
            <div className="req-search-form">
              <input
                type="text"
                placeholder="Search applications..."
                className="req-search-input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <button className="req-search-button">🔍</button>
            </div>
            <div className="req-account-wrap">
              <div className="req-account-item">
                <img
                  className="req-avatar"
                  src={recruiterProfile?.avatar || "https://randomuser.me/api/portraits/men/75.jpg"}
                  alt="Profile"
                  onClick={() => setIsProfileOpen((prev) => !prev)}
                  style={{ cursor: "pointer" }}
                />
                <a
                  href="#"
                  className="req-user-name"
                  onClick={(e) => {
                    e.preventDefault();
                    setIsProfileOpen((prev) => !prev);
                  }}
                >
                  {recruiterName || "Recruiter"}
                </a>

                {isProfileOpen && (
                  <>
                    <div
                      style={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100vw",
                        height: "100vh",
                        background: "transparent",
                        zIndex: 999
                      }}
                      onClick={() => setIsProfileOpen(false)}
                    />
                    <div className="profile-dropdown">
                      {recruiterProfile && (
                        <div className="profile-header">
                          <strong>
                            {recruiterProfile.firstName}{" "}
                            {recruiterProfile.lastName}
                          </strong>
                          <div style={{ opacity: 0.9, marginTop: "0.5rem" }}>
                            {recruiterProfile.email}
                          </div>
                        </div>
                      )}
                      
                      {employerProfile ? (
                        <div className="profile-info">
                          <div className="detail-row">
                            <span className="detail-label">🏢</span>
                            <strong>{employerProfile.companyName}</strong>
                          </div>
                          <div className="detail-row">
                            <span className="detail-label">📍</span>
                            <span>{employerProfile.address}, {employerProfile.city}</span>
                          </div>
                          <div className="detail-row">
                            <span className="detail-label">📞</span>
                            <span>{employerProfile.phone}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="profile-info">
                          <div style={{ textAlign: "center", color: "#888", padding: "2rem" }}>
                            ⚠ No employer profile found
                          </div>
                        </div>
                      )}

                      <div className="profile-actions">
                        <button
                          className="profile-action-btn edit"
                          onClick={() => {
                            setEditData(employerProfile || {});
                            setIsEditOpen(true);
                            setIsProfileOpen(false);
                          }}
                        >
                          <span>✏</span>
                          Edit Profile
                        </button>

                        <button
                          className="profile-action-btn logout"
                          onClick={() => {
                            handleLogout();
                            setIsProfileOpen(false);
                          }}
                        >
                          <span>🚪</span>
                          Logout
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="applications-container">
          {currentView === 'dashboard' ? (
            // Dashboard View
            <>
              <div className="applications-header">
                <h1 className="applications-title">
                  Welcome back, {recruiterName || "Recruiter"}!
                </h1>
                <p className="applications-subtitle">
                  Here's an overview of your recruitment activities
                </p>

                <div className="stats-grid">
                  <div className="stat-card">
                    <div className="stat-number stat-total">{statusCounts.total}</div>
                    <div className="stat-label">Total Applications</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-number stat-pending">{statusCounts.pending}</div>
                    <div className="stat-label">Pending Review</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-number stat-approved">{statusCounts.approved}</div>
                    <div className="stat-label">Approved</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-number stat-rejected">{statusCounts.rejected}</div>
                    <div className="stat-label">Rejected</div>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              {/* <div className="quick-actions-grid">
                <div className="action-card" onClick={() => setCurrentView('applications')}>
                  <div className="action-card-icon">📋</div>
                  <h3 className="action-card-title">View All Applications</h3>
                  <p className="action-card-desc">
                    Review and manage all job applications in one place
                  </p>
                </div>

                <div className="action-card">
                  <div className="action-card-icon">➕</div>
                  <h3 className="action-card-title">Post New Job</h3>
                  <p className="action-card-desc">
                    Create and publish a new job posting to attract candidates
                  </p>
                </div>

                <div className="action-card">
                  <div className="action-card-icon">📊</div>
                  <h3 className="action-card-title">View Reports</h3>
                  <p className="action-card-desc">
                    Access detailed analytics and hiring reports
                  </p>
                </div>
              </div> */}

              {/* Recent Applications */}
              {applications.length > 0 && (
                <div>
                  <div className="section-header">
                    <h2 className="section-title">Recent Applications</h2>
                    <button 
                      className="view-all-btn"
                      onClick={() => setCurrentView('applications')}
                    >
                      View All →
                    </button>
                  </div>
                  <div className="applications-grid">
                    {applications.slice(0, 3).map((app) => (
                      <div key={app._id} className="application-card">
                        <div className="application-header">
                          <div className="applicant-info">
                            <div className="applicant-avatar">
                              {app.name ? app.name.charAt(0).toUpperCase() : '👤'}
                            </div>
                            <div>
                              <h3 className="applicant-name">{app.name}</h3>
                            </div>
                          </div>
                          <div className={`status-badge status-${app.status}`}>
                            {app.status === 'pending' && '⏳ Pending'}
                            {app.status === 'approved' && '✅ Approved'}
                            {app.status === 'rejected' && '❌ Rejected'}
                            {app.status === 'processing' && '⚙️ Processing'}
                          </div>
                        </div>

                        <div className="application-details">
                          <div className="detail-row">
                            <span className="detail-label">✉ Email:</span>
                            <span className="detail-value">
                              <a href={`mailto:${app.email}`} className="detail-link">
                                {app.email}
                              </a>
                            </span>
                          </div>
                        </div>

                        <div className="application-footer">
                          <div className="application-date">
                            📅 Applied: {new Date(app.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </div>
                          <button 
                            onClick={() => setCurrentView('applications')}
                            style={{
                              padding: '0.5rem 1rem',
                              background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                              color: 'white',
                              border: 'none',
                              borderRadius: '8px',
                              fontWeight: '600',
                              cursor: 'pointer',
                              fontSize: '0.875rem'
                            }}
                          >
                            View Details →
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            // Applications View
            <>
              <div className="applications-header">
                <h1 className="applications-title">
                  All Applications
                </h1>
                <p className="applications-subtitle">
                  Manage your job applications and find the perfect candidates
                </p>

                <div className="stats-grid">
                  <div className="stat-card">
                    <div className="stat-number stat-total">{statusCounts.total}</div>
                    <div className="stat-label">Total Applications</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-number stat-pending">{statusCounts.pending}</div>
                    <div className="stat-label">Pending Review</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-number stat-approved">{statusCounts.approved}</div>
                    <div className="stat-label">Approved</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-number stat-rejected">{statusCounts.rejected}</div>
                    <div className="stat-label">Rejected</div>
                  </div>
                </div>
              </div>

              <div className="filters-section">
                <div className="filters-controls">
                  <div className="filter-group">
                    <label className="filter-label">Filter by Status:</label>
                    <select
                      className="filter-select"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <option value="all">All Applications</option>
                      <option value="pending">Pending ({statusCounts.pending})</option>
                      <option value="approved">Approved ({statusCounts.approved})</option>
                      <option value="rejected">Rejected ({statusCounts.rejected})</option>
                    </select>
                  </div>
                  
                  <div className="search-box">
                    <div className="search-icon">🔍</div>
                    <input
                      type="text"
                      className="search-input"
                      placeholder="Search by name or email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {loading ? (
                <div className="loading-spinner">
                  <div>🔄 Loading applications...</div>
                </div>
              ) : filteredApplications.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-state-icon">
                    {searchTerm || statusFilter !== 'all' ? '🔍' : '📋'}
                  </div>
                  <h3 className="empty-state-title">
                    {searchTerm || statusFilter !== 'all' 
                      ? 'No Applications Found' 
                      : 'No Applications Yet'
                    }
                  </h3>
                  <p className="empty-state-subtitle">
                    {searchTerm || statusFilter !== 'all'
                      ? 'Try adjusting your search or filter criteria'
                      : 'Applications for your job posts will appear here'
                    }
                  </p>
                </div>
              ) : (
                <div className="applications-grid">
                  {filteredApplications.map((app) => (
                    <div key={app._id} className="application-card">
                      <div className="application-header">
                        <div className="applicant-info">
                          <div className="applicant-avatar">
                            {app.name ? app.name.charAt(0).toUpperCase() : '👤'}
                          </div>
                          <div>
                            <h3 className="applicant-name">{app.name}</h3>
                          </div>
                        </div>
                        <div className={`status-badge status-${app.status}`}>
                          {app.status === 'pending' && '⏳ Pending'}
                          {app.status === 'approved' && '✅ Approved'}
                          {app.status === 'rejected' && '❌ Rejected'}
                          {app.status === 'processing' && '⚙️ Processing'}
                        </div>
                      </div>

                      <div className="application-details">
                        <div className="detail-row">
                          <span className="detail-label">✉ Email:</span>
                          <span className="detail-value">
                            <a href={`mailto:${app.email}`} className="detail-link">
                              {app.email}
                            </a>
                          </span>
                        </div>

                        {app.portfolio && (
                          <div className="detail-row">
                            <span className="detail-label">🌐 Portfolio:</span>
                            <span className="detail-value">
                              <a href={app.portfolio} target="_blank" rel="noreferrer" className="detail-link">
                                View Portfolio
                              </a>
                            </span>
                          </div>
                        )}

                        <div className="detail-row">
                          <span className="detail-label">📝 Cover Letter:</span>
                          <span className="detail-value">{app.coverLetter}</span>
                        </div>

                        {app.resume && (
                          <div className="detail-row">
                            <span className="detail-label">📄 Resume:</span>
                            <span className="detail-value">
                              <a href={`http://localhost:5000${app.resume}`} target="_blank" rel="noreferrer" className="detail-link">
                                Download Resume
                              </a>
                            </span>
                          </div>
                        )}

                        {app.status === 'approved' && (app.interviewDate || app.meetingLink) && (
                          <div className="interview-info">
                            <div className="interview-title">
                              📅 Interview Scheduled
                            </div>
                            {app.interviewDate && (
                              <div className="interview-detail">
                                <strong>Date & Time:</strong> {new Date(app.interviewDate).toLocaleString('en-US', {
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </div>
                            )}
                            {app.meetingLink && (
                              <div className="interview-detail">
                                <strong>Meeting Link:</strong>{' '}
                                <a href={app.meetingLink} target="_blank" rel="noreferrer" className="detail-link">
                                  Join Interview
                                </a>
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="application-footer">
                        <div className="application-date">
                          📅 Applied: {new Date(app.createdAt).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </div>

                        <div className="application-actions">
                          {app.status === "pending" ? (
                            <>
                              <button
                                className="action-btn approve-btn"
                                onClick={() => openScheduleModal(app)}
                              >
                                <span>✅</span> Schedule Interview
                              </button>
                              <button
                                className="action-btn reject-btn"
                                onClick={() => handleReject(app)}
                              >
                                <span>❌</span> Reject
                              </button>
                            </>
                          ) : app.status === "processing" ? (
                            <div className={`status-badge status-${app.status}`}>
                              <span>⚙️</span> Processing...
                            </div>
                          ) : (
                            <div className={`status-badge status-${app.status}`}>
                              {app.status === "approved" ? "✅ Interview Scheduled" : "❌ Application Rejected"}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Interview Scheduling Modal */}
        {isScheduleModalOpen && selectedApplication && (
          <div className="modal-overlay" onClick={() => setIsScheduleModalOpen(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h3 className="modal-title">
                  <span>📅</span> Schedule Interview
                </h3>
                <p className="modal-subtitle">
                  Schedule an interview with {selectedApplication.name}
                </p>
              </div>
              
              <form onSubmit={(e) => {
                e.preventDefault();
                handleScheduleInterview();
              }}>
                <div className="date-time-row">
                  <div className="form-group">
                    <label className="form-label">📅 Interview Date</label>
                    <input
                      type="date"
                      className="form-input"
                      value={interviewData.date}
                      min={getTodayDate()}
                      onChange={(e) => setInterviewData({...interviewData, date: e.target.value})}
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">🕐 Interview Time</label>
                    <input
                      type="time"
                      className="form-input"
                      value={interviewData.time}
                      onChange={(e) => setInterviewData({...interviewData, time: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">🔗 Meeting Link</label>
                  <input
                    type="url"
                    className="form-input"
                    value={interviewData.meetingLink}
                    onChange={(e) => setInterviewData({...interviewData, meetingLink: e.target.value})}
                    placeholder="https://meet.google.com/abc-def-ghi"
                    required
                  />
                  <small style={{ color: '#64748b', fontSize: '0.85rem', marginTop: '0.5rem', display: 'block' }}>
                    Provide a Google Meet, Zoom, or Teams link for the interview
                  </small>
                </div>

                <div className="modal-actions">
                  <button type="submit" className="modal-btn save-btn">
                    ✅ Schedule Interview
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsScheduleModalOpen(false)}
                    className="modal-btn cancel-btn"
                  >
                    ✖ Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Profile Modal */}
        {isEditOpen && (
          <div className="modal-overlay" onClick={() => setIsEditOpen(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div
  className="modal-header"
  style={{ display: "flex", justifyContent: "center", alignItems: "center", textAlign: "center" }}
>
  <h3 className="modal-title" style={{ margin: 0, fontWeight: "bold" }}>
    <span></span> Edit Employer Profile
  </h3>
</div>

              <p className="modal-subtitle">
                  Update your company information
                </p>
              <form onSubmit={(e) => {
                e.preventDefault();
                handleSaveProfile();
              }}>
                {profileFields.map(({ key, label }) => (
                  <div key={key} className="form-group">
                    <label className="form-label">{label}</label>
                    {key === 'description' ? (
                      <textarea
                        className="form-textarea"
                        value={editData?.[key] || ""}
                        onChange={(e) => setEditData({ ...editData, [key]: e.target.value })}
                        placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
                      />
                    ) : (
                      <input
                        type={key === 'email' ? 'email' : key === 'website' || key === 'linkedin' ? 'url' : 'text'}
                        className="form-input"
                        value={editData?.[key] || ""}
                        onChange={(e) => setEditData({ ...editData, [key]: e.target.value })}
                        placeholder={`Enter ${label.replace(/[^\w\s]/gi, '')}`}
                      />
                    )}
                  </div>
                ))}

                <div className="modal-actions">
                  <button type="submit" className="modal-btn save-btn">
                    💾 Save Changes
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditOpen(false)}
                    className="modal-btn cancel-btn"
                  >
                    ✖ Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Req_Dashboard;