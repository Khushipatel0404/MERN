// import React from "react";
// // import "./SignInSignUp.css"; // Reuse your existing styles


// const ForgotPassword = () => {
//   return (
//     <div className="signin-signup-container">
//       <div className="container">
//         {/* Left Section */}
//         <div className="left-section">
//           <div className="logo">JobEntry</div>
//           <div className="hero-content">
//             <h2 className="hero-title">Forgot Your Password?</h2>
//             <p className="hero-subtitle">
//               No worries — just enter your registered email and we’ll send you a
//               link to reset it.
//             </p>
//           </div>
//         </div>

//         {/* Right Section */}
//         <div className="right-section">
//           <div className="form-header">
//             <h2 className="form-title">Reset Password</h2>
//             <p className="form-subtitle">We will send you a password reset link</p>
//           </div>

//           <form>
//             <div className="form-group">
//               <label>Email Address</label>
//               <input
//                 type="email"
//                 placeholder="Enter your email"
//                 required
//               />
//             </div>

//             <button type="submit" className="btn-primary">
//               Send Reset Link
//             </button>
//           </form>

//           <div className="form-footer">
//             <p>
//               Remember your password?{" "}
//               <a href="/signin">Back to Sign In</a>
//             </p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ForgotPassword;


// import React from "react";
// import { Link } from "react-router-dom";

// const ForgotPassword = () => {
//   return (
//     <div className="auth-signin-signup-container">
//       <div className="auth-main-container">
//         {/* Left Section */}
//         <div className="auth-left-section">
//           <div className="auth-logo">JobEntry</div>
//           <div className="auth-hero-content">
//             <h2 className="auth-hero-title">Forgot Your Password?</h2>
//             <p className="auth-hero-subtitle">
//               No worries — just enter your registered email and we’ll send you a
//               link to reset it.
//             </p>
//           </div>
//         </div>

//         {/* Right Section */}
//         <div className="auth-right-section">
//           <div className="auth-form-header">
//             <h2 className="auth-form-title">Reset Password</h2>
//             <p className="auth-form-subtitle">
//               We will send you a password reset link
//             </p>
//           </div>

//           <form>
//             <div className="auth-form-group">
//               <label>Email Address</label>
//               <input
//                 type="email"
//                 placeholder="Enter your email"
//                 required
//               />
//             </div>

//             <button type="submit" className="auth-btn-primary">
//               Send Reset Link
//             </button>
//           </form>

//           <div className="auth-form-footer">
//             <p>
//               Remember your password?{" "}
//               <a href="/signin">Back to Sign In</a>
//             </p>
//           </div>

          
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ForgotPassword;


import React, { useState } from "react";
import { Link } from "react-router-dom";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      setMessage(data.message);
    } catch (err) {
      setMessage("❌ Something went wrong, please try again.");
    }
  };

  return (
    <div className="auth-signin-signup-container">
      <div className="auth-main-container">
        <div className="auth-left-section">
          <div className="auth-logo">JobEntry</div>
          <div className="auth-hero-content">
            <h2 className="auth-hero-title">Forgot Your Password?</h2>
            <p className="auth-hero-subtitle">
              No worries — just enter your registered email and we’ll send you a link.
            </p>
          </div>
        </div>

        <div className="auth-right-section">
          <div className="auth-form-header">
            <h2 className="auth-form-title">Reset Password</h2>
            <p className="auth-form-subtitle">We will send you a password reset link</p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="auth-form-group">
              <label>Email Address</label>
              <input
                type="email"
                placeholder="Enter your email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <button type="submit" className="auth-btn-primary">
              Send Reset Link
            </button>
          </form>

          {message && (
            <p style={{ marginTop: "10px", color: message.includes("✅") ? "green" : "red" }}>
              {message}
            </p>
          )}

          <div className="auth-form-footer">
            <p>
              Remember your password? <Link to="/signin">Back to Sign In</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
