// // // import React, { useState } from "react";
// // // // import "./SignInSignUp.css"; // Reuse your existing styles


// // // const ResetPassword = () => {
// // //   const [password, setPassword] = useState("");
// // //   const [confirmPassword, setConfirmPassword] = useState("");

// // //   const handleSubmit = (e) => {
// // //     e.preventDefault();

// // //     if (password !== confirmPassword) {
// // //       alert("Passwords do not match!");
// // //       return;
// // //     }

// // //     // Here you can call your backend API to reset password
// // //     console.log("Password reset successfully!");
// // //   };

// // //   return (
// // //     <div className="signin-signup-container">
// // //       <div className="container">
// // //         {/* Left Section */}
// // //         <div className="left-section">
// // //           <div className="logo">JobEntry</div>
// // //           <div className="hero-content">
// // //             <h2 className="hero-title">Set Your New Password</h2>
// // //             <p className="hero-subtitle">
// // //               Enter your new password and confirm it to complete the reset process.
// // //             </p>
// // //           </div>
// // //         </div>

// // //         {/* Right Section */}
// // //         <div className="right-section">
// // //           <div className="form-header">
// // //             <h2 className="form-title">Create New Password</h2>
// // //             <p className="form-subtitle">
// // //               Choose a strong password you haven’t used before.
// // //             </p>
// // //           </div>

// // //           <form onSubmit={handleSubmit}>
// // //             <div className="form-group">
// // //               <label>New Password</label>
// // //               <input
// // //                 type="password"
// // //                 placeholder="Enter new password"
// // //                 value={password}
// // //                 onChange={(e) => setPassword(e.target.value)}
// // //                 required
// // //               />
// // //             </div>

// // //             <div className="form-group">
// // //               <label>Confirm Password</label>
// // //               <input
// // //                 type="password"
// // //                 placeholder="Re-enter new password"
// // //                 value={confirmPassword}
// // //                 onChange={(e) => setConfirmPassword(e.target.value)}
// // //                 required
// // //               />
// // //             </div>

// // //             <button type="submit" className="btn-primary">
// // //               Reset Password
// // //             </button>
// // //           </form>

// // //           <div className="form-footer">
// // //             <p>
// // //               Back to <a href="/signin">Sign In</a>
// // //             </p>
// // //           </div>
// // //         </div>
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default ResetPassword;



// // import React, { useState } from "react";
// // import { Link } from "react-router-dom";

// // const ResetPassword = () => {
// //   const [password, setPassword] = useState("");
// //   const [confirmPassword, setConfirmPassword] = useState("");

// //   const handleSubmit = (e) => {
// //     e.preventDefault();

// //     if (password !== confirmPassword) {
// //       alert("Passwords do not match!");
// //       return;
// //     }

// //     // Backend API call for reset
// //     console.log("Password reset successfully!");
// //   };

// //   return (
// //     <div className="auth-signin-signup-container">
// //       <div className="auth-main-container">
// //         {/* Left Section */}
// //         <div className="auth-left-section">
// //           <div className="auth-logo">JobEntry</div>
// //           <div className="auth-hero-content">
// //             <h2 className="auth-hero-title">Set Your New Password</h2>
// //             <p className="auth-hero-subtitle">
// //               Enter your new password and confirm it to complete the reset process.
// //             </p>
// //           </div>
// //         </div>

// //         {/* Right Section */}
// //         <div className="auth-right-section">
// //           <div className="auth-form-header">
// //             <h2 className="auth-form-title">Create New Password</h2>
// //             <p className="auth-form-subtitle">
// //               Choose a strong password you haven’t used before.
// //             </p>
// //           </div>

// //           <form onSubmit={handleSubmit}>
// //             <div className="auth-form-group">
// //               <label>New Password</label>
// //               <input
// //                 type="password"
// //                 placeholder="Enter new password"
// //                 value={password}
// //                 onChange={(e) => setPassword(e.target.value)}
// //                 required
// //               />
// //             </div>

// //             <div className="auth-form-group">
// //               <label>Confirm Password</label>
// //               <input
// //                 type="password"
// //                 placeholder="Re-enter new password"
// //                 value={confirmPassword}
// //                 onChange={(e) => setConfirmPassword(e.target.value)}
// //                 required
// //               />
// //             </div>

// //             <button type="submit" className="auth-btn-primary">
// //               Reset Password
// //             </button>
// //           </form>

// //           <div className="auth-form-footer">
// //             <p>
// //               Back to <a href="/signin">Sign In</a>
// //             </p>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default ResetPassword;

// import React, { useState } from "react";
// import { useLocation, Link } from "react-router-dom";

// const ResetPassword = () => {
//   const query = new URLSearchParams(useLocation().search);
//   const token = query.get("token");

//   const [password, setPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");
//   const [message, setMessage] = useState("");

//   // const handleSubmit = async (e) => {
//   //   e.preventDefault();

//   //   if (password !== confirmPassword) {
//   //     setMessage("❌ Passwords do not match!");
//   //     return;
//   //   }

//   //   try {
//   //     const res = await fetch("http://localhost:5000/api/reset-password", {
//   //       method: "POST",
//   //       headers: { "Content-Type": "application/json" },
//   //       body: JSON.stringify({ token, password }),
//   //     });
//   //     const data = await res.json();
//   //     setMessage(data.message);
//   //   } catch (err) {
//   //     setMessage("❌ Something went wrong, please try again.");
//   //   }
//   // };


//   const handleSubmit = (e) => {
//   e.preventDefault();
//   if (password !== confirmPassword) {
//     alert("Passwords do not match!");
//     return;
//   }

//   console.log("Password reset successfully!");
// };

//   return (
//     <div className="auth-signin-signup-container">
//       <div className="auth-main-container">
//         <div className="auth-left-section">
//           <div className="auth-logo">JobEntry</div>
//           <div className="auth-hero-content">
//             <h2 className="auth-hero-title">Set Your New Password</h2>
//             <p className="auth-hero-subtitle">
//               Enter your new password and confirm it to complete the reset process.
//             </p>
//           </div>
//         </div>

//         <div className="auth-right-section">
//           <div className="auth-form-header">
//             <h2 className="auth-form-title">Create New Password</h2>
//             <p className="auth-form-subtitle">Choose a strong password</p>
//           </div>

//           <form onSubmit={handleSubmit}>
//             <div className="auth-form-group">
//               <label>New Password</label>
//               <input
//                 type="password"
//                 placeholder="Enter new password"
//                 value={password}
//                 onChange={(e) => setPassword(e.target.value)}
//                 required
//               />
//             </div>

//             <div className="auth-form-group">
//               <label>Confirm Password</label>
//               <input
//                 type="password"
//                 placeholder="Re-enter new password"
//                 value={confirmPassword}
//                 onChange={(e) => setConfirmPassword(e.target.value)}
//                 required
//               />
//             </div>

//             <button type="submit" className="auth-btn-primary">
//               Reset Password
//             </button>
//           </form>

//           {message && (
//             <p style={{ marginTop: "10px", color: message.includes("✅") ? "green" : "red" }}>
//               {message}
//             </p>
//           )}

//           <div className="auth-form-footer">
//             <p>
//               Back to <Link to="/signin">Sign In</Link>
//             </p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ResetPassword;


import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const ResetPassword = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");

  const location = useLocation();
  const navigate = useNavigate();

  
  const query = new URLSearchParams(location.search);
  const token = query.get("token");
  

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setMessage("❌ Passwords do not match!");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });

      const data = await res.json();

      if (res.ok) {
        setMessage("✅ Password reset successful!");
        setTimeout(() => navigate("/signin"), 2000);
      } else {
        setMessage("❌ " + (data.message || "Something went wrong"));
      }
    } catch (err) {
      setMessage("❌ Error: " + err.message);
    }
  };

  return (
    <div className="auth-signin-signup-container">
      <div className="auth-main-container">
        {/* Left Section */}
        <div className="auth-left-section">
          <div className="auth-logo">JobEntry</div>
          <div className="auth-hero-content">
            <h2 className="auth-hero-title">Set Your New Password</h2>
            <p className="auth-hero-subtitle">
              Enter your new password and confirm it to complete the reset process.
            </p>
          </div>
        </div>

        {/* Right Section */}
        <div className="auth-right-section">
          <form onSubmit={handleSubmit}>
            <div className="auth-form-group">
              <label>New Password</label>
              <input
                type="password"
                placeholder="Enter new password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <div className="auth-form-group">
              <label>Confirm Password</label>
              <input
                type="password"
                placeholder="Re-enter new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>

            <button type="submit" className="auth-btn-primary">
              Reset Password
            </button>
          </form>

          {message && <p style={{ marginTop: "10px", color: "red" }}>{message}</p>}
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
