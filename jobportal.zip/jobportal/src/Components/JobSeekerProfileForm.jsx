// // import React, { useState } from "react";
// // import { useParams, useNavigate } from "react-router-dom";

// // const JobSeekerProfileForm = () => {
// //   const { userId } = useParams();
// //   const navigate = useNavigate();

// //   const [formData, setFormData] = useState({
// //     bio: "",
// //     skills: "",
// //     experience: "",
// //     linkedin: "",
// //     github: "",
// //     education: "",
// //   });

// //   const [error, setError] = useState("");
// //   const [success, setSuccess] = useState("");

// //   const handleInputChange = (e) => {
// //     const { name, value } = e.target;
// //     setFormData({ ...formData, [name]: value });
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     try {
// //       const res = await fetch("http://localhost:5000/api/profile/jobseeker", {
// //         method: "POST",
// //         headers: { "Content-Type": "application/json" },
// //         body: JSON.stringify({ userId, ...formData }),
// //       });

// //       const data = await res.json();
// //       if (res.ok && data.success) {
// //         setSuccess(data.message);
// //         setError("");
// //         setTimeout(() => navigate("/login"), 1500); // Redirect to login
// //       } else {
// //         setError(data.message || "Something went wrong");
// //       }
// //     } catch (err) {
// //       setError(err.message);
// //     }
// //   };

// //   return (
// //     <div className="profile-form-container">
// //       <h2>Job Seeker Profile</h2>
// //       {error && <div className="error">{error}</div>}
// //       {success && <div className="success">{success}</div>}
// //       <form onSubmit={handleSubmit}>
// //         <label>Bio</label>
// //         <textarea name="bio" value={formData.bio} onChange={handleInputChange} />

// //         <label>Skills</label>
// //         <input type="text" name="skills" value={formData.skills} onChange={handleInputChange} />

// //         <label>Experience</label>
// //         <input type="text" name="experience" value={formData.experience} onChange={handleInputChange} />

// //         <label>LinkedIn</label>
// //         <input type="text" name="linkedin" value={formData.linkedin} onChange={handleInputChange} />

// //         <label>GitHub</label>
// //         <input type="text" name="github" value={formData.github} onChange={handleInputChange} />

// //         <label>Education</label>
// //         <input type="text" name="education" value={formData.education} onChange={handleInputChange} />

// //         <button type="submit">Save Profile</button>
// //       </form>
// //     </div>
// //   );
// // };

// // export default JobSeekerProfileForm;

// // import React, { useState, useEffect } from "react";
// // import { useNavigate } from "react-router-dom";

// // const JobseekerProfile = ({ userId }) => {
// //   const navigate = useNavigate();

// //   const [formData, setFormData] = useState({
// //     bio: "",
// //     skills: "",
// //     experience: "",
// //     education: "",
// //     linkedin: "",
// //     github: "",
// //     resume: "",
// //     phone: "",
// //     location: "",
// //     expectedSalary: "",
// //     availability: "",
// //   });

// //   const [success, setSuccess] = useState("");
// //   const [error, setError] = useState("");

// //   const handleInputChange = (e) => {
// //     const { name, value } = e.target;
// //     setFormData((prev) => ({ ...prev, [name]: value }));
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();

// //     try {
// //       const res = await fetch("http://localhost:5000/api/profile/jobseeker", {
// //         method: "POST",
// //         headers: { "Content-Type": "application/json" },
// //         body: JSON.stringify({ ...formData, userId }),
// //       });

// //       const data = await res.json();
// //       if (res.ok && data.success) {
// //         setSuccess(data.message);
// //         setError("");
// //         setTimeout(() => navigate("/"), 1500); // Redirect after submission
// //       } else {
// //         setError(data.message || "Something went wrong");
// //         setSuccess("");
// //       }
// //     } catch (err) {
// //       setError("Error: " + err.message);
// //       setSuccess("");
// //     }
// //   };

// //   return (
// //     <div className="profile-container">
// //       <h2>Jobseeker Profile</h2>
// //       {error && <p style={{ color: "red" }}>{error}</p>}
// //       {success && <p style={{ color: "green" }}>{success}</p>}
// //       <form onSubmit={handleSubmit}>
// //         <label>Bio</label>
// //         <textarea name="bio" value={formData.bio} onChange={handleInputChange} />

// //         <label>Skills</label>
// //         <input name="skills" value={formData.skills} onChange={handleInputChange} />

// //         <label>Experience</label>
// //         <input name="experience" value={formData.experience} onChange={handleInputChange} />

// //         <label>Education</label>
// //         <input name="education" value={formData.education} onChange={handleInputChange} />

// //         <label>LinkedIn</label>
// //         <input name="linkedin" value={formData.linkedin} onChange={handleInputChange} />

// //         <label>GitHub</label>
// //         <input name="github" value={formData.github} onChange={handleInputChange} />

// //         <label>Resume URL</label>
// //         <input name="resume" value={formData.resume} onChange={handleInputChange} />

// //         <label>Phone</label>
// //         <input name="phone" value={formData.phone} onChange={handleInputChange} />

// //         <label>Location</label>
// //         <input name="location" value={formData.location} onChange={handleInputChange} />

// //         <label>Expected Salary</label>
// //         <input name="expectedSalary" value={formData.expectedSalary} onChange={handleInputChange} />

// //         <label>Availability</label>
// //         <input name="availability" value={formData.availability} onChange={handleInputChange} />

// //         <button type="submit">Submit Profile</button>
// //       </form>
// //     </div>
// //   );
// // };

// // export default JobseekerProfile;
// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";

// const JobseekerProfile = ({ userId }) => {
//   const navigate = useNavigate();

//   const [formData, setFormData] = useState({
//     bio: "",
//     skills: "",
//     experience: "",
//     education: "",
//     linkedin: "",
//     github: "",
//     resume: "",
//     phone: "",
//     location: { city: "", state: "", country: "" },
//     expectedSalary: "",
//     availability: "",
//   });

//   const [success, setSuccess] = useState("");
//   const [error, setError] = useState("");

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;

//     // handle nested location object
//     if (["city", "state", "country"].includes(name)) {
//       setFormData((prev) => ({
//         ...prev,
//         location: { ...prev.location, [name]: value },
//       }));
//     } else {
//       setFormData((prev) => ({ ...prev, [name]: value }));
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!userId) return setError("❌ userId missing!");

//     try {
//       const res = await fetch("http://localhost:5000/api/profile/jobseeker", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ ...formData, userId }),
//       });

//       const data = await res.json();
//       if (res.ok && data.success) {
//         setSuccess(data.message);
//         setError("");
//         setTimeout(() => navigate("/"), 1500);
//       } else {
//         setError(data.message || "Something went wrong");
//         setSuccess("");
//       }
//     } catch (err) {
//       setError("Error: " + err.message);
//       setSuccess("");
//     }
//   };

//   return (
//     <div className="profile-container">
//       <h2>Jobseeker Profile</h2>
//       {error && <p style={{ color: "red" }}>{error}</p>}
//       {success && <p style={{ color: "green" }}>{success}</p>}
//       <form onSubmit={handleSubmit}>
//         <label>Bio</label>
//         <textarea name="bio" value={formData.bio} onChange={handleInputChange} />

//         <label>Skills</label>
//         <input name="skills" value={formData.skills} onChange={handleInputChange} />

//         <label>Experience</label>
//         <input name="experience" value={formData.experience} onChange={handleInputChange} />

//         <label>Education</label>
//         <input name="education" value={formData.education} onChange={handleInputChange} />

//         <label>LinkedIn</label>
//         <input name="linkedin" value={formData.linkedin} onChange={handleInputChange} />

//         <label>GitHub</label>
//         <input name="github" value={formData.github} onChange={handleInputChange} />

//         <label>Resume URL</label>
//         <input name="resume" value={formData.resume} onChange={handleInputChange} />

//         <label>Phone</label>
//         <input name="phone" value={formData.phone} onChange={handleInputChange} />

//         <label>City</label>
//         <input name="city" value={formData.location.city} onChange={handleInputChange} />

//         <label>State</label>
//         <input name="state" value={formData.location.state} onChange={handleInputChange} />

//         <label>Country</label>
//         <input name="country" value={formData.location.country} onChange={handleInputChange} />

//         <label>Expected Salary</label>
//         <input name="expectedSalary" value={formData.expectedSalary} onChange={handleInputChange} />

//         <label>Availability</label>
//         <input name="availability" value={formData.availability} onChange={handleInputChange} />

//         <button type="submit">Submit Profile</button>
//       </form>
//     </div>
//   );
// };

// // export default JobseekerProfile;
// import React, { useState } from "react";
// import { useNavigate, useParams } from "react-router-dom";

// const JobseekerProfile = () => {
//   const navigate = useNavigate();
//   const { userId } = useParams(); // Get userId from URL

//   const [formData, setFormData] = useState({
//     bio: "",
//     skills: "",
//     experience: "",
//     education: "",
//     linkedin: "",
//     github: "",
//     resume: "",
//     phone: "",
//     location: { city: "", state: "", country: "" },
//     expectedSalary: "",
//     availability: "",
//   });

//   const [success, setSuccess] = useState("");
//   const [error, setError] = useState("");

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;

//     // Handle location fields separately
//     if (name === "city" || name === "state" || name === "country") {
//       setFormData((prev) => ({
//         ...prev,
//         location: { ...prev.location, [name]: value },
//       }));
//     } else {
//       setFormData((prev) => ({ ...prev, [name]: value }));
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!userId) return setError("❌ userId missing!");

//     try {
//       const res = await fetch("http://localhost:5000/api/profile/jobseeker", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ ...formData, userId }),
//       });

//       const data = await res.json();
//       if (res.ok && data.success) {
//         setSuccess(data.message);
//         setError("");
//         setTimeout(() => navigate("/signin"), 1500);
//       } else {
//         setError(data.message || "Something went wrong");
//         setSuccess("");
//       }
//     } catch (err) {
//       setError("Error: " + err.message);
//       setSuccess("");
//     }
//   };

//   return (
//     <div className="profile-container">
//       <h2>Jobseeker Profile</h2>
//       {error && <p style={{ color: "red" }}>{error}</p>}
//       {success && <p style={{ color: "green" }}>{success}</p>}
//       <form onSubmit={handleSubmit}>
//         <label>Bio</label>
//         <textarea name="bio" value={formData.bio} onChange={handleInputChange} />

//         <label>Skills</label>
//         <input name="skills" value={formData.skills} onChange={handleInputChange} />

//         <label>Experience</label>
//         <input name="experience" value={formData.experience} onChange={handleInputChange} />

//         <label>Education</label>
//         <input name="education" value={formData.education} onChange={handleInputChange} />

//         <label>LinkedIn</label>
//         <input name="linkedin" value={formData.linkedin} onChange={handleInputChange} />

//         <label>GitHub</label>
//         <input name="github" value={formData.github} onChange={handleInputChange} />

//         <label>Resume URL</label>
//         <input name="resume" value={formData.resume} onChange={handleInputChange} />

//         <label>Phone</label>
//         <input name="phone" value={formData.phone} onChange={handleInputChange} />

//         <label>City</label>
//         <input name="city" value={formData.location.city} onChange={handleInputChange} />

//         <label>State</label>
//         <input name="state" value={formData.location.state} onChange={handleInputChange} />

//         <label>Country</label>
//         <input name="country" value={formData.location.country} onChange={handleInputChange} />

//         <label>Expected Salary</label>
//         <input name="expectedSalary" value={formData.expectedSalary} onChange={handleInputChange} />

//         <label>Availability</label>
//         <input name="availability" value={formData.availability} onChange={handleInputChange} />

//         <button type="submit">Submit Profile</button>
//       </form>
//     </div>
//   );
// };

// export default JobseekerProfile;
import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const JobseekerProfile = () => {
  const navigate = useNavigate();
  const { userId } = useParams(); // Get userId from URL

  const [formData, setFormData] = useState({
    bio: "",
    skills: "",
    experience: "",
    education: "",
    linkedin: "",
    github: "",
    resume: "",
    phone: "",
    location: { city: "", state: "", country: "" },
    expectedSalary: "",
    availability: "",
  });

  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    if (name === "city" || name === "state" || name === "country") {
      setFormData((prev) => ({
        ...prev,
        location: { ...prev.location, [name]: value },
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!userId) return setError("❌ userId missing!");

    try {
      const res = await fetch("http://localhost:5000/api/profile/jobseeker", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...formData, userId }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSuccess(data.message);
        setError("");
        setTimeout(() => navigate("/signin"), 1500);
      } else {
        setError(data.message || "Something went wrong");
        setSuccess("");
      }
    } catch (err) {
      setError("Error: " + err.message);
      setSuccess("");
    }
  };

  return (
    <div className="auth-signin-signup-container">
      <div className="auth-main-container">
        {/* ✅ Left Section */}
        <div className="auth-left-section">
          <div className="auth-logo">JobEntry</div>
          <div className="auth-hero-content">
            <h2 className="auth-hero-title">Jobseeker Profile Setup</h2>
            <p className="auth-hero-subtitle">
              Fill in your professional details so employers can know more about you.
            </p>
          </div>
        </div>

        {/* ✅ Right Section */}
        <div className="auth-right-section">
          <form onSubmit={handleSubmit}>
            <div className="auth-form-group">
              <label>Bio</label>
              <textarea
                name="bio"
                value={formData.bio}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Skills</label>
              <input
                name="skills"
                value={formData.skills}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Experience</label>
              <input
                name="experience"
                value={formData.experience}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Education</label>
              <input
                name="education"
                value={formData.education}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>LinkedIn</label>
              <input
                name="linkedin"
                value={formData.linkedin}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>GitHub</label>
              <input
                name="github"
                value={formData.github}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Resume URL</label>
              <input
                name="resume"
                value={formData.resume}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Phone</label>
              <input
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>City</label>
              <input
                name="city"
                value={formData.location.city}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>State</label>
              <input
                name="state"
                value={formData.location.state}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Country</label>
              <input
                name="country"
                value={formData.location.country}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Expected Salary</label>
              <input
                name="expectedSalary"
                value={formData.expectedSalary}
                onChange={handleInputChange}
              />
            </div>

            <div className="auth-form-group">
              <label>Availability</label>
              <input
                name="availability"
                value={formData.availability}
                onChange={handleInputChange}
              />
            </div>

            <button type="submit" className="auth-btn-primary">
              Submit Profile
            </button>
          </form>

          {error && <p style={{ marginTop: "10px", color: "red" }}>{error}</p>}
          {success && <p style={{ marginTop: "10px", color: "green" }}>{success}</p>}
        </div>
      </div>
    </div>
  );
};

export default JobseekerProfile;
