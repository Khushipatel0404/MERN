function HeaderCarousel({ carousel, carousel2 }) {
  // Container fluid styles
  const containerFluidStyle = {
    padding: 0,
    width: "100%",
  };

  // Owl carousel container style
  const owlCarouselStyle = {
    position: "relative",
  };

  // Each carousel item style
  const carouselItemStyle = {
    position: "relative",
    minHeight: "500px",
  };

  // Image style
  const imgFluidStyle = {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    display: "block",
  };

  // Overlay style
  const overlayStyle = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    background: "rgba(43, 57, 64, 0.5)",
    display: "flex",
    alignItems: "center",
  };

  // Inner container with padding and left border
  const innerContainerStyle = {
    position: "relative",
    padding: "45px 0 45px 35px",
    borderLeft: "15px solid #0d6efd", // Bootstrap primary color
    width: "100%",
    boxSizing: "border-box",
  };

  // Row style (flex container, left-aligned)
  const rowStyle = {
    display: "flex",
    justifyContent: "flex-start",
    flexWrap: "wrap",
  };

  // Column style for col-10 col-lg-8 (~83.333% width)
  const colStyle = {
    flex: "0 0 auto",
    width: "83.3333%",
    maxWidth: "83.3333%",
  };

  // Heading style
  const h1Style = {
    fontSize: "calc(1.625rem + 3vw)",
    fontWeight: 700,
    color: "white",
    marginBottom: "1.5rem",
  };

  // Paragraph style
  const pStyle = {
    fontSize: "1.25rem",
    fontWeight: 500,
    color: "white",
    marginBottom: "1.5rem",
    paddingBottom: "0.5rem",
  };

  // Button primary style
  const btnPrimaryStyle = {
    padding: "0.75rem 3rem",
    marginRight: "1rem",
    backgroundColor: "#0d6efd",
    border: "none",
    color: "white",
    textDecoration: "none",
    borderRadius: "0.25rem",
    cursor: "pointer",
    display: "inline-block",
  };

  // Button secondary style
  const btnSecondaryStyle = {
    padding: "0.75rem 3rem",
    backgroundColor: "#6c757d",
    border: "none",
    color: "white",
    textDecoration: "none",
    borderRadius: "0.25rem",
    cursor: "pointer",
    display: "inline-block",
  };

  return (
    <div className="container-fluid p-0" style={containerFluidStyle}>
      <div className="owl-carousel header-carousel position-relative" style={owlCarouselStyle}>
        <div className="owl-carousel-item position-relative" style={carouselItemStyle}>
          <img src={carousel} alt="Carousel" className="img-fluid" style={imgFluidStyle} />
          <div className="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style={overlayStyle}>
            <div className="container" style={innerContainerStyle}>
              <div className="row justify-content-start" style={rowStyle}>
                <div className="col-10 col-lg-8" style={colStyle}>
                  <h1 className="display-3 text-white animated slideInDown mb-4" style={h1Style}>
                    Find The Perfect Job That You Deserved
                  </h1>
                  <p className="fs-5 fw-medium text-white mb-4 pb-2" style={pStyle}>
                    Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et
                    kasd rebum sea elitr.
                  </p>
                  <a href="#" className="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft" style={btnPrimaryStyle}>
                    Search A Job
                  </a>
                  <a href="#" className="btn btn-secondary py-md-3 px-md-5 animated slideInRight" style={btnSecondaryStyle}>
                    Find A Talent
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="owl-carousel-item position-relative" style={carouselItemStyle}>
          <img src={carousel2} alt="Carousel2" className="img-fluid" style={imgFluidStyle} />
          <div className="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style={overlayStyle}>
            <div className="container" style={innerContainerStyle}>
              <div className="row justify-content-start" style={rowStyle}>
                <div className="col-10 col-lg-8" style={colStyle}>
                  <h1 className="display-3 text-white animated slideInDown mb-4" style={h1Style}>
                    Find The Best Startup Job That Fit You
                  </h1>
                  <p className="fs-5 fw-medium text-white mb-4 pb-2" style={pStyle}>
                    Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et
                    kasd rebum sea elitr.
                  </p>
                  <a href="#" className="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft" style={btnPrimaryStyle}>
                    Search A Job
                  </a>
                  <a href="#" className="btn btn-secondary py-md-3 px-md-5 animated slideInRight" style={btnSecondaryStyle}>
                    Find A Talent
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
