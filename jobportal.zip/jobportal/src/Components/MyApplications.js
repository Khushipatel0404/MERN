// // // // import React, { useEffect, useState } from "react";

// // // // const MyApplications = () => {
// // // //   const [applications, setApplications] = useState([]);
// // // //   const [interviews, setInterviews] = useState([]);
// // // //   const [loading, setLoading] = useState(true);

// // // //   const user = JSON.parse(localStorage.getItem("user")); // logged-in user info

// // // //   useEffect(() => {
// // // //     const fetchData = async () => {
// // // //       try {
// // // //         // Fetch applications
// // // //         const appRes = await fetch(`http://localhost:5000/api/user/applications/${user.id}`);
// // // //         const appData = await appRes.json();

// // // //         // Fetch interviews
// // // //         const intRes = await fetch(`http://localhost:5000/api/user/interviews/${user.id}`);
// // // //         const intData = await intRes.json();

// // // //         if (appData.success) setApplications(appData.applications);
// // // //         if (intData.success) setInterviews(intData.interviews);
// // // //       } catch (err) {
// // // //         console.error("❌ Fetch Error:", err);
// // // //       } finally {
// // // //         setLoading(false);
// // // //       }
// // // //     };

// // // //     fetchData();
// // // //   }, [user.id]);

// // // //   if (loading) return <div className="container py-5 text-center">Loading...</div>;

// // // //   return (
// // // //     <div className="container py-5">
// // // //       <h2 className="text-center mb-4">My Applications</h2>

// // // //       {applications.length === 0 ? (
// // // //         <p className="text-center">No applications found.</p>
// // // //       ) : (
// // // //         <div className="table-responsive">
// // // //           <table className="table table-striped table-bordered align-middle">
// // // //             <thead className="table-dark text-center">
// // // //               <tr>
// // // //                 <th>Jobseeker Name</th>
// // // //                 <th>Email</th>
// // // //                 <th>Employer</th>
// // // //                 <th>Status</th>
// // // //                 <th>Applied On</th>
// // // //                 <th>Interview Date</th>
// // // //                 <th>Meeting Link</th>
// // // //               </tr>
// // // //             </thead>
// // // //             <tbody className="text-center">
// // // //               {applications.map((app) => {
// // // //                 const interview = interviews.find(
// // // //                   (int) => int.applicationId?._id === app._id
// // // //                 );

// // // //                 return (
// // // //                   <tr key={app._id}>
// // // //                     <td>{app.name}</td>
// // // //                     <td>{app.email}</td>
// // // //                     <td>{app.employerId?.companyName || "N/A"}</td>
// // // //                     <td>
// // // //                       {app.status === "approved" ? (
// // // //                         <span className="text-success fw-bold">Approved</span>
// // // //                       ) : app.status === "rejected" ? (
// // // //                         <span className="text-danger fw-bold">Rejected</span>
// // // //                       ) : (
// // // //                         <span className="text-warning fw-bold">Pending</span>
// // // //                       )}
// // // //                     </td>
// // // //                     <td>{new Date(app.createdAt).toLocaleDateString()}</td>
// // // //                     <td>
// // // //                       {interview?.interviewDate
// // // //                         ? new Date(interview.interviewDate).toLocaleString()
// // // //                         : "—"}
// // // //                     </td>
// // // //                     <td>
// // // //                       {interview?.meetingLink ? (
// // // //                         <a
// // // //                           href={interview.meetingLink}
// // // //                           target="_blank"
// // // //                           rel="noopener noreferrer"
// // // //                         >
// // // //                           Join Link
// // // //                         </a>
// // // //                       ) : (
// // // //                         "—"
// // // //                       )}
// // // //                     </td>
// // // //                   </tr>
// // // //                 );
// // // //               })}
// // // //             </tbody>
// // // //           </table>
// // // //         </div>
// // // //       )}
// // // //     </div>
// // // //   );
// // // // };

// // // // export default MyApplications;
// // // import React, { useEffect, useState } from "react";

// // // const MyApplications = () => {
// // //   const [applications, setApplications] = useState([]);
// // //   const [interviews, setInterviews] = useState([]);
// // //   const [loading, setLoading] = useState(true);

// // //   const user = JSON.parse(localStorage.getItem("user"));

// // //   useEffect(() => {
// // //     const fetchData = async () => {
// // //       try {
// // //         const appRes = await fetch(`http://localhost:5000/api/user/applications/${user.id}`);
// // //         const intRes = await fetch(`http://localhost:5000/api/user/interviews/${user.id}`);

// // //         const appData = await appRes.json();
// // //         const intData = await intRes.json();

// // //         if (appData.success) setApplications(appData.applications);
// // //         if (intData.success) setInterviews(intData.interviews);

// // //         console.log("Applications:", appData.applications);
// // //         console.log("Interviews:", intData.interviews);
// // //       } catch (err) {
// // //         console.error(err);
// // //       } finally {
// // //         setLoading(false);
// // //       }
// // //     };

// // //     fetchData();
// // //   }, [user.id]);

// // //   if (loading) return <div className="container py-5 text-center">Loading...</div>;

// // //   return (
// // //     <div className="container py-5">
// // //       <h2 className="text-center mb-4">My Applications</h2>

// // //       {applications.length === 0 ? (
// // //         <p className="text-center">No applications found.</p>
// // //       ) : (
// // //         <div className="table-responsive">
// // //           <table className="table table-striped table-bordered align-middle">
// // //             <thead className="table-dark text-center">
// // //               <tr>
// // //                 <th>Jobseeker Name</th>
// // //                 <th>Email</th>
// // //                 <th>Employer</th>
// // //                 <th>Status</th>
// // //                 <th>Applied On</th>
// // //                 <th>Interview Date</th>
// // //                 <th>Meeting Link</th>
// // //               </tr>
// // //             </thead>
// // //             <tbody className="text-center">
// // //               {applications.map((app) => {
// // //                 // 🔹 Compare as string to avoid ObjectId mismatch
// // //                 const interview = interviews.find(
// // //                   (int) => int.applicationId && String(int.applicationId._id) === String(app._id)
// // //                 );

// // //                 return (
// // //                   <tr key={app._id}>
// // //                     <td>{app.name}</td>
// // //                     <td>{app.email}</td>
// // //                     <td>{app.employerId?.companyName || "N/A"}</td>
// // //                     <td>
// // //                       {app.status === "approved" ? (
// // //                         <span className="text-success fw-bold">Approved</span>
// // //                       ) : app.status === "rejected" ? (
// // //                         <span className="text-danger fw-bold">Rejected</span>
// // //                       ) : (
// // //                         <span className="text-warning fw-bold">Pending</span>
// // //                       )}
// // //                     </td>
// // //                     <td>{new Date(app.createdAt).toLocaleDateString()}</td>
// // //                     <td>
// // //                       {interview?.interviewDate
// // //                         ? new Date(interview.interviewDate).toLocaleString()
// // //                         : "—"}
// // //                     </td>
// // //                     <td>
// // //                       {interview?.meetingLink ? (
// // //                         <a href={interview.meetingLink} target="_blank" rel="noopener noreferrer">
// // //                           Join Link
// // //                         </a>
// // //                       ) : "—"}
// // //                     </td>
// // //                   </tr>
// // //                 );
// // //               })}
// // //             </tbody>
// // //           </table>
// // //         </div>
// // //       )}
// // //     </div>
// // //   );
// // // };

// // // export default MyApplications;
// // import React, { useEffect, useState } from "react";
// // import { Link, useNavigate } from "react-router-dom";

// // const MyApplications = () => {
// //   const [applications, setApplications] = useState([]);
// //   const [interviews, setInterviews] = useState([]);
// //   const [loading, setLoading] = useState(true);
// //   const [user, setUser] = useState(null);
// //   const [isProfileOpen, setIsProfileOpen] = useState(false);
// //   const navigate = useNavigate();

// //   useEffect(() => {
// //     const storedUser = JSON.parse(localStorage.getItem("user"));
// //     if (storedUser) {
// //       setUser(storedUser);
// //       fetchData(storedUser.id);
// //     }
// //   }, []);

// //   const fetchData = async (userId) => {
// //     try {
// //       const appRes = await fetch(`http://localhost:5000/api/user/applications/${userId}`);
// //       const intRes = await fetch(`http://localhost:5000/api/user/interviews/${userId}`);

// //       const appData = await appRes.json();
// //       const intData = await intRes.json();

// //       if (appData.success) setApplications(appData.applications);
// //       if (intData.success) setInterviews(intData.interviews);
// //     } catch (err) {
// //       console.error(err);
// //     } finally {
// //       setLoading(false);
// //     }
// //   };

// //   const handleLogout = () => {
// //     localStorage.removeItem("user");
// //     setUser(null);
// //     navigate("/");
// //   };

// //   const getStatusColor = (status) => {
// //     switch (status) {
// //       case "approved":
// //         return "#00D9A0";
// //       case "rejected":
// //         return "#e74c3c";
// //       default:
// //         return "#f39c12";
// //     }
// //   };

// //   const getStatusLabel = (status) => {
// //     switch (status) {
// //       case "approved":
// //         return "✅ Approved";
// //       case "rejected":
// //         return "❌ Rejected";
// //       default:
// //         return "⏳ Pending";
// //     }
// //   };

// //   return (
// //     <div>
// //       {/* ========== NAVBAR ========== */}
// //       <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
// //         <Link to="/" className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
// //           <h1 className="m-0 text-primary">JobEntry</h1>
// //         </Link>

// //         <button
// //           type="button"
// //           className="navbar-toggler me-4"
// //           data-bs-toggle="collapse"
// //           data-bs-target="#navbarCollapse"
// //         >
// //           <span className="navbar-toggler-icon"></span>
// //         </button>

// //         <div className="collapse navbar-collapse" id="navbarCollapse">
// //           <div className="navbar-nav ms-auto p-4 p-lg-0">
// //             {user && (
// //               <span className="nav-item nav-link text-primary fw-bold me-2">
// //                 Welcome, {user.firstName || user.name}
// //               </span>
// //             )}

// //             <Link to="/" className="nav-item nav-link">Home</Link>
// //             <Link to="/about" className="nav-item nav-link">About</Link>
// //             <Link to="/jobs" className="nav-item nav-link">Jobs</Link>
// //             <Link to="/contact" className="nav-item nav-link">Contact</Link>

// //             {user ? (
// //               <div className="nav-item dropdown" style={{ position: "relative" }}>
// //                 <a
// //                   href="#"
// //                   className="nav-link dropdown-toggle"
// //                   onClick={(e) => {
// //                     e.preventDefault();
// //                     setIsProfileOpen(!isProfileOpen);
// //                   }}
// //                 >
// //                   👤
// //                 </a>

// //                 {isProfileOpen && (
// //                   <div
// //                     style={{
// //                       position: "absolute",
// //                       top: "50px",
// //                       right: 0,
// //                       background: "#fff",
// //                       boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
// //                       borderRadius: "10px",
// //                       minWidth: "250px",
// //                       zIndex: 100,
// //                     }}
// //                   >
// //                     <div style={{ padding: "15px", borderBottom: "1px solid #eee" }}>
// //                       <strong>{user.firstName} {user.lastName}</strong>
// //                       <div style={{ fontSize: "12px", color: "#777" }}>{user.email}</div>
// //                     </div>
// //                     <button
// //                       onClick={handleLogout}
// //                       style={{
// //                         width: "100%",
// //                         background: "none",
// //                         border: "none",
// //                         color: "#e74c3c",
// //                         padding: "10px 15px",
// //                         textAlign: "left",
// //                         cursor: "pointer",
// //                         fontWeight: "bold",
// //                       }}
// //                     >
// //                       Logout
// //                     </button>
// //                   </div>
// //                 )}
// //               </div>
// //             ) : (
// //               <Link to="/signin" className="nav-item nav-link">Login</Link>
// //             )}
// //           </div>
// //         </div>
// //       </nav>

// //       {/* ========== MAIN CONTENT ========== */}
// //       <div style={{ minHeight: "calc(100vh - 300px)", paddingTop: "40px", paddingBottom: "40px", backgroundColor: "#f8f9fa" }}>
// //         <div className="container">
// //           <h2 style={{ textAlign: "center", marginBottom: "50px", fontSize: "2.5rem", fontWeight: "bold", color: "#333" }}>
// //             My Applications
// //           </h2>

// //           {loading ? (
// //             <div style={{ textAlign: "center", padding: "60px 20px" }}>
// //               <div style={{ fontSize: "18px", color: "#666" }}>Loading your applications...</div>
// //             </div>
// //           ) : applications.length === 0 ? (
// //             <div style={{ textAlign: "center", padding: "60px 20px", backgroundColor: "#fff", borderRadius: "10px" }}>
// //               <div style={{ fontSize: "18px", color: "#999", marginBottom: "20px" }}>No applications yet</div>
// //               <Link to="/jobs" className="btn btn-primary" style={{ backgroundColor: "#00D9A0", border: "none" }}>
// //                 Browse Jobs
// //               </Link>
// //             </div>
// //           ) : (
// //             <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "25px" }}>
// //               {applications.map((app) => {
// //                 const interview = interviews.find(
// //                   (int) => int.applicationId && String(int.applicationId._id) === String(app._id)
// //                 );
// //                 const statusColor = getStatusColor(app.status);

// //                 return (
// //                   <div
// //                     key={app._id}
// //                     style={{
// //                       background: "#fff",
// //                       borderRadius: "12px",
// //                       boxShadow: "0 4px 15px rgba(0,0,0,0.08)",
// //                       overflow: "hidden",
// //                       transition: "all 0.3s ease",
// //                       border: `4px solid ${statusColor}`,
// //                     }}
// //                     onMouseOver={(e) => {
// //                       e.currentTarget.style.boxShadow = "0 8px 25px rgba(0,0,0,0.15)";
// //                       e.currentTarget.style.transform = "translateY(-5px)";
// //                     }}
// //                     onMouseOut={(e) => {
// //                       e.currentTarget.style.boxShadow = "0 4px 15px rgba(0,0,0,0.08)";
// //                       e.currentTarget.style.transform = "translateY(0)";
// //                     }}
// //                   >
// //                     {/* Status Badge */}
// //                     <div
// //                       style={{
// //                         background: statusColor,
// //                         color: "#fff",
// //                         padding: "12px 16px",
// //                         fontSize: "14px",
// //                         fontWeight: "bold",
// //                         textAlign: "center",
// //                       }}
// //                     >
// //                       {getStatusLabel(app.status)}
// //                     </div>

// //                     {/* Card Content */}
// //                     <div style={{ padding: "20px" }}>
// //                       <h5 style={{ marginBottom: "8px", color: "#333", fontSize: "16px", fontWeight: "bold" }}>
// //                         {app.name}
// //                       </h5>

// //                       <div style={{ marginBottom: "12px" }}>
// //                         <div style={{ fontSize: "13px", color: "#666", marginBottom: "4px" }}>
// //                           <strong>Company:</strong> {app.employerId?.companyName || "N/A"}
// //                         </div>
// //                         <div style={{ fontSize: "13px", color: "#666", marginBottom: "4px" }}>
// //                           <strong>Email:</strong> {app.email}
// //                         </div>
// //                       </div>

// //                       <hr style={{ margin: "12px 0" }} />

// //                       <div style={{ marginBottom: "12px" }}>
// //                         <div style={{ fontSize: "12px", color: "#777", marginBottom: "4px" }}>
// //                           Applied: {new Date(app.createdAt).toLocaleDateString()}
// //                         </div>
// //                         {interview?.interviewDate && (
// //                           <div style={{ fontSize: "12px", color: "#777" }}>
// //                             Interview: {new Date(interview.interviewDate).toLocaleString()}
// //                           </div>
// //                         )}
// //                       </div>

// //                       {interview?.meetingLink && (
// //                         <a
// //                           href={interview.meetingLink}
// //                           target="_blank"
// //                           rel="noopener noreferrer"
// //                           style={{
// //                             display: "inline-block",
// //                             backgroundColor: "#00D9A0",
// //                             color: "#fff",
// //                             padding: "10px 16px",
// //                             borderRadius: "6px",
// //                             textDecoration: "none",
// //                             fontSize: "13px",
// //                             fontWeight: "bold",
// //                             marginTop: "10px",
// //                             transition: "all 0.3s ease",
// //                           }}
// //                           onMouseOver={(e) => {
// //                             e.target.style.backgroundColor = "#00b087";
// //                           }}
// //                           onMouseOut={(e) => {
// //                             e.target.style.backgroundColor = "#00D9A0";
// //                           }}
// //                         >
// //                           Join Meeting
// //                         </a>
// //                       )}
// //                     </div>
// //                   </div>
// //                 );
// //               })}
// //             </div>
// //           )}
// //         </div>
// //       </div>

// //       {/* ========== FOOTER ========== */}
// //       <div className="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
// //         <div className="container py-5">
// //           <div className="row g-5">
// //             <div className="col-lg-3 col-md-6">
// //               <h5 className="text-white mb-4">Company</h5>
// //               <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
// //               <Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
// //               <Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
// //             </div>
// //             <div className="col-lg-3 col-md-6">
// //               <h5 className="text-white mb-4">Quick Links</h5>
// //               <Link className="btn btn-link text-white-50" to="/">Home</Link>
// //               <Link className="btn btn-link text-white-50" to="/jobs">Browse Jobs</Link>
// //               <Link className="btn btn-link text-white-50" to="/about">About</Link>
// //             </div>
// //             <div className="col-lg-3 col-md-6">
// //               <h5 className="text-white mb-4">Contact</h5>
// //               <p className="mb-2"><i className="fa fa-map-marker-alt me-3"></i>Ahmedabad, India</p>
// //               <p className="mb-2"><i className="fa fa-phone-alt me-3"></i>+91 99021 23412</p>
// //               <p className="mb-2"><i className="fa fa-envelope me-3"></i>jobentry@email.com</p>
// //             </div>
// //             <div className="col-lg-3 col-md-6">
// //               <h5 className="text-white mb-4">Newsletter</h5>
// //               <p>Stay updated with latest job opportunities</p>
// //             </div>
// //           </div>
// //         </div>
// //         <div style={{ textAlign: "center", paddingTop: "20px", borderTop: "1px solid #444" }}>
// //           <p>&copy; 2024 JobEntry. All rights reserved.</p>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default MyApplications;
// import React, { useEffect, useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import "../css/bootstrap.min.css";
// import "../css/style.css";

// const MyApplications = () => {
//   const [applications, setApplications] = useState([]);
//   const [interviews, setInterviews] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [user, setUser] = useState(null);
//   const [isProfileOpen, setIsProfileOpen] = useState(false);
//   const [jobSeekerProfile, setJobSeekerProfile] = useState(null);
//   const [isEditOpen, setIsEditOpen] = useState(false);
//   const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
//   const [oldPassword, setOldPassword] = useState("");
//   const [newPassword, setNewPassword] = useState("");
//   const navigate = useNavigate();

//   useEffect(() => {
//     const storedUser = JSON.parse(localStorage.getItem("user"));
//     if (storedUser) {
//       setUser(storedUser);
//       fetchData(storedUser.id);
//       fetchJobSeekerProfile(storedUser.id);
//     }
//   }, []);

//   const fetchJobSeekerProfile = (userId) => {
//     fetch(`http://localhost:5000/api/profile/jobseeker/${userId}`)
//       .then((res) => res.json())
//       .then((data) => {
//         if (data.success) setJobSeekerProfile(data.profile);
//       })
//       .catch((err) => console.error("Profile fetch error:", err));
//   };

//   const fetchData = async (userId) => {
//     try {
//       const appRes = await fetch(`http://localhost:5000/api/user/applications/${userId}`);
//       const intRes = await fetch(`http://localhost:5000/api/user/interviews/${userId}`);

//       const appData = await appRes.json();
//       const intData = await intRes.json();

//       if (appData.success) setApplications(appData.applications);
//       if (intData.success) setInterviews(intData.interviews);
//     } catch (err) {
//       console.error(err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleLogout = () => {
//     localStorage.removeItem("user");
//     setUser(null);
//     navigate("/");
//   };

//   const handleProfileUpdate = (e) => {
//     e.preventDefault();
//     const formData = new FormData(e.target);
//     const updatedData = Object.fromEntries(formData.entries());

//     fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(updatedData),
//     })
//       .then((res) => res.json())
//       .then((data) => {
//         if (data.success) {
//           setJobSeekerProfile(data.profile);
//           setIsEditOpen(false);
//           alert("Profile updated successfully!");
//         }
//       })
//       .catch((err) => console.error(err));
//   };

//   const handleChangePassword = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await fetch("http://localhost:5000/api/change-password", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           userId: user.id,
//           oldPassword,
//           newPassword,
//         }),
//       });

//       const data = await res.json();
//       if (data.success) {
//         alert("Password updated successfully");
//         setIsChangePasswordOpen(false);
//         setOldPassword("");
//         setNewPassword("");
//       } else {
//         alert("Error: " + data.message);
//       }
//     } catch (err) {
//       console.error("Change Password Error:", err);
//       alert("Error updating password");
//     }
//   };

//   const getStatusColor = (status) => {
//     switch (status) {
//       case "approved":
//         return "#00D9A0";
//       case "rejected":
//         return "#e74c3c";
//       default:
//         return "#f39c12";
//     }
//   };

//   const getStatusLabel = (status) => {
//     switch (status) {
//       case "approved":
//         return "✅ Approved";
//       case "rejected":
//         return "❌ Rejected";
//       default:
//         return "⏳ Pending";
//     }
//   };

//   return (
//     <div>
//       {/* ==================== NAVBAR (SAME AS HOME) ==================== */}
//       <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
//         <Link to="/" className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
//           <h1 className="m-0 text-primary">JobEntry</h1>
//         </Link>

//         <button
//           type="button"
//           className="navbar-toggler me-4"
//           data-bs-toggle="collapse"
//           data-bs-target="#navbarCollapse"
//         >
//           <span className="navbar-toggler-icon"></span>
//         </button>

//         <div className="collapse navbar-collapse" id="navbarCollapse">
//           <div className="navbar-nav ms-auto p-4 p-lg-0">
//             {user && (
//               <span className="nav-item nav-link text-primary fw-bold me-2">
//                 Welcome, {user.firstName || user.name}
//               </span>
//             )}

//             <Link to="/" className="nav-item nav-link">Home</Link>
//             <Link to="/about" className="nav-item nav-link">About</Link>

//             <div className="nav-item dropdown">
//               <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
//                 Jobs
//               </a>
//               <div className="dropdown-menu rounded-0 m-0">
//                 <Link to="/jobs" className="dropdown-item">Job List</Link>
//                 <Link to="/jobdetails" className="dropdown-item">Job Detail</Link>
//                 {user && (
//                   <Link to="/user/applications" className="dropdown-item">
//                     My Applications
//                   </Link>
//                 )}
//               </div>
//             </div>

//             <div className="nav-item dropdown">
//               <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
//                 Pages
//               </a>
//               <div className="dropdown-menu rounded-0 m-0">
//                 <Link to="/category" className="dropdown-item">Job Category</Link>
//                 <Link to="/testimonial" className="dropdown-item">Testimonial</Link>
//                 <Link to="/404" className="dropdown-item">404</Link>
//               </div>
//             </div>

//             <Link to="/contact" className="nav-item nav-link">Contact</Link>

//             {user ? (
//               <div className="nav-item dropdown" style={{ position: "relative" }}>
//                 <a
//                   href="#"
//                   className="nav-link dropdown-toggle d-flex align-items-center"
//                   onClick={(e) => {
//                     e.preventDefault();
//                     setIsProfileOpen(!isProfileOpen);
//                   }}
//                 >
//                   {user.avatar ? (
//                     <img
//                       src={user.avatar}
//                       alt="profile"
//                       style={{
//                         width: "35px",
//                         height: "35px",
//                         borderRadius: "50%",
//                         marginRight: "8px",
//                         cursor: "pointer",
//                       }}
//                     />
//                   ) : (
//                     <div
//                       style={{
//                         width: "35px",
//                         height: "35px",
//                         borderRadius: "50%",
//                         background: "#ddd",
//                         display: "flex",
//                         alignItems: "center",
//                         justifyContent: "center",
//                         marginRight: "8px",
//                         cursor: "pointer",
//                         fontSize: "16px",
//                         fontWeight: "bold",
//                         color: "#555",
//                       }}
//                     >
//                       👤
//                     </div>
//                   )}
//                 </a>

//                 {isProfileOpen && (
//                   <div
//                     style={{
//                       position: "absolute",
//                       top: "50px",
//                       right: 0,
//                       background: "#fff",
//                       boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
//                       borderRadius: "10px",
//                       minWidth: "300px",
//                       zIndex: 100,
//                       overflow: "hidden",
//                       fontFamily: "Segoe UI, sans-serif",
//                     }}
//                   >
//                     <div
//                       style={{
//                         padding: "15px",
//                         borderBottom: "1px solid #eee",
//                         background: "#f9f9f9",
//                       }}
//                     >
//                       <strong style={{ fontSize: "16px", color: "#333" }}>
//                         {user.firstName} {user.lastName}
//                       </strong>
//                       <div style={{ fontSize: "13px", color: "#777" }}>
//                         {user.email}
//                       </div>
//                     </div>

//                     {jobSeekerProfile ? (
//                       <div style={{ padding: "12px 16px", fontSize: "14px", color: "#444", maxHeight: "300px", overflowY: "auto" }}>
//                         {jobSeekerProfile.bio && <p style={{ margin: "4px 0" }}>📝 <strong>Bio:</strong> {jobSeekerProfile.bio}</p>}
//                         {jobSeekerProfile.skills && <p style={{ margin: "4px 0" }}>🛠️ <strong>Skills:</strong> {jobSeekerProfile.skills}</p>}
//                         {jobSeekerProfile.experience && <p style={{ margin: "4px 0" }}>💼 <strong>Exp:</strong> {jobSeekerProfile.experience}</p>}
//                       </div>
//                     ) : (
//                       <div style={{ padding: "12px 16px", color: "#888" }}>
//                         No profile found
//                       </div>
//                     )}

//                     <button
//                       onClick={() => setIsEditOpen(true)}
//                       style={{
//                         width: "100%",
//                         background: "none",
//                         border: "none",
//                         color: "#3498db",
//                         padding: "12px 16px",
//                         textAlign: "left",
//                         cursor: "pointer",
//                         fontWeight: "bold",
//                         borderTop: "1px solid #eee",
//                       }}
//                     >
//                       Edit Profile
//                     </button>

//                     <button
//                       onClick={() => setIsChangePasswordOpen(true)}
//                       style={{
//                         width: "100%",
//                         background: "none",
//                         border: "none",
//                         color: "#f39c12",
//                         padding: "12px 16px",
//                         textAlign: "left",
//                         cursor: "pointer",
//                         fontWeight: "bold",
//                         borderTop: "1px solid #eee",
//                       }}
//                     >
//                       Change Password
//                     </button>

//                     <button
//                       onClick={handleLogout}
//                       style={{
//                         width: "100%",
//                         background: "none",
//                         border: "none",
//                         color: "#e74c3c",
//                         padding: "12px 16px",
//                         textAlign: "left",
//                         cursor: "pointer",
//                         fontWeight: "bold",
//                         borderTop: "1px solid #eee",
//                       }}
//                     >
//                       Logout
//                     </button>
//                   </div>
//                 )}
//               </div>
//             ) : (
//               <Link to="/signin" className="nav-item nav-link">Login</Link>
//             )}
//           </div>

//           <Link
//             to="/category"
//             className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"
//             style={{ backgroundColor: "#00D9A0", borderColor: "#00D9A0" }}
//           >
//             Post A Job <i className="fa fa-arrow-right ms-3"></i>
//           </Link>
//         </div>
//       </nav>

//       {/* ==================== EDIT PROFILE MODAL ==================== */}
//       {isEditOpen && (
//         <div
//           style={{
//             position: "fixed",
//             top: 0,
//             left: 0,
//             width: "100%",
//             height: "100%",
//             background: "rgba(0,0,0,0.5)",
//             display: "flex",
//             justifyContent: "center",
//             alignItems: "center",
//             zIndex: 200,
//           }}
//         >
//           <div
//             style={{
//               background: "#fff",
//               padding: "20px",
//               borderRadius: "8px",
//               width: "400px",
//               maxHeight: "90vh",
//               overflowY: "auto",
//             }}
//           >
//             <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
//               Edit JobSeeker Profile
//             </h4>

//             <form onSubmit={handleProfileUpdate}>
//               <label>Bio</label>
//               <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <label>Skills</label>
//               <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <label>Experience</label>
//               <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <label>Education</label>
//               <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <label>Phone</label>
//               <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <label>LinkedIn</label>
//               <input type="text" name="linkedin" defaultValue={jobSeekerProfile?.linkedin} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <label>GitHub</label>
//               <input type="text" name="github" defaultValue={jobSeekerProfile?.github} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <label>Resume</label>
//               <input type="text" name="resume" defaultValue={jobSeekerProfile?.resume} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

//               <div style={{ textAlign: "right", marginTop: "10px" }}>
//                 <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px", padding: "8px 12px", cursor: "pointer" }}>
//                   Cancel
//                 </button>
//                 <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "8px 12px", border: "none", borderRadius: "4px", cursor: "pointer" }}>
//                   Save
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}

//       {/* ==================== CHANGE PASSWORD MODAL ==================== */}
//       {isChangePasswordOpen && (
//         <div style={{
//           position: "fixed",
//           top: 0, left: 0, width: "100%", height: "100%",
//           background: "rgba(0,0,0,0.5)", display: "flex",
//           justifyContent: "center", alignItems: "center", zIndex: 200
//         }}>
//           <div style={{
//             background: "#fff", padding: "20px",
//             borderRadius: "8px", width: "400px"
//           }}>
//             <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>Change Password</h4>
//             <form onSubmit={handleChangePassword}>
//               <input
//                 type="password"
//                 placeholder="Old Password"
//                 value={oldPassword}
//                 onChange={(e) => setOldPassword(e.target.value)}
//                 style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
//                 required
//               />
//               <input
//                 type="password"
//                 placeholder="New Password"
//                 value={newPassword}
//                 onChange={(e) => setNewPassword(e.target.value)}
//                 style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
//                 required
//               />
//               <button type="submit" style={{
//                 padding: "8px 12px",
//                 background: "#00D9A0", color: "#fff",
//                 border: "none", borderRadius: "4px", cursor: "pointer"
//               }}>
//                 Save
//               </button>
//               <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
//                 padding: "8px 12px", marginLeft: "10px",
//                 background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
//               }}>
//                 Cancel
//               </button>
//             </form>
//           </div>
//         </div>
//       )}

//       {/* ==================== MAIN CONTENT ==================== */}
//       <div style={{ minHeight: "calc(100vh - 300px)", paddingTop: "60px", paddingBottom: "60px", backgroundColor: "#f8f9fa" }}>
//         <div className="container">
//           <h1 style={{ textAlign: "center", marginBottom: "50px", fontSize: "2.5rem", fontWeight: "bold", color: "#333" }}>
//             My Applications
//           </h1>

//           {loading ? (
//             <div style={{ textAlign: "center", padding: "80px 20px" }}>
//               <div style={{ fontSize: "18px", color: "#666" }}>Loading your applications...</div>
//             </div>
//           ) : applications.length === 0 ? (
//             <div style={{ textAlign: "center", padding: "80px 20px", backgroundColor: "#fff", borderRadius: "10px" }}>
//               <div style={{ fontSize: "18px", color: "#999", marginBottom: "20px" }}>No applications found</div>
//               <Link to="/jobs" className="btn btn-primary" style={{ backgroundColor: "#00D9A0", border: "none", padding: "10px 30px" }}>
//                 Browse Jobs
//               </Link>
//             </div>
//           ) : (
//             <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "25px" }}>
//               {applications.map((app) => {
//                 const interview = interviews.find(
//                   (int) => int.applicationId && String(int.applicationId._id) === String(app._id)
//                 );
//                 const statusColor = getStatusColor(app.status);

//                 return (
//                   <div
//                     key={app._id}
//                     style={{
//                       background: "#fff",
//                       borderRadius: "12px",
//                       boxShadow: "0 4px 15px rgba(0,0,0,0.08)",
//                       overflow: "hidden",
//                       transition: "all 0.3s ease",
//                       border: `4px solid ${statusColor}`,
//                     }}
//                     onMouseOver={(e) => {
//                       e.currentTarget.style.boxShadow = "0 8px 25px rgba(0,0,0,0.15)";
//                       e.currentTarget.style.transform = "translateY(-5px)";
//                     }}
//                     onMouseOut={(e) => {
//                       e.currentTarget.style.boxShadow = "0 4px 15px rgba(0,0,0,0.08)";
//                       e.currentTarget.style.transform = "translateY(0)";
//                     }}
//                   >
//                     {/* Status Badge */}
//                     <div
//                       style={{
//                         background: statusColor,
//                         color: "#fff",
//                         padding: "12px 16px",
//                         fontSize: "14px",
//                         fontWeight: "bold",
//                         textAlign: "center",
//                       }}
//                     >
//                       {getStatusLabel(app.status)}
//                     </div>

//                     {/* Card Content */}
//                     <div style={{ padding: "20px" }}>
//                       <h5 style={{ marginBottom: "8px", color: "#333", fontSize: "16px", fontWeight: "bold" }}>
//                         {app.name}
//                       </h5>

//                       <div style={{ marginBottom: "12px" }}>
//                         <div style={{ fontSize: "13px", color: "#666", marginBottom: "4px" }}>
//                           <strong>Company:</strong> {app.employerId?.companyName || "N/A"}
//                         </div>
//                         <div style={{ fontSize: "13px", color: "#666", marginBottom: "4px" }}>
//                           <strong>Email:</strong> {app.email}
//                         </div>
//                       </div>

//                       <hr style={{ margin: "12px 0" }} />

//                       <div style={{ marginBottom: "12px" }}>
//                         <div style={{ fontSize: "12px", color: "#777", marginBottom: "4px" }}>
//                           Applied: {new Date(app.createdAt).toLocaleDateString()}
//                         </div>
//                         {interview?.interviewDate && (
//                           <div style={{ fontSize: "12px", color: "#777" }}>
//                             Interview: {new Date(interview.interviewDate).toLocaleString()}
//                           </div>
//                         )}
//                       </div>

//                       {interview?.meetingLink && (
//                         <a
//                           href={interview.meetingLink}
//                           target="_blank"
//                           rel="noopener noreferrer"
//                           style={{
//                             display: "inline-block",
//                             backgroundColor: "#00D9A0",
//                             color: "#fff",
//                             padding: "10px 16px",
//                             borderRadius: "6px",
//                             textDecoration: "none",
//                             fontSize: "13px",
//                             fontWeight: "bold",
//                             marginTop: "10px",
//                             transition: "all 0.3s ease",
//                           }}
//                           onMouseOver={(e) => {
//                             e.target.style.backgroundColor = "#00b087";
//                           }}
//                           onMouseOut={(e) => {
//                             e.target.style.backgroundColor = "#00D9A0";
//                           }}
//                         >
//                           Join Meeting
//                         </a>
//                       )}
//                     </div>
//                   </div>
//                 );
//               })}
//             </div>
//           )}
//         </div>
//       </div>

//       {/* ==================== FOOTER (SAME AS HOME) ==================== */}
//       <div className="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
//         <div className="container py-5">
//           <div className="row g-5">
//             <div className="col-lg-3 col-md-6">
//               <h5 className="text-white mb-4">Company</h5>
//               <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
//               <Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
//               <Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
//               <Link className="btn btn-link text-white-50" to="/privacy-policy">Privacy Policy</Link>
//               <Link className="btn btn-link text-white-50" to="/testimonial">Terms & Condition</Link>
//             </div>
//             <div className="col-lg-3 col-md-6">
//               <h5 className="text-white mb-4">Quick Links</h5>
//               <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
//               <Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
//               <Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
//               <Link className="btn btn-link text-white-50" to="/privacy-policy">Privacy Policy</Link>
//               <Link className="btn btn-link text-white-50" to="/testimonial">Terms & Condition</Link>
//             </div>
//             <div className="col-lg-3 col-md-6">
//               <h5 className="text-white mb-4">Contact</h5>
//               <p className="mb-2"><i className="fa fa-map-marker-alt me-3"></i>123 Ahmedabad, India</p>
//               <p className="mb-2"><i className="fa fa-phone-alt me-3"></i>+91 99021 23412</p>
//               <p className="mb-2"><i className="fa fa-envelope me-3"></i>jobentry@email.com</p>
//               <div className="d-flex pt-2">
//                 <a className="btn btn-outline-light btn-social" href="https://twitter.com" target="_blank" rel="noopener noreferrer">
//                   <i className="fab fa-twitter"></i>
//                 </a>
//                 <a className="btn btn-outline-light btn-social" href="https://facebook.com" target="_blank" rel="noopener noreferrer">
//                   <i className="fab fa-facebook-f"></i>
//                 </a>
//                 <a className="btn btn-outline-light btn-social" href="https://youtube.com" target="_blank" rel="noopener noreferrer">
//                   <i className="fab fa-youtube"></i>
//                 </a>
//                 <a className="btn btn-outline-light btn-social" href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
//                   <i className="fab fa-linkedin-in"></i>
//                 </a>
//               </div>
//             </div>
//             <div className="col-lg-3 col-md-6">
//               <h5 className="text-white mb-4">Newsletter</h5>
//               <p>Stay updated with latest job opportunities.</p>
//               <div className="position-relative mx-auto" style={{ maxWidth: "400px" }}>
//                 <input
//                   className="form-control bg-transparent w-100 py-3 ps-4 pe-5"
//                   type="text"
//                   placeholder="Your email"
//                 />
//                 <button
//                   type="button"
//                   className="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2"
//                   onClick={() => navigate("/signin")}
//                 >
//                   SignUp
//                 </button>
//               </div>
//             </div>
//           </div>
//         </div>
//         <div style={{ textAlign: "center", paddingTop: "20px", borderTop: "1px solid #444" }}>
//           <p>&copy; 2024 JobEntry. All rights reserved.</p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default MyApplications;

import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../css/bootstrap.min.css";
import "../css/style.css";

const MyApplications = () => {
  const [applications, setApplications] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [jobSeekerProfile, setJobSeekerProfile] = useState(null);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser(storedUser);
      fetchData(storedUser.id);
      fetchJobSeekerProfile(storedUser.id);
    }
  }, []);

  const fetchJobSeekerProfile = (userId) => {
    fetch(`http://localhost:5000/api/profile/jobseeker/${userId}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setJobSeekerProfile(data.profile);
      })
      .catch((err) => console.error("Profile fetch error:", err));
  };

  const fetchData = async (userId) => {
    try {
      const appRes = await fetch(`http://localhost:5000/api/user/applications/${userId}`);
      const intRes = await fetch(`http://localhost:5000/api/user/interviews/${userId}`);

      const appData = await appRes.json();
      const intData = await intRes.json();

      if (appData.success) setApplications(appData.applications);
      if (intData.success) setInterviews(intData.interviews);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/");
  };

  const handleProfileUpdate = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const updatedData = Object.fromEntries(formData.entries());

    fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedData),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setJobSeekerProfile(data.profile);
          setIsEditOpen(false);
          alert("Profile updated successfully!");
        }
      })
      .catch((err) => console.error(err));
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          oldPassword,
          newPassword,
        }),
      });

      const data = await res.json();
      if (data.success) {
        alert("Password updated successfully");
        setIsChangePasswordOpen(false);
        setOldPassword("");
        setNewPassword("");
      } else {
        alert("Error: " + data.message);
      }
    } catch (err) {
      console.error("Change Password Error:", err);
      alert("Error updating password");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "approved":
        return "#00D9A0";
      case "rejected":
        return "#e74c3c";
      default:
        return "#f39c12";
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case "approved":
        return "✅ Approved";
      case "rejected":
        return "❌ Rejected";
      default:
        return "⏳ Pending";
    }
  };

  return (
    <div>
      {/* ==================== NAVBAR (SAME AS HOME) ==================== */}
     <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
       <Link
         to="/"
         className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5"
       >
         <h1 className="m-0 text-primary">JobEntry</h1>
       </Link>
     
       <button
         type="button"
         className="navbar-toggler me-4"
         data-bs-toggle="collapse"
         data-bs-target="#navbarCollapse"
       >
         <span className="navbar-toggler-icon"></span>
       </button>
     
       <div className="collapse navbar-collapse" id="navbarCollapse">
         <div className="navbar-nav ms-auto p-4 p-lg-0">
           {user && (
             <span className="nav-item nav-link text-primary fw-bold me-2">
               Welcome, {user.firstName || user.name}
             </span>
           )}
     
           <Link to="/" className="nav-item nav-link">Home</Link>
           <Link to="/about" className="nav-item nav-link">About</Link>
     
           <div className="nav-item dropdown">
             <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
               Jobs
             </a>
             <div className="dropdown-menu rounded-0 m-0">
               <Link to="/jobs" className="dropdown-item">Job List</Link>
               <Link to="/jobdetails" className="dropdown-item">Job Detail</Link>
               {user && (
       <Link to="/user/applications" className="nav-item nav-link">
         My Applications
       </Link>
     )}
             </div>
           </div>
     
     
           <div className="nav-item dropdown">
             <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
               Pages
             </a>
             <div className="dropdown-menu rounded-0 m-0">
               <Link to="/category" className="dropdown-item">Job Category</Link>
               <Link to="/testimonial" className="dropdown-item">Testimonial</Link>
               <Link to="/404" className="dropdown-item">404</Link>
             </div>
           </div>
     
           <Link to="/contact" className="nav-item nav-link">Contact</Link>
     
           {/* Profile / Login */}
           {user ? (
             <div className="nav-item dropdown" style={{ position: "relative" }}>
               <a
                 href="#"
                 className="nav-link dropdown-toggle d-flex align-items-center"
                 onClick={(e) => {
                   e.preventDefault();
                   setIsProfileOpen(!isProfileOpen);
                 }}
               >
                 {user.avatar ? (
       <img
         src={user.avatar}
         alt="profile"
         style={{
           width: "35px",
           height: "35px",
           borderRadius: "50%",
           marginRight: "8px",
           cursor: "pointer",
         }}
       />
     ) : (
       <div
         style={{
           width: "35px",
           height: "35px",
           borderRadius: "50%",
           background: "#ddd",
           display: "flex",
           alignItems: "center",
           justifyContent: "center",
           marginRight: "8px",
           cursor: "pointer",
           fontSize: "16px",
           fontWeight: "bold",
           color: "#555",
         }}
       >
         👤
       </div>
     )}
     
               </a>
     
     {isProfileOpen && (
       <div
         style={{
           position: "absolute",
           top: "50px",
           right: 0,
           background: "#fff",
           boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
           borderRadius: "10px",
           minWidth: "300px",
           zIndex: 100,
           overflow: "hidden",
           fontFamily: "Segoe UI, sans-serif",
         }}
       >
        
         <div
           style={{
             padding: "15px",
             borderBottom: "1px solid #eee",
             background: "#f9f9f9",
           }}
         >
           <strong style={{ fontSize: "16px", color: "#333" }}>
             {user.firstName} {user.lastName}
           </strong>
           <div style={{ fontSize: "13px", color: "#777" }}>
             {user.email}
           </div>
         </div>
     
         {jobSeekerProfile ? (
           <div style={{ padding: "12px 16px", fontSize: "14px", color: "#444" }}>
             {jobSeekerProfile.bio && <p>📝 <strong>Bio:</strong> {jobSeekerProfile.bio}</p>}
             {jobSeekerProfile.skills && <p>🛠️ <strong>Skills:</strong> {jobSeekerProfile.skills}</p>}
             {jobSeekerProfile.experience && <p>💼 <strong>Experience:</strong> {jobSeekerProfile.experience}</p>}
             {jobSeekerProfile.education && <p>🎓 <strong>Education:</strong> {jobSeekerProfile.education}</p>}
             {jobSeekerProfile.phone && <p>📞 <strong>Phone:</strong> {jobSeekerProfile.phone}</p>}
             {jobSeekerProfile.location && (
               <p>🌍 <strong>Location:</strong> {jobSeekerProfile.location.city}, {jobSeekerProfile.location.state}, {jobSeekerProfile.location.country}</p>
             )}
             {jobSeekerProfile.linkedin && (
               <p>🔗 <a href={jobSeekerProfile.linkedin} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>LinkedIn</a></p>
             )}
             {jobSeekerProfile.github && (
               <p>💻 <a href={jobSeekerProfile.github} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>GitHub</a></p>
             )}
             {jobSeekerProfile.resume && (
               <p>📄 <a href={jobSeekerProfile.resume} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>View Resume</a></p>
             )}
             {jobSeekerProfile.expectedSalary && <p>💰 {jobSeekerProfile.expectedSalary}</p>}
             {jobSeekerProfile.availability && <p>⏳ {jobSeekerProfile.availability}</p>}
           </div>
         ) : (
           <div style={{ padding: "12px 16px", color: "#888" }}>
             ⚠️ No profile found
           </div>
         )}
     
        
         <button
           onClick={() => setIsEditOpen(true)}
           style={{
             width: "100%",
             background: "none",
             border: "none",
             color: "#3498db",
             padding: "12px 16px",
             textAlign: "left",
             cursor: "pointer",
             fontWeight: "bold",
             borderTop: "1px solid #eee",
           }}
         >
           ✏️ Edit Profile
         </button>
     
     
         <button
           onClick={() => setIsChangePasswordOpen(true)}
           style={{
             width: "100%",
             background: "none",
             border: "none",
             color: "#f39c12",
             padding: "12px 16px",
             textAlign: "left",
             cursor: "pointer",
             fontWeight: "bold",
             borderTop: "1px solid #eee",
           }}
         >
           🔑 Change Password
         </button>
     
         <button
           onClick={handleLogout}
           style={{
             width: "100%",
             background: "none",
             border: "none",
             color: "#e74c3c",
             padding: "12px 16px",
             textAlign: "left",
             cursor: "pointer",
             fontWeight: "bold",
             borderTop: "1px solid #eee",
           }}
         >
           🚪 Logout
         </button>
       </div>
     )}
     
             </div>
           ) : (
             <Link to="/signin" className="nav-item nav-link">Login</Link>
           )}
         </div>
     
         <Link
           to="/Category"
           className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"
           style={{ backgroundColor: "#00D9A0", borderColor: "#00D9A0" }}
         >
           Post A Job <i className="fa fa-arrow-right ms-3"></i>
         </Link>
       </div>
     {/* Change Password Modal */}
     {isChangePasswordOpen && (
       <div style={{
         position: "fixed",
         top: 0, left: 0, width: "100%", height: "100%",
         background: "rgba(0,0,0,0.5)", display: "flex",
         justifyContent: "center", alignItems: "center", zIndex: 200
       }}>
         <div style={{
           background: "#fff", padding: "20px",
           borderRadius: "8px", width: "400px"
         }}>
           <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>🔒 Change Password</h4>
           <form onSubmit={handleChangePassword}>
             <input
               type="password"
               placeholder="Old Password"
               value={oldPassword}
               onChange={(e) => setOldPassword(e.target.value)}
               style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
               required
             />
             <input
               type="password"
               placeholder="New Password"
               value={newPassword}
               onChange={(e) => setNewPassword(e.target.value)}
               style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
               required
             />
             <button type="submit" style={{
               padding: "8px 12px",
               background: "#00D9A0", color: "#fff",
               border: "none", borderRadius: "4px", cursor: "pointer"
             }}>
               Save
             </button>
             <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
               padding: "8px 12px", marginLeft: "10px",
               background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
             }}>
               Cancel
             </button>
           </form>
         </div>
       </div>
     )}
     
     
       {/* Edit Profile Modal with form */}
       {isEditOpen && (
         <div
           style={{
             position: "fixed",
             top: 0,
             left: 0,
             width: "100%",
             height: "100%",
             background: "rgba(0,0,0,0.5)",
             display: "flex",
             justifyContent: "center",
             alignItems: "center",
             zIndex: 200,
           }}
         >
           <div
             style={{
               background: "#fff",
               padding: "20px",
               borderRadius: "8px",
               width: "400px",
               maxHeight: "90vh",
               overflowY: "auto",
             }}
           >
             <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
               ✏️ Edit JobSeeker Profile
             </h4>
     
             <form onSubmit={handleProfileUpdate}>
               <label>Bio</label>
               <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Skills</label>
               <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Experience</label>
               <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Education</label>
               <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Phone</label>
               <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>LinkedIn</label>
               <input type="text" name="linkedin" defaultValue={jobSeekerProfile?.linkedin} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>GitHub</label>
               <input type="text" name="github" defaultValue={jobSeekerProfile?.github} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Resume</label>
               <input type="text" name="resume" defaultValue={jobSeekerProfile?.resume} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Expected Salary</label>
               <input type="text" name="expectedSalary" defaultValue={jobSeekerProfile?.expectedSalary} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Availability</label>
               <input type="text" name="availability" defaultValue={jobSeekerProfile?.availability} style={{ width: "100%", marginBottom: "10px" }} />
     
               <div style={{ textAlign: "right", marginTop: "10px" }}>
                 <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px" }}>
                   Cancel
                 </button>
                 <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "6px 12px", border: "none", borderRadius: "4px" }}>
                   Save
                 </button>
               </div>
             </form>
           </div>
         </div>
       )}
     </nav>

      {/* ==================== EDIT PROFILE MODAL ==================== */}
      {isEditOpen && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 200,
          }}
        >
          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "8px",
              width: "400px",
              maxHeight: "90vh",
              overflowY: "auto",
            }}
          >
            <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
              Edit JobSeeker Profile
            </h4>

            <form onSubmit={handleProfileUpdate}>
              <label>Bio</label>
              <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <label>Skills</label>
              <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <label>Experience</label>
              <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <label>Education</label>
              <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <label>Phone</label>
              <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <label>LinkedIn</label>
              <input type="text" name="linkedin" defaultValue={jobSeekerProfile?.linkedin} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <label>GitHub</label>
              <input type="text" name="github" defaultValue={jobSeekerProfile?.github} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <label>Resume</label>
              <input type="text" name="resume" defaultValue={jobSeekerProfile?.resume} style={{ width: "100%", marginBottom: "10px", padding: "8px" }} />

              <div style={{ textAlign: "right", marginTop: "10px" }}>
                <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px", padding: "8px 12px", cursor: "pointer" }}>
                  Cancel
                </button>
                <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "8px 12px", border: "none", borderRadius: "4px", cursor: "pointer" }}>
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== CHANGE PASSWORD MODAL ==================== */}
      {isChangePasswordOpen && (
        <div style={{
          position: "fixed",
          top: 0, left: 0, width: "100%", height: "100%",
          background: "rgba(0,0,0,0.5)", display: "flex",
          justifyContent: "center", alignItems: "center", zIndex: 200
        }}>
          <div style={{
            background: "#fff", padding: "20px",
            borderRadius: "8px", width: "400px"
          }}>
            <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>Change Password</h4>
            <form onSubmit={handleChangePassword}>
              <input
                type="password"
                placeholder="Old Password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
                required
              />
              <input
                type="password"
                placeholder="New Password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
                required
              />
              <button type="submit" style={{
                padding: "8px 12px",
                background: "#00D9A0", color: "#fff",
                border: "none", borderRadius: "4px", cursor: "pointer"
              }}>
                Save
              </button>
              <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
                padding: "8px 12px", marginLeft: "10px",
                background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
              }}>
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ==================== MAIN CONTENT ==================== */}
      <div style={{ minHeight: "calc(100vh - 300px)", paddingTop: "60px", paddingBottom: "60px", backgroundColor: "#f8f9fa" }}>
        <div className="container">
          <h1 style={{ textAlign: "center", marginBottom: "50px", fontSize: "2.5rem", fontWeight: "bold", color: "#333" }}>
            My Applications
          </h1>

          {loading ? (
            <div style={{ textAlign: "center", padding: "80px 20px" }}>
              <div style={{ fontSize: "18px", color: "#666" }}>Loading your applications...</div>
            </div>
          ) : applications.length === 0 ? (
            <div style={{ textAlign: "center", padding: "80px 20px", backgroundColor: "#fff", borderRadius: "10px" }}>
              <div style={{ fontSize: "18px", color: "#999", marginBottom: "20px" }}>No applications found</div>
              <Link to="/jobs" className="btn btn-primary" style={{ backgroundColor: "#00D9A0", border: "none", padding: "10px 30px" }}>
                Browse Jobs
              </Link>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "25px" }}>
              {applications.map((app) => {
                const interview = interviews.find(
                  (int) => int.applicationId && String(int.applicationId._id) === String(app._id)
                );
                const statusColor = getStatusColor(app.status);

                return (
                  <div
                    key={app._id}
                    style={{
                      background: "#fff",
                      borderRadius: "12px",
                      boxShadow: "0 4px 15px rgba(0,0,0,0.08)",
                      overflow: "hidden",
                      transition: "all 0.3s ease",
                      border: `4px solid ${statusColor}`,
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.boxShadow = "0 8px 25px rgba(0,0,0,0.15)";
                      e.currentTarget.style.transform = "translateY(-5px)";
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.boxShadow = "0 4px 15px rgba(0,0,0,0.08)";
                      e.currentTarget.style.transform = "translateY(0)";
                    }}
                  >
                    {/* Status Badge */}
                    <div
                      style={{
                        background: statusColor,
                        color: "#fff",
                        padding: "12px 16px",
                        fontSize: "14px",
                        fontWeight: "bold",
                        textAlign: "center",
                      }}
                    >
                      {getStatusLabel(app.status)}
                    </div>

                    {/* Card Content */}
                    <div style={{ padding: "20px" }}>
                      <h5 style={{ marginBottom: "8px", color: "#333", fontSize: "16px", fontWeight: "bold" }}>
                        {app.name}
                      </h5>

                      <div style={{ marginBottom: "12px" }}>
                        <div style={{ fontSize: "13px", color: "#666", marginBottom: "4px" }}>
                          <strong>Company:</strong> {app.employerId?.companyName || "N/A"}
                        </div>
                        <div style={{ fontSize: "13px", color: "#666", marginBottom: "4px" }}>
                          <strong>Email:</strong> {app.email}
                        </div>
                      </div>

                      <hr style={{ margin: "12px 0" }} />

                      <div style={{ marginBottom: "12px" }}>
                        <div style={{ fontSize: "12px", color: "#777", marginBottom: "4px" }}>
                          Applied: {new Date(app.createdAt).toLocaleDateString()}
                        </div>
                        {interview?.interviewDate && (
                          <div style={{ fontSize: "12px", color: "#777" }}>
                            Interview: {new Date(interview.interviewDate).toLocaleString()}
                          </div>
                        )}
                      </div>

                      {interview?.meetingLink && (
                        <a
                          href={interview.meetingLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            display: "inline-block",
                            backgroundColor: "#00D9A0",
                            color: "#fff",
                            padding: "10px 16px",
                            borderRadius: "6px",
                            textDecoration: "none",
                            fontSize: "13px",
                            fontWeight: "bold",
                            marginTop: "10px",
                            transition: "all 0.3s ease",
                          }}
                          onMouseOver={(e) => {
                            e.target.style.backgroundColor = "#00b087";
                          }}
                          onMouseOut={(e) => {
                            e.target.style.backgroundColor = "#00D9A0";
                          }}
                        >
                          Join Meeting
                        </a>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ==================== FOOTER (SAME AS HOME) ==================== */}
      <div className="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
        <div className="container py-5">
          <div className="row g-5">
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Company</h5>
              <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
              <Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
              <Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
              <Link className="btn btn-link text-white-50" to="/privacy-policy">Privacy Policy</Link>
              <Link className="btn btn-link text-white-50" to="/testimonial">Terms & Condition</Link>
            </div>
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Quick Links</h5>
              <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
              <Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
              <Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
              <Link className="btn btn-link text-white-50" to="/privacy-policy">Privacy Policy</Link>
              <Link className="btn btn-link text-white-50" to="/testimonial">Terms & Condition</Link>
            </div>
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Contact</h5>
              <p className="mb-2"><i className="fa fa-map-marker-alt me-3"></i>123 Ahmedabad, India</p>
              <p className="mb-2"><i className="fa fa-phone-alt me-3"></i>+91 99021 23412</p>
              <p className="mb-2"><i className="fa fa-envelope me-3"></i>jobentry@email.com</p>
              <div className="d-flex pt-2">
                <a className="btn btn-outline-light btn-social" href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                  <i className="fab fa-twitter"></i>
                </a>
                <a className="btn btn-outline-light btn-social" href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a className="btn btn-outline-light btn-social" href="https://youtube.com" target="_blank" rel="noopener noreferrer">
                  <i className="fab fa-youtube"></i>
                </a>
                <a className="btn btn-outline-light btn-social" href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              </div>
            </div>
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Newsletter</h5>
              <p>Stay updated with latest job opportunities.</p>
              <div className="position-relative mx-auto" style={{ maxWidth: "400px" }}>
                <input
                  className="form-control bg-transparent w-100 py-3 ps-4 pe-5"
                  type="text"
                  placeholder="Your email"
                />
                <button
                  type="button"
                  className="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2"
                  onClick={() => navigate("/signin")}
                >
                  SignUp
                </button>
              </div>
            </div>
          </div>
        </div>
        <div style={{ textAlign: "center", paddingTop: "20px", borderTop: "1px solid #444" }}>
          <p>&copy; 2024 JobEntry. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default MyApplications;