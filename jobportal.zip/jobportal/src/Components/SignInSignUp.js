// // // import React, { useState, useEffect } from 'react';
// // // import './SignInSignUp.css';

// // // const SignInSignUp = () => {
// // //   const [activeTab, setActiveTab] = useState('login');
// // //   const [formData, setFormData] = useState({
// // //     email: '',
// // //     password: '',
// // //     firstName: '',
// // //     lastName: '',
// // //     signupEmail: '',
// // //     signupPassword: '',
// // //     confirmPassword: '',
// // //     remember: false,
// // //     terms: false
// // //   });

// // //   const switchTab = (tab) => {
// // //     setActiveTab(tab);
// // //   };

// // //   const handleInputChange = (e) => {
// // //     const { name, value, type, checked } = e.target;
// // //     setFormData(prev => ({
// // //       ...prev,
// // //       [name]: type === 'checkbox' ? checked : value
// // //     }));
// // //   };

// // //   const handleLoginSubmit = (e) => {
// // //     e.preventDefault();
// // //     console.log('Login submitted:', {
// // //       email: formData.email,
// // //       password: formData.password,
// // //       remember: formData.remember
// // //     });
// // //     // Add your login logic here
// // //   };

// // //   const handleSignupSubmit = (e) => {
// // //     e.preventDefault();
// // //     console.log('Signup submitted:', {
// // //       firstName: formData.firstName,
// // //       lastName: formData.lastName,
// // //       email: formData.signupEmail,
// // //       password: formData.signupPassword,
// // //       terms: formData.terms
// // //     });
// // //     // Add your signup logic here
// // //   };

// // //   useEffect(() => {
// // //     // Add interactive effects to inputs
// // //     const inputs = document.querySelectorAll('input');
// // //     inputs.forEach(input => {
// // //       const handleFocus = () => {
// // //         input.parentElement.style.transform = 'translateY(-2px)';
// // //       };
      
// // //       const handleBlur = () => {
// // //         input.parentElement.style.transform = 'translateY(0)';
// // //       };

// // //       input.addEventListener('focus', handleFocus);
// // //       input.addEventListener('blur', handleBlur);

// // //       return () => {
// // //         input.removeEventListener('focus', handleFocus);
// // //         input.removeEventListener('blur', handleBlur);
// // //       };
// // //     });
// // //   }, []);

// // //   return (
// // //     <div className="signin-signup-container">
// // //       <div className="container">
// // //         <div className="left-section">
// // //           <div className="logo">JobEntry</div>
// // //           <div className="hero-content">
// // //             <h1 className="hero-title">Find The Perfect Job That You Deserved</h1>
// // //             <p className="hero-subtitle">
// // //               Join thousands of professionals who have found their dream careers through our platform. 
// // //               Your next opportunity is just a click away.
// // //             </p>
// // //           </div>
// // //           <div className="business-icons">
// // //             <div className="icon-circle">👥</div>
// // //             <div className="icon-circle">💼</div>
// // //             <div className="icon-circle">🚀</div>
// // //           </div>
// // //         </div>

// // //         <div className="right-section">
// // //           <div className="form-header">
// // //             <div className="form-tabs">
// // //               <div 
// // //                 className={`tab ${activeTab === 'login' ? 'active' : ''}`} 
// // //                 onClick={() => switchTab('login')}
// // //               >
// // //                 Login
// // //               </div>
// // //               <div 
// // //                 className={`tab ${activeTab === 'signup' ? 'active' : ''}`} 
// // //                 onClick={() => switchTab('signup')}
// // //               >
// // //                 Sign Up
// // //               </div>
// // //             </div>
// // //           </div>

// // //           {/* Login Form */}
// // //           {activeTab === 'login' && (
// // //             <div className="login-form active">
// // //               <div style={{ textAlign: 'center', marginBottom: '30px' }}>
// // //                 <h2 className="form-title">Welcome Back!</h2>
// // //                 <p className="form-subtitle">Please sign in to your account</p>
// // //               </div>

// // //               <form onSubmit={handleLoginSubmit}>
// // //                 <div className="form-group">
// // //                   <label htmlFor="email">Email Address</label>
// // //                   <input 
// // //                     type="email" 
// // //                     id="email"
// // //                     name="email"
// // //                     value={formData.email}
// // //                     onChange={handleInputChange}
// // //                     placeholder="Enter your email"
// // //                     required
// // //                   />
// // //                 </div>

// // //                 <div className="form-group">
// // //                   <label htmlFor="password">Password</label>
// // //                   <input 
// // //                     type="password" 
// // //                     id="password"
// // //                     name="password"
// // //                     value={formData.password}
// // //                     onChange={handleInputChange}
// // //                     placeholder="Enter your password"
// // //                     required
// // //                   />
// // //                 </div>

// // //                 <div className="checkbox-group">
// // //                   <input 
// // //                     type="checkbox" 
// // //                     id="remember"
// // //                     name="remember"
// // //                     checked={formData.remember}
// // //                     onChange={handleInputChange}
// // //                   />
// // //                   <label htmlFor="remember">Remember me</label>
// // //                 </div>

// // //                 <button type="submit" className="btn-primary">Sign In</button>
// // //               </form>

// // //               <div className="divider">
// // //                 <span>Or continue with</span>
// // //               </div>

// // //               <div className="social-login">
// // //                 <div className="social-btn">
// // //                   <span>🔍 Google</span>
// // //                 </div>
// // //                 <div className="social-btn">
// // //                   <span>💼 LinkedIn</span>
// // //                 </div>
// // //               </div>

// // //               <div className="form-footer">
// // //                 Don't have an account? <a href="#" onClick={() => switchTab('signup')}>Sign up here</a>
// // //               </div>
// // //             </div>
// // //           )}

// // //           {/* Signup Form */}
// // //           {activeTab === 'signup' && (
// // //             <div className="signup-form active">
// // //               <div style={{ textAlign: 'center', marginBottom: '30px' }}>
// // //                 <h2 className="form-title">Create Account</h2>
// // //                 <p className="form-subtitle">Join us and start your career journey</p>
// // //               </div>

// // //               <form onSubmit={handleSignupSubmit}>
// // //                 <div className="form-row">
// // //                   <div className="form-group">
// // //                     <label htmlFor="firstName">First Name</label>
// // //                     <input 
// // //                       type="text" 
// // //                       id="firstName"
// // //                       name="firstName"
// // //                       value={formData.firstName}
// // //                       onChange={handleInputChange}
// // //                       placeholder="Khushi"
// // //                       required
// // //                     />
// // //                   </div>
// // //                   <div className="form-group">
// // //                     <label htmlFor="lastName">Last Name</label>
// // //                     <input 
// // //                       type="text" 
// // //                       id="lastName"
// // //                       name="lastName"
// // //                       value={formData.lastName}
// // //                       onChange={handleInputChange}
// // //                       placeholder="Kundariya"
// // //                       required
// // //                     />
// // //                   </div>
// // //                 </div>

// // //                 <div className="form-group">
// // //                   <label htmlFor="signupEmail">Email Address</label>
// // //                   <input 
// // //                     type="email" 
// // //                     id="signupEmail"
// // //                     name="signupEmail"
// // //                     value={formData.signupEmail}
// // //                     onChange={handleInputChange}
// // //                     placeholder="khushikundariya@example.com"
// // //                     required
// // //                   />
// // //                 </div>

// // //                 <div className="form-group">
// // //                   <label htmlFor="signupPassword">Password</label>
// // //                   <input 
// // //                     type="password" 
// // //                     id="signupPassword"
// // //                     name="signupPassword"
// // //                     value={formData.signupPassword}
// // //                     onChange={handleInputChange}
// // //                     placeholder="Create a strong password"
// // //                     required
// // //                   />
// // //                 </div>

// // //                 <div className="form-group">
// // //                   <label htmlFor="confirmPassword">Confirm Password</label>
// // //                   <input 
// // //                     type="password" 
// // //                     id="confirmPassword"
// // //                     name="confirmPassword"
// // //                     value={formData.confirmPassword}
// // //                     onChange={handleInputChange}
// // //                     placeholder="Confirm your password"
// // //                     required
// // //                   />
// // //                 </div>

// // //                 <div className="checkbox-group">
// // //                   <input 
// // //                     type="checkbox" 
// // //                     id="terms"
// // //                     name="terms"
// // //                     checked={formData.terms}
// // //                     onChange={handleInputChange}
// // //                     required
// // //                   />
// // //                   <label htmlFor="terms">
// // //                     I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
// // //                   </label>
// // //                 </div>

// // //                 <button type="submit" className="btn-primary">Create Account</button>
// // //               </form>

// // //               <div className="divider">
// // //                 <span>Or sign up with</span>
// // //               </div>

// // //               <div className="social-login">
// // //                 <div className="social-btn">
// // //                   <span>🔍 Google</span>
// // //                 </div>
// // //                 <div className="social-btn">
// // //                   <span>💼 LinkedIn</span>
// // //                 </div>
// // //               </div>

// // //               <div className="form-footer">
// // //                 Already have an account? <a href="#" onClick={() => switchTab('login')}>Sign in here</a>
// // //               </div>
// // //             </div>
// // //           )}
// // //         </div>
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default SignInSignUp;

// // import React, { useState, useEffect } from "react";
// // import "./SignInSignUp.css";

// // const SignInSignUp = () => {
// //   const [activeTab, setActiveTab] = useState("login");
// //   const [formData, setFormData] = useState({
// //     email: "",
// //     password: "",
// //     firstName: "",
// //     lastName: "",
// //     signupEmail: "",
// //     signupPassword: "",
// //     confirmPassword: "",
// //     remember: false,
// //     terms: false,
// //   });

// //   const [error, setError] = useState("");
// //   const [success, setSuccess] = useState("");

// //   const switchTab = (tab) => {
// //     setError("");
// //     setSuccess("");
// //     setActiveTab(tab);
// //   };

// //   const handleInputChange = (e) => {
// //     const { name, value, type, checked } = e.target;
// //     setFormData((prev) => ({
// //       ...prev,
// //       [name]: type === "checkbox" ? checked : value,
// //     }));
// //   };

// //   const handleLoginSubmit = (e) => {
// //     e.preventDefault();
// //     if (!formData.email || !formData.password) {
// //       setError("⚠️ Please fill all the fields.");
// //       setSuccess("");
// //     } else if (!formData.email.includes("@") || !formData.email.includes(".")) {
// //       setError("⚠️ Please enter a valid email address.");
// //       setSuccess("");
// //     } else {
// //       setSuccess("✅ Login successful!");
// //       setError("");
// //       setFormData({ ...formData, email: "", password: "" });
// //     }
// //   };

// //   const handleSignupSubmit = (e) => {
// //     e.preventDefault();
// //     if (
// //       !formData.firstName ||
// //       !formData.lastName ||
// //       !formData.signupEmail ||
// //       !formData.signupPassword ||
// //       !formData.confirmPassword
// //     ) {
// //       setError("⚠️ Please fill all the fields.");
// //       setSuccess("");
// //     } else if (!formData.signupEmail.includes("@") || !formData.signupEmail.includes(".")) {
// //       setError("⚠️ Please enter a valid email address.");
// //       setSuccess("");
// //     } else if (formData.signupPassword !== formData.confirmPassword) {
// //       setError("⚠️ Passwords do not match.");
// //       setSuccess("");
// //     } else {
// //       setSuccess("✅ Account created successfully!");
// //       setError("");
// //       setFormData({
// //         email: "",
// //         password: "",
// //         firstName: "",
// //         lastName: "",
// //         signupEmail: "",
// //         signupPassword: "",
// //         confirmPassword: "",
// //         remember: false,
// //         terms: false,
// //       });
// //     }
// //   };

// //   useEffect(() => {
// //     const inputs = document.querySelectorAll("input");
// //     inputs.forEach((input) => {
// //       const handleFocus = () => {
// //         input.parentElement.style.transform = "translateY(-2px)";
// //       };
// //       const handleBlur = () => {
// //         input.parentElement.style.transform = "translateY(0)";
// //       };
// //       input.addEventListener("focus", handleFocus);
// //       input.addEventListener("blur", handleBlur);
// //       return () => {
// //         input.removeEventListener("focus", handleFocus);
// //         input.removeEventListener("blur", handleBlur);
// //       };
// //     });
// //   }, []);

// //   return (
// //     <div className="signin-signup-container">
// //       <div className="container">
// //         <div className="left-section">
// //           <div className="logo">JobEntry</div>
// //           <div className="hero-content">
// //             <h1 className="hero-title">Find The Perfect Job That You Deserved</h1>
// //             <p className="hero-subtitle">
// //               Join thousands of professionals who have found their dream careers through our platform.
// //               Your next opportunity is just a click away.
// //             </p>
// //           </div>
// //           <div className="business-icons">
// //             <div className="icon-circle">👥</div>
// //             <div className="icon-circle">💼</div>
// //             <div className="icon-circle">🚀</div>
// //           </div>
// //         </div>

// //         <div className="right-section">
// //           <div className="form-header">
// //             <div className="form-tabs">
// //               <div
// //                 className={`tab ${activeTab === "login" ? "active" : ""}`}
// //                 onClick={() => switchTab("login")}
// //               >
// //                 Login
// //               </div>
// //               <div
// //                 className={`tab ${activeTab === "signup" ? "active" : ""}`}
// //                 onClick={() => switchTab("signup")}
// //               >
// //                 Sign Up
// //               </div>
// //             </div>
// //           </div>

// //           {/* Error / Success Message */}
// //           {error && <div className="error-message">{error}</div>}
// //           {success && <div className="success-message">{success}</div>}

// //           {/* Login Form */}
// //           {activeTab === "login" && (
// //             <div className="login-form active">
// //               <div style={{ textAlign: "center", marginBottom: "30px" }}>
// //                 <h2 className="form-title">Welcome Back!</h2>
// //                 <p className="form-subtitle">Please sign in to your account</p>
// //               </div>

// //               <form onSubmit={handleLoginSubmit}>
// //                 <div className="form-group">
// //                   <label htmlFor="email">Email Address</label>
// //                   <input
// //                     type="email"
// //                     id="email"
// //                     name="email"
// //                     value={formData.email}
// //                     onChange={handleInputChange}
// //                     placeholder="Enter your email"
// //                   />
// //                 </div>

// //                 <div className="form-group">
// //                   <label htmlFor="password">Password</label>
// //                   <input
// //                     type="password"
// //                     id="password"
// //                     name="password"
// //                     value={formData.password}
// //                     onChange={handleInputChange}
// //                     placeholder="Enter your password"
// //                   />
// //                 </div>

// //                 <div className="checkbox-group">
// //                   <input
// //                     type="checkbox"
// //                     id="remember"
// //                     name="remember"
// //                     checked={formData.remember}
// //                     onChange={handleInputChange}
// //                   />
// //                   <label htmlFor="remember">Remember me</label>
// //                 </div>

// //                 <button type="submit" className="btn-primary">
// //                   Sign In
// //                 </button>
// //               </form>

// //               <div className="divider">
// //                 <span>Or continue with</span>
// //               </div>

// //               <div className="social-login">
// //                 <div className="social-btn">
// //                   <span>🔍 Google</span>
// //                 </div>
// //                 <div className="social-btn">
// //                   <span>💼 LinkedIn</span>
// //                 </div>
// //               </div>

// //               <div className="form-footer">
// //                 Don't have an account?{" "}
// //                 <a href="#" onClick={() => switchTab("signup")}>
// //                   Sign up here
// //                 </a>
// //               </div>
// //             </div>
// //           )}

// //           {/* Signup Form */}
// //           {activeTab === "signup" && (
// //             <div className="signup-form active">
// //               <div style={{ textAlign: "center", marginBottom: "30px" }}>
// //                 <h2 className="form-title">Create Account</h2>
// //                 <p className="form-subtitle">Join us and start your career journey</p>
// //               </div>

// //               <form onSubmit={handleSignupSubmit}>
// //                 <div className="form-row">
// //                   <div className="form-group">
// //                     <label htmlFor="firstName">First Name</label>
// //                     <input
// //                       type="text"
// //                       id="firstName"
// //                       name="firstName"
// //                       value={formData.firstName}
// //                       onChange={handleInputChange}
// //                       placeholder="Khushi"
// //                     />
// //                   </div>
// //                   <div className="form-group">
// //                     <label htmlFor="lastName">Last Name</label>
// //                     <input
// //                       type="text"
// //                       id="lastName"
// //                       name="lastName"
// //                       value={formData.lastName}
// //                       onChange={handleInputChange}
// //                       placeholder="Kundariya"
// //                     />
// //                   </div>
// //                 </div>

// //                 <div className="form-group">
// //                   <label htmlFor="signupEmail">Email Address</label>
// //                   <input
// //                     type="email"
// //                     id="signupEmail"
// //                     name="signupEmail"
// //                     value={formData.signupEmail}
// //                     onChange={handleInputChange}
// //                     placeholder="khushikundariya@example.com"
// //                   />
// //                 </div>

// //                 <div className="form-group">
// //                   <label htmlFor="signupPassword">Password</label>
// //                   <input
// //                     type="password"
// //                     id="signupPassword"
// //                     name="signupPassword"
// //                     value={formData.signupPassword}
// //                     onChange={handleInputChange}
// //                     placeholder="Create a strong password"
// //                   />
// //                 </div>

// //                 <div className="form-group">
// //                   <label htmlFor="confirmPassword">Confirm Password</label>
// //                   <input
// //                     type="password"
// //                     id="confirmPassword"
// //                     name="confirmPassword"
// //                     value={formData.confirmPassword}
// //                     onChange={handleInputChange}
// //                     placeholder="Confirm your password"
// //                   />
// //                 </div>

// //                 <div className="checkbox-group">
// //                   <input
// //                     type="checkbox"
// //                     id="terms"
// //                     name="terms"
// //                     checked={formData.terms}
// //                     onChange={handleInputChange}
// //                   />
// //                   <label htmlFor="terms">
// //                     I agree to the <a href="#">Terms of Service</a> and{" "}
// //                     <a href="#">Privacy Policy</a>
// //                   </label>
// //                 </div>

// //                 <button type="submit" className="btn-primary">
// //                   Create Account
// //                 </button>
// //               </form>

// //               <div className="divider">
// //                 <span>Or sign up with</span>
// //               </div>

// //               <div className="social-login">
// //                 <div className="social-btn">
// //                   <span>🔍 Google</span>
// //                 </div>
// //                 <div className="social-btn">
// //                   <span>💼 LinkedIn</span>
// //                 </div>
// //               </div>

// //               <div className="form-footer">
// //                 Already have an account?{" "}
// //                 <a href="#" onClick={() => switchTab("login")}>
// //                   Sign in here
// //                 </a>
// //               </div>
// //             </div>
// //           )}
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default SignInSignUp;


// import React, { useState, useEffect } from "react";
// import "./SignInSignUp.css";

// const SignInSignUp = () => {
//   const [activeTab, setActiveTab] = useState("login");
//   const [formData, setFormData] = useState({
//     email: "",
//     password: "",
//     firstName: "",
//     lastName: "",
//     signupEmail: "",
//     signupPassword: "",
//     confirmPassword: "",
//     remember: false,
//     terms: false,
//   });

//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   const switchTab = (tab) => {
//     setError("");
//     setSuccess("");
//     setActiveTab(tab);
//   };

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   const handleLoginSubmit = (e) => {
//     e.preventDefault();
//     if (!formData.email || !formData.password) {
//       setError("⚠️ Please fill all the fields.");
//       setSuccess("");
//     } else if (!formData.email.includes("@") || !formData.email.includes(".")) {
//       setError("⚠️ Please enter a valid email address.");
//       setSuccess("");
//     } else {
//       setSuccess("✅ Login successful!");
//       setError("");
//       setFormData({ ...formData, email: "", password: "" });
//     }
//   };

//   const handleSignupSubmit = (e) => {
//     e.preventDefault();
//     if (
//       !formData.firstName ||
//       !formData.lastName ||
//       !formData.signupEmail ||
//       !formData.signupPassword ||
//       !formData.confirmPassword
//     ) {
//       setError("⚠️ Please fill all the fields.");
//       setSuccess("");
//     } else if (!formData.signupEmail.includes("@") || !formData.signupEmail.includes(".")) {
//       setError("⚠️ Please enter a valid email address.");
//       setSuccess("");
//     } else if (formData.signupPassword !== formData.confirmPassword) {
//       setError("⚠️ Passwords do not match.");
//       setSuccess("");
//     } else if (!formData.terms) {
//       setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//       setSuccess("");
//     } else {
//       setSuccess("✅ Account created successfully!");
//       setError("");
//       setFormData({
//         email: "",
//         password: "",
//         firstName: "",
//         lastName: "",
//         signupEmail: "",
//         signupPassword: "",
//         confirmPassword: "",
//         remember: false,
//         terms: false,
//       });
//     }
//   };

//   useEffect(() => {
//     const inputs = document.querySelectorAll("input");
//     inputs.forEach((input) => {
//       const handleFocus = () => {
//         input.parentElement.style.transform = "translateY(-2px)";
//       };
//       const handleBlur = () => {
//         input.parentElement.style.transform = "translateY(0)";
//       };
//       input.addEventListener("focus", handleFocus);
//       input.addEventListener("blur", handleBlur);
//       return () => {
//         input.removeEventListener("focus", handleFocus);
//         input.removeEventListener("blur", handleBlur);
//       };
//     });
//   }, []);

//   return (
//     <div className="signin-signup-container">
//       <div className="container">
//         {/* LEFT SIDE */}
//         <div className="left-section">
//           <div className="logo">JobEntry</div>
//           <div className="hero-content">
//             <h1 className="hero-title">Find The Perfect Job That You Deserved</h1>
//             <p className="hero-subtitle">
//               Join thousands of professionals who have found their dream careers through our platform.
//               Your next opportunity is just a click away.
//             </p>
//           </div>
//           <div className="business-icons">
//             <div className="icon-circle">👥</div>
//             <div className="icon-circle">💼</div>
//             <div className="icon-circle">🚀</div>
//           </div>
//         </div>

//         {/* RIGHT SIDE */}
//         <div className="right-section">
//           {/* TABS */}
//           <div className="form-header">
//             <div className="form-tabs">
//               <div
//                 className={`tab ${activeTab === "login" ? "active" : ""}`}
//                 onClick={() => switchTab("login")}
//               >
//                 Login
//               </div>
//               <div
//                 className={`tab ${activeTab === "signup" ? "active" : ""}`}
//                 onClick={() => switchTab("signup")}
//               >
//                 Sign Up
//               </div>
//             </div>
//           </div>

//           {/* Error / Success Message */}
//           {error && <div className="error-message">{error}</div>}
//           {success && <div className="success-message">{success}</div>}

//           {/* LOGIN FORM */}
//           {activeTab === "login" && (
//             <div className="login-form active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="form-title">Welcome Back!</h2>
//                 <p className="form-subtitle">Please sign in to your account</p>
//               </div>

//               <form onSubmit={handleLoginSubmit}>
//                 <div className="form-group">
//                   <label htmlFor="email">Email Address</label>
//                   <input
//                     type="email"
//                     id="email"
//                     name="email"
//                     value={formData.email}
//                     onChange={handleInputChange}
//                     placeholder="Enter your email"
//                   />
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="password">Password</label>
//                   <input
//                     type="password"
//                     id="password"
//                     name="password"
//                     value={formData.password}
//                     onChange={handleInputChange}
//                     placeholder="Enter your password"
//                   />
//                 </div>

//                 <div className="checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="remember"
//                     name="remember"
//                     checked={formData.remember}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="remember">Remember me</label>
//                 </div>

//                 <button type="submit" className="btn-primary">
//                   Sign In
//                 </button>
//               </form>

//               <div className="divider">
//                 <span>Or continue with</span>
//               </div>

//               <div className="social-login">
//                 <div className="social-btn">
//                   <span>🔍 Google</span>
//                 </div>
//                 <div className="social-btn">
//                   <span>💼 LinkedIn</span>
//                 </div>
//               </div>

//               <div className="form-footer">
//                 Don't have an account?{" "}
//                 <a href="#" onClick={() => switchTab("signup")}>
//                   Sign up here
//                 </a>
//               </div>
//             </div>
//           )}

//           {/* SIGNUP FORM */}
//           {activeTab === "signup" && (
//             <div className="signup-form active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="form-title">Create Account</h2>
//                 <p className="form-subtitle">Join us and start your career journey</p>
//               </div>

//               <form onSubmit={handleSignupSubmit}>
//                 <div className="form-row">
//                   <div className="form-group">
//                     <label htmlFor="firstName">First Name</label>
//                     <input
//                       type="text"
//                       id="firstName"
//                       name="firstName"
//                       value={formData.firstName}
//                       onChange={handleInputChange}
//                       placeholder="Khushi"
//                     />
//                   </div>
//                   <div className="form-group">
//                     <label htmlFor="lastName">Last Name</label>
//                     <input
//                       type="text"
//                       id="lastName"
//                       name="lastName"
//                       value={formData.lastName}
//                       onChange={handleInputChange}
//                       placeholder="Kundariya"
//                     />
//                   </div>
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="signupEmail">Email Address</label>
//                   <input
//                     type="email"
//                     id="signupEmail"
//                     name="signupEmail"
//                     value={formData.signupEmail}
//                     onChange={handleInputChange}
//                     placeholder="khushikundariya@example.com"
//                   />
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="signupPassword">Password</label>
//                   <input
//                     type="password"
//                     id="signupPassword"
//                     name="signupPassword"
//                     value={formData.signupPassword}
//                     onChange={handleInputChange}
//                     placeholder="Create a strong password"
//                   />
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="confirmPassword">Confirm Password</label>
//                   <input
//                     type="password"
//                     id="confirmPassword"
//                     name="confirmPassword"
//                     value={formData.confirmPassword}
//                     onChange={handleInputChange}
//                     placeholder="Confirm your password"
//                   />
//                 </div>

//                 <div className="checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="terms"
//                     name="terms"
//                     checked={formData.terms}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="terms">
//                     I agree to the <a href="#">Terms of Service</a> and{" "}
//                     <a href="#">Privacy Policy</a>
//                   </label>
//                 </div>

//                 <button
//                   type="submit"
//                   className="btn-primary"
//                   disabled={!formData.terms} // Button disabled until checkbox checked
//                 >
//                   Create Account
//                 </button>
//               </form>

//               <div className="divider">
//                 <span>Or sign up with</span>
//               </div>

//               <div className="social-login">
//                 <div className="social-btn">
//                   <span>🔍 Google</span>
//                 </div>
//                 <div className="social-btn">
//                   <span>💼 LinkedIn</span>
//                 </div>
//               </div>

//               <div className="form-footer">
//                 Already have an account?{" "}
//                 <a href="#" onClick={() => switchTab("login")}>
//                   Sign in here
//                 </a>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignInSignUp;


// import React, { useState, useEffect } from "react";
// import "../Login/Login.css";

// const SignInSignUp = () => {
//   const [activeTab, setActiveTab] = useState("login");
//   const [formData, setFormData] = useState({
//     email: "",
//     password: "",
//     firstName: "",
//     lastName: "",
//     signupEmail: "",
//     signupPassword: "",
//     confirmPassword: "",
//     remember: false, // Login checkbox
//     terms: false,    // Signup checkbox
//   });

//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   const switchTab = (tab) => {
//     setError("");
//     setSuccess("");
//     setActiveTab(tab);
//   };

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   const handleLoginSubmit = (e) => {
//     e.preventDefault();
//     if (!formData.email || !formData.password) {
//       setError("⚠️ Please fill all the fields.");
//       setSuccess("");
//     } else if (!formData.email.includes("@") || !formData.email.includes(".")) {
//       setError("⚠️ Please enter a valid email address.");
//       setSuccess("");
//     } else if (!formData.remember) {
//       setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//       setSuccess("");
//     } else {
//       setSuccess("✅ Login successful!");
//       setError("");
//       setFormData({ ...formData, email: "", password: "", remember: false });
//     }
//   };

//   const handleSignupSubmit = (e) => {
//     e.preventDefault();
//     if (
//       !formData.firstName ||
//       !formData.lastName ||
//       !formData.signupEmail ||
//       !formData.signupPassword ||
//       !formData.confirmPassword
//     ) {
//       setError("⚠️ Please fill all the fields.");
//       setSuccess("");
//     } else if (!formData.signupEmail.includes("@") || !formData.signupEmail.includes(".")) {
//       setError("⚠️ Please enter a valid email address.");
//       setSuccess("");
//     } else if (formData.signupPassword !== formData.confirmPassword) {
//       setError("⚠️ Passwords do not match.");
//       setSuccess("");
//     } else if (!formData.terms) {
//       setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//       setSuccess("");
//     } else {
//       setSuccess("✅ Account created successfully!");
//       setError("");
//       setFormData({
//         email: "",
//         password: "",
//         firstName: "",
//         lastName: "",
//         signupEmail: "",
//         signupPassword: "",
//         confirmPassword: "",
//         remember: false,
//         terms: false,
//       });
//     }
//   };

//   useEffect(() => {
//     const inputs = document.querySelectorAll("input");
//     inputs.forEach((input) => {
//       const handleFocus = () => {
//         input.parentElement.style.transform = "translateY(-2px)";
//       };
//       const handleBlur = () => {
//         input.parentElement.style.transform = "translateY(0)";
//       };
//       input.addEventListener("focus", handleFocus);
//       input.addEventListener("blur", handleBlur);
//       return () => {
//         input.removeEventListener("focus", handleFocus);
//         input.removeEventListener("blur", handleBlur);
//       };
//     });
//   }, []);

//   return (
//     <div className="signin-signup-container">
//       <div className="container">
//         {/* LEFT SIDE */}
//         <div className="left-section">
//           <div className="logo">JobEntry</div>
//           <div className="hero-content">
//             <h1 className="hero-title">Find The Perfect Job That You Deserved</h1>
//             <p className="hero-subtitle">
//               Join thousands of professionals who have found their dream careers through our platform.
//               Your next opportunity is just a click away.
//             </p>
//           </div>
//           <div className="business-icons">
//             <div className="icon-circle">👥</div>
//             <div className="icon-circle">💼</div>
//             <div className="icon-circle">🚀</div>
//           </div>
//         </div>

//         {/* RIGHT SIDE */}
//         <div className="right-section">
//           {/* TABS */}
//           <div className="form-header">
//             <div className="form-tabs">
//               <div
//                 className={`tab ${activeTab === "login" ? "active" : ""}`}
//                 onClick={() => switchTab("login")}
//               >
//                 Login
//               </div>
//               <div
//                 className={`tab ${activeTab === "signup" ? "active" : ""}`}
//                 onClick={() => switchTab("signup")}
//               >
//                 Sign Up
//               </div>
//             </div>
//           </div>

//           {/* Error / Success Message */}
//           {error && <div className="error-message">{error}</div>}
//           {success && <div className="success-message">{success}</div>}

//           {/* LOGIN FORM */}
//           {activeTab === "login" && (
//             <div className="login-form active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="form-title">Welcome Back!</h2>
//                 <p className="form-subtitle">Please sign in to your account</p>
//               </div>

//               <form onSubmit={handleLoginSubmit}>
//                 <div className="form-group">
//                   <label htmlFor="email">Email Address</label>
//                   <input
//                     type="email"
//                     id="email"
//                     name="email"
//                     value={formData.email}
//                     onChange={handleInputChange}
//                     placeholder="Enter your email"
//                   />
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="password">Password</label>
//                   <input
//                     type="password"
//                     id="password"
//                     name="password"
//                     value={formData.password}
//                     onChange={handleInputChange}
//                     placeholder="Enter your password"
//                   />
//                 </div>

//                 <div className="checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="remember"
//                     name="remember"
//                     checked={formData.remember}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="remember">
//                     I agree to the <a href="#">Terms of Service</a> and{" "}
//                     <a href="#">Privacy Policy</a>
//                   </label>
//                 </div>

//                 <button
//                   type="submit"
//                   className="btn-primary"
//                   disabled={!formData.remember} // Disabled until checked
//                 >
//                   Sign In
//                 </button>
//               </form>

//               <div className="divider">
//                 <span>Or continue with</span>
//               </div>

//               <div className="social-login">
//                 <div className="social-btn">
//                   <span>🔍 Google</span>
//                 </div>
//                 <div className="social-btn">
//                   <span>💼 LinkedIn</span>
//                 </div>
//               </div>

//               <div className="form-footer">
//                 Don't have an account?{" "}
//                 <a href="#" onClick={() => switchTab("signup")}>
//                   Sign up here
//                 </a>
//               </div>
//             </div>
//           )}

//           {/* SIGNUP FORM */}
//           {activeTab === "signup" && (
//             <div className="signup-form active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="form-title">Create Account</h2>
//                 <p className="form-subtitle">Join us and start your career journey</p>
//               </div>

//               <form onSubmit={handleSignupSubmit}>
//                 <div className="form-row">
//                   <div className="form-group">
//                     <label htmlFor="firstName">First Name</label>
//                     <input
//                       type="text"
//                       id="firstName"
//                       name="firstName"
//                       value={formData.firstName}
//                       onChange={handleInputChange}
//                       placeholder="Khushi"
//                     />
//                   </div>
//                   <div className="form-group">
//                     <label htmlFor="lastName">Last Name</label>
//                     <input
//                       type="text"
//                       id="lastName"
//                       name="lastName"
//                       value={formData.lastName}
//                       onChange={handleInputChange}
//                       placeholder="Kundariya"
//                     />
//                   </div>
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="signupEmail">Email Address</label>
//                   <input
//                     type="email"
//                     id="signupEmail"
//                     name="signupEmail"
//                     value={formData.signupEmail}
//                     onChange={handleInputChange}
//                     placeholder="khushikundariya@example.com"
//                   />
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="signupPassword">Password</label>
//                   <input
//                     type="password"
//                     id="signupPassword"
//                     name="signupPassword"
//                     value={formData.signupPassword}
//                     onChange={handleInputChange}
//                     placeholder="Create a strong password"
//                   />
//                 </div>

//                 <div className="form-group">
//                   <label htmlFor="confirmPassword">Confirm Password</label>
//                   <input
//                     type="password"
//                     id="confirmPassword"
//                     name="confirmPassword"
//                     value={formData.confirmPassword}
//                     onChange={handleInputChange}
//                     placeholder="Confirm your password"
//                   />
//                 </div>

//                 <div className="checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="terms"
//                     name="terms"
//                     checked={formData.terms}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="terms">
//                     I agree to the <a href="#">Terms of Service</a> and{" "}
//                     <a href="#">Privacy Policy</a>
//                   </label>
//                 </div>

//                 <button
//                   type="submit"
//                   className="btn-primary"
//                   disabled={!formData.terms} // Disabled until checked
//                 >
//                   Create Account
//                 </button>
//               </form>

//               <div className="divider">
//                 <span>Or sign up with</span>
//               </div>

//               <div className="social-login">
//                 <div className="social-btn">
//                   <span>🔍 Google</span>
//                 </div>
//                 <div className="social-btn">
//                   <span>💼 LinkedIn</span>
//                 </div>
//               </div>

//               <div className="form-footer">
//                 Already have an account?{" "}
//                 <a href="#" onClick={() => switchTab("login")}>
//                   Sign in here
//                 </a>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignInSignUp;





// import React, { useState, useEffect } from "react";
// import "../Login/Login.css";
// // import { Link } from "react-router-dom";
// import { Link, useNavigate } from "react-router-dom"; // <-- Add useNavigate here


// const SignInSignUp = () => {
//     const navigate = useNavigate(); 
//   const [activeTab, setActiveTab] = useState("login");
//   const [formData, setFormData] = useState({
//     email: "",
//     password: "",
//     firstName: "",
//     lastName: "",
//     signupEmail: "",
//     signupPassword: "",
//     confirmPassword: "",
//     role: "", // NEW field for user role
//     remember: false, 
//     terms: false,
//   });

//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   const switchTab = (tab) => {
//     setError("");
//     setSuccess("");
//     setActiveTab(tab);
//   };

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   const handleLoginSubmit = (e) => {
//     e.preventDefault();
//     if (!formData.email || !formData.password) {
//       setError("⚠️ Please fill all the fields.");
//       setSuccess("");
//     } else if (!formData.email.includes("@") || !formData.email.includes(".")) {
//       setError("⚠️ Please enter a valid email address.");
//       setSuccess("");
//     } else if (!formData.remember) {
//       setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//       setSuccess("");
//     } else if (formData.loginRole === "Admin") {
//       // Admin login check (set your admin email and password here)
//       if (
//         formData.email === "admin@jobentry.com" &&
//         formData.password === "admin123"
//       ) {
//         setSuccess("✅ Admin login successful!");
//         setError("");
//         setTimeout(() => {
//           navigate("/Adm_Dashboard");
//         }, 1000);
//       } else {
//         setError("⚠️ Invalid admin credentials.");
//         setSuccess("");
//       }
//     } else {
//       setSuccess("✅ Login successful!");
//       setError("");
//       setFormData({ ...formData, email: "", password: "", remember: false });
//     }
//   };

//   const handleSignupSubmit = (e) => {
//     e.preventDefault();
//     if (
//       !formData.firstName ||
//       !formData.lastName ||
//       !formData.signupEmail ||
//       !formData.signupPassword ||
//       !formData.confirmPassword ||
//       !formData.role
//     ) {
//       setError("⚠️ Please fill all the fields and select a role.");
//       setSuccess("");
//     } else if (!formData.signupEmail.includes("@") || !formData.signupEmail.includes(".")) {
//       setError("⚠️ Please enter a valid email address.");
//       setSuccess("");
//     } else if (formData.signupPassword !== formData.confirmPassword) {
//       setError("⚠️ Passwords do not match.");
//       setSuccess("");
//     } else if (!formData.terms) {
//       setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//       setSuccess("");
//     } else {
//       setSuccess(`✅ Account created successfully as ${formData.role}!`);
//       setError("");
//       setFormData({
//         email: "",
//         password: "",
//         firstName: "",
//         lastName: "",
//         signupEmail: "",
//         signupPassword: "",
//         confirmPassword: "",
//         role: "",
//         remember: false,
//         terms: false,
//       });
//     }
//   };

//   useEffect(() => {
//     const inputs = document.querySelectorAll("input, select");
//     inputs.forEach((input) => {
//       const handleFocus = () => {
//         input.parentElement.style.transform = "translateY(-2px)";
//       };
//       const handleBlur = () => {
//         input.parentElement.style.transform = "translateY(0)";
//       };
//       input.addEventListener("focus", handleFocus);
//       input.addEventListener("blur", handleBlur);
//       return () => {
//         input.removeEventListener("focus", handleFocus);
//         input.removeEventListener("blur", handleBlur);
//       };
//     });
//   }, []);

//   return (
//     <div className="auth-signin-signup-container">
//       <div className="auth-main-container">
//         {/* LEFT SIDE */}
//         <div className="auth-left-section">
//           <div className="auth-logo">JobEntry</div>
//           <div className="auth-hero-content">
//             <h1 className="auth-hero-title">Find The Perfect Job That You Deserved</h1>
//             <p className="auth-hero-subtitle">
//               Join thousands of professionals who have found their dream careers through our platform.
//               Your next opportunity is just a click away.
//             </p>
//           </div>
//           <div className="auth-business-icons">
//             <div className="auth-icon-circle">👥</div>
//             <div className="auth-icon-circle">💼</div>
//             <div className="auth-icon-circle">🚀</div>
//           </div>
//         </div>

//         {/* RIGHT SIDE */}
//         <div className="auth-right-section">
//           {/* TABS */}
//           <div className="auth-form-header">
//             <div className="auth-form-tabs">
//               <div
//                 className={`auth-tab ${activeTab === "login" ? "auth-active" : ""}`}
//                 onClick={() => switchTab("login")}
//               >
//                 Login
//               </div>
//               <div
//                 className={`auth-tab ${activeTab === "signup" ? "auth-active" : ""}`}
//                 onClick={() => switchTab("signup")}
//               >
//                 Sign Up
//               </div>
//             </div>
//           </div>

//           {/* Error / Success Message */}
//           {error && <div className="auth-error-message">{error}</div>}
//           {success && <div className="auth-success-message">{success}</div>}

//           {/* LOGIN FORM */}
//           {activeTab === "login" && (
//             <div className="auth-login-form auth-active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="auth-form-title">Welcome Back!</h2>
//                 <p className="auth-form-subtitle">Please sign in to your account</p>
//               </div>

//               <form onSubmit={handleLoginSubmit}>
//                 <div className="auth-form-group">
//                   <label htmlFor="email">Email Address</label>
//                   <input
//                     type="email"
//                     id="email"
//                     name="email"
//                     value={formData.email}
//                     onChange={handleInputChange}
//                     placeholder="Enter your email"
//                   />
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="password">Password</label>
//                   <input
//                     type="password"
//                     id="password"
//                     name="password"
//                     value={formData.password}
//                     onChange={handleInputChange}
//                     placeholder="Enter your password"
//                   />
//                 </div>

//                 <div className="auth-checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="remember"
//                     name="remember"
//                     checked={formData.remember}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="remember">
//                     I agree to the <a href="#">Terms of Service</a> and{" "}
//                     <a href="#">Privacy Policy</a>
//                   </label>
//                 </div>

//                 <button
//                   type="submit"
//                   className="auth-btn-primary"
//                   disabled={!formData.remember}
//                 >
//                   Sign In
//                 </button>
//               </form>
//             </div>
//           )}

//           {/* SIGNUP FORM */}
//           {activeTab === "signup" && (
//             <div className="auth-signup-form auth-active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="auth-form-title">Create Account</h2>
//                 <p className="auth-form-subtitle">Join us and start your career journey</p>
//               </div>

//               <form onSubmit={handleSignupSubmit}>
//                 <div className="auth-form-row">
//                   <div className="auth-form-group">
//                     <label htmlFor="firstName">First Name</label>
//                     <input
//                       type="text"
//                       id="firstName"
//                       name="firstName"
//                       value={formData.firstName}
//                       onChange={handleInputChange}
//                       placeholder="Khushi"
//                     />
//                   </div>
//                   <div className="auth-form-group">
//                     <label htmlFor="lastName">Last Name</label>
//                     <input
//                       type="text"
//                       id="lastName"
//                       name="lastName"
//                       value={formData.lastName}
//                       onChange={handleInputChange}
//                       placeholder="Kundariya"
//                     />
//                   </div>
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="signupEmail">Email Address</label>
//                   <input
//                     type="email"
//                     id="signupEmail"
//                     name="signupEmail"
//                     value={formData.signupEmail}
//                     onChange={handleInputChange}
//                     placeholder="khushi@example.com"
//                   />
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="signupPassword">Password</label>
//                   <input
//                     type="password"
//                     id="signupPassword"
//                     name="signupPassword"
//                     value={formData.signupPassword}
//                     onChange={handleInputChange}
//                     placeholder="Create a strong password"
//                   />
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="confirmPassword">Confirm Password</label>
//                   <input
//                     type="password"
//                     id="confirmPassword"
//                     name="confirmPassword"
//                     value={formData.confirmPassword}
//                     onChange={handleInputChange}
//                     placeholder="Confirm your password"
//                   />
//                 </div>

//                 {/* User Role Selection */}
//                 <div className="auth-form-group">
//                   <label htmlFor="role">Register As</label>
//                   <select
//                     id="role"
//                     name="role"
//                     value={formData.role}
//                     onChange={handleInputChange}
//                   >
//                     <option value="">-- Select Role --</option>
//                     <option value="Job Seeker">Job Seeker</option>
//                     <option value="Employer">Employer</option>
                    
//                   </select>
//                 </div>

//                 <div className="auth-checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="terms"
//                     name="terms"
//                     checked={formData.terms}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="terms">
//                     I agree to the <a href="#">Terms of Service</a> and{" "}
//                     <a href="#">Privacy Policy</a>
//                   </label>
//                 </div>

//                 <button
//                   type="submit"
//                   className="auth-btn-primary"
//                   disabled={!formData.terms || !formData.role}
//                 >
//                   Create Account
//                 </button>
//               </form>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignInSignUp;



// import React, { useState, useEffect } from "react";
// import "../Login/Login.css";
// import { Link, useNavigate } from "react-router-dom";

// const ADMIN_EMAIL = "admin@jobentry.com";
// const ADMIN_PASSWORD = "admin123";

// const SignInSignUp = () => {
//   const navigate = useNavigate();
//   const [activeTab, setActiveTab] = useState("login");
//   const [formData, setFormData] = useState({
//     email: "",
//     password: "",
//     firstName: "",
//     lastName: "",
//     signupEmail: "",
//     signupPassword: "",
//     confirmPassword: "",
//     role: "",
//     remember: false,
//     terms: false,
//   });

//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   const switchTab = (tab) => {
//     setError("");
//     setSuccess("");
//     setActiveTab(tab);
//   };

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   // const handleLoginSubmit = (e) => {
//   //   e.preventDefault();
//   //   if (!formData.email || !formData.password) {
//   //     setError("⚠️ Please fill all the fields.");
//   //     setSuccess("");
//   //   } else if (!formData.email.includes("@") || !formData.email.includes(".")) {
//   //     setError("⚠️ Please enter a valid email address.");
//   //     setSuccess("");
//   //   } else if (!formData.remember) {
//   //     setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//   //     setSuccess("");
//   //   } else if (
//   //     formData.email === ADMIN_EMAIL &&
//   //     formData.password === ADMIN_PASSWORD
//   //   ) {
//   //     setSuccess("✅ Admin login successful!");
//   //     setError("");
//   //     setTimeout(() => {
//   //       navigate("/admin");
//   //     }, 1000);
//   //   } else {
//   //     setSuccess("✅ Login successful!");
//   //     setError("");
//   //     setFormData({ ...formData, email: "", password: "", remember: false });
//   //   }
//   // };
// // const handleLoginSubmit = (e) => {
// //   e.preventDefault();

// //   if (!formData.email || !formData.password) {
// //     setError("⚠️ Please fill all the fields.");
// //     setSuccess("");
// //   } else if (!formData.email.includes("@") || !formData.email.includes(".")) {
// //     setError("⚠️ Please enter a valid email address.");
// //     setSuccess("");
// //   } else if (!formData.remember) {
// //     setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
// //     setSuccess("");
// //   } 
// //   // ✅ Admin Login
// //   else if (
// //     formData.email === ADMIN_EMAIL &&
// //     formData.password === ADMIN_PASSWORD
// //   ) {
// //     setSuccess("✅ Admin login successful!");
// //     setError("");
// //     setTimeout(() => {
// //       navigate("/admin"); // Admin dashboard
// //     }, 1000);
// //   } 
// //   // ✅ Normal User Login
// //   else {
// //     setSuccess("✅ Login successful!");
// //     setError("");
// //     setFormData({ ...formData, email: "", password: "", remember: false });
// //     setTimeout(() => {
// //       navigate("/"); // Redirect to Home page
// //     }, 1000);
// //   }
// // };


// // const handleLoginSubmit = async (e) => {
// //   e.preventDefault();

// //   if (!formData.email || !formData.password) {
// //     setError("⚠️ Please fill all the fields.");
// //     setSuccess("");
// //     return;
// //   }

// //   try {
// //     const res = await fetch("http://localhost:5000/api/login", {
// //       method: "POST",
// //       headers: { "Content-Type": "application/json" },
// //       body: JSON.stringify({ email: formData.email, password: formData.password }),
// //     });

// //     const data = await res.json();

// //     if (res.ok) {
// //       setSuccess(`✅ ${data.message}`);
// //       setError("");
// //       // Optional: store user info in localStorage/session
// //       setTimeout(() => navigate("/"), 1000); // redirect
// //     } else {
// //       setError("⚠️ " + (data.error || data.message || "Something went wrong"));
// //       setSuccess("");
// //     }
// //   } catch (err) {
// //     setError("⚠️ Something went wrong: " + err.message);
// //     setSuccess("");
// //   }
// // };



// const handleLoginSubmit = async (e) => {
//   e.preventDefault();

//   if (!formData.email || !formData.password) {
//     setError("⚠️ Please fill all the fields.");
//     setSuccess("");
//     return;
//   }

//   try {
//     const res = await fetch("http://localhost:5000/api/login", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ email: formData.email, password: formData.password }),
//     });

//     const data = await res.json();

//     if (res.ok && data.success) {
//       setSuccess(`✅ ${data.message}`);
//       setError("");

//       localStorage.setItem("user", JSON.stringify(data.user));

      
//      if (data.user.role === "jobseeker") {
//   navigate("/"); 
// } else if (data.user.role === "employer") {
//   navigate("/recruiter"); 
// } else if (data.user.role === "admin") {
//   navigate("/admin"); 
// } else {
//   navigate("/");
// }

//     } else {
//       setError("⚠️ " + (data.error || data.message || "Something went wrong"));
//       setSuccess("");
//     }
//   } catch (err) {
//     setError("⚠️ Something went wrong: " + err.message);
//     setSuccess("");
//   }
// };


// const handleSignupSubmit = async (e) => {
//   e.preventDefault();

//   if (
//     !formData.firstName ||
//     !formData.lastName ||
//     !formData.signupEmail ||
//     !formData.signupPassword ||
//     !formData.confirmPassword ||
//     !formData.role
//   ) {
//     setError("⚠️ Please fill all the fields and select a role.");
//     setSuccess("");
//     return;
//   }

//   if (!formData.signupEmail.includes("@") || !formData.signupEmail.includes(".")) {
//     setError("⚠️ Please enter a valid email address.");
//     setSuccess("");
//     return;
//   }

//   if (formData.signupPassword !== formData.confirmPassword) {
//     setError("⚠️ Passwords do not match.");
//     setSuccess("");
//     return;
//   }

//   if (!formData.terms) {
//     setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//     setSuccess("");
//     return;
//   }

//   try {
//     const res = await fetch("http://localhost:5000/api/signup", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({
//         firstName: formData.firstName,
//         lastName: formData.lastName,
//         email: formData.signupEmail,
//         password: formData.signupPassword,
//         role: formData.role,
//       }),
//     });

//     const data = await res.json();
//     console.log(data);

//     if (res.ok) {
//       setSuccess(`✅ ${data.message}`);
//       setError("");
//       setFormData({
//         email: "",
//         password: "",
//         firstName: "",
//         lastName: "",
//         signupEmail: "",
//         signupPassword: "",
//         confirmPassword: "",
//         role: "",
//         remember: false,
//         terms: false,
//       });
//     } else {
//       setError("⚠️ " + (data.error || data.message || "Something went wrong"));
//       setSuccess("");
//     }
//   } catch (err) {
//     setError("⚠️ Something went wrong: " + err.message);
//     setSuccess("");
//   }
// };

// useEffect(() => {
//     const inputs = document.querySelectorAll("input, select");
//     inputs.forEach((input) => {
//       const handleFocus = () => {
//         input.parentElement.style.transform = "translateY(-2px)";
//       };
//       const handleBlur = () => {
//         input.parentElement.style.transform = "translateY(0)";
//       };
//       input.addEventListener("focus", handleFocus);
//       input.addEventListener("blur", handleBlur);
//       return () => {
//         input.removeEventListener("focus", handleFocus);
//         input.removeEventListener("blur", handleBlur);
//       };
//     });
//   }, []);

//   return (
//     <div className="auth-signin-signup-container">
//       <div className="auth-main-container">
        
//         <div className="auth-left-section">
//           <div className="auth-logo">JobEntry</div>
//           <div className="auth-hero-content">
//             <h1 className="auth-hero-title">Find The Perfect Job That You Deserved</h1>
//             <p className="auth-hero-subtitle">
//               Join thousands of professionals who have found their dream careers through our platform.
//               Your next opportunity is just a click away.
//             </p>
//           </div>
//           <div className="auth-business-icons">
//             <div className="auth-icon-circle">👥</div>
//             <div className="auth-icon-circle">💼</div>
//             <div className="auth-icon-circle">🚀</div>
//           </div>
//         </div>

//         {/* RIGHT SIDE */}
//         <div className="auth-right-section">
//           {/* TABS */}
//           <div className="auth-form-header">
//             <div className="auth-form-tabs">
//               <div
//                 className={`auth-tab ${activeTab === "login" ? "auth-active" : ""}`}
//                 onClick={() => switchTab("login")}
//               >
//                 Login
//               </div>
//               <div
//                 className={`auth-tab ${activeTab === "signup" ? "auth-active" : ""}`}
//                 onClick={() => switchTab("signup")}
//               >
//                 Sign Up
//               </div>
//             </div>
//           </div>

//           {/* Error / Success Message */}
//           {error && <div className="auth-error-message">{error}</div>}
//           {success && <div className="auth-success-message">{success}</div>}

//           {/* LOGIN FORM */}
//           {activeTab === "login" && (
//             <div className="auth-login-form auth-active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="auth-form-title">Welcome Back!</h2>
//                 <p className="auth-form-subtitle">Please sign in to your account</p>
//               </div>

//               <form onSubmit={handleLoginSubmit}>
//                 <div className="auth-form-group">
//                   <label htmlFor="email">Email Address</label>
//                   <input
//                     type="email"
//                     id="email"
//                     name="email"
//                     value={formData.email}
//                     onChange={handleInputChange}
//                     placeholder="Enter your email"
//                   />
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="password">Password</label>
//                   <input
//                     type="password"
//                     id="password"
//                     name="password"
//                     value={formData.password}
//                     onChange={handleInputChange}
//                     placeholder="Enter your password"
//                   />
//                 </div>

//                 <div className="auth-checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="remember"
//                     name="remember"
//                     checked={formData.remember}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="remember">
//                     I agree to the <a href="#">Terms of Service</a> and{" "}
//                     <a href="#">Privacy Policy</a>
//                   </label>
//                 </div>

//                 <button
//                   type="submit"
//                   className="auth-btn-primary"
//                   disabled={!formData.remember}
//                 >
//                   Sign In
//                 </button>
//                 <div style={{ marginTop: "10px", color: "#888", fontSize: "13px" }}>
//                   <b>Admin Login:</b> <br />
//                   Email: <span style={{ fontFamily: "monospace" }}>{ADMIN_EMAIL}</span> <br />
//                   Password: <span style={{ fontFamily: "monospace" }}>{ADMIN_PASSWORD}</span>
//                 </div>
//               </form>
//               <div className="form-footer">
//   <p>
//     <Link to="/forgot-password">Forgot Password?</Link>
//   </p>
// </div>

//             </div>
//           )}

//           {/* SIGNUP FORM */}
//           {activeTab === "signup" && (
//             <div className="auth-signup-form auth-active">
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="auth-form-title">Create Account</h2>
//                 <p className="auth-form-subtitle">Join us and start your career journey</p>
//               </div>

//               <form onSubmit={handleSignupSubmit}>
//                 <div className="auth-form-row">
//                   <div className="auth-form-group">
//                     <label htmlFor="firstName">First Name</label>
//                     <input
//                       type="text"
//                       id="firstName"
//                       name="firstName"
//                       value={formData.firstName}
//                       onChange={handleInputChange}
//                       placeholder="Khushi"
//                     />
//                   </div>
//                   <div className="auth-form-group">
//                     <label htmlFor="lastName">Last Name</label>
//                     <input
//                       type="text"
//                       id="lastName"
//                       name="lastName"
//                       value={formData.lastName}
//                       onChange={handleInputChange}
//                       placeholder="Kundariya"
//                     />
//                   </div>
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="signupEmail">Email Address</label>
//                   <input
//                     type="email"
//                     id="signupEmail"
//                     name="signupEmail"
//                     value={formData.signupEmail}
//                     onChange={handleInputChange}
//                     placeholder="khushi@example.com"
//                   />
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="signupPassword">Password</label>
//                   <input
//                     type="password"
//                     id="signupPassword"
//                     name="signupPassword"
//                     value={formData.signupPassword}
//                     onChange={handleInputChange}
//                     placeholder="Create a strong password"
//                   />
//                 </div>

//                 <div className="auth-form-group">
//                   <label htmlFor="confirmPassword">Confirm Password</label>
//                   <input
//                     type="password"
//                     id="confirmPassword"
//                     name="confirmPassword"
//                     value={formData.confirmPassword}
//                     onChange={handleInputChange}
//                     placeholder="Confirm your password"
//                   />
//                 </div>

//                 {/* User Role Selection */}
//                 <div className="auth-form-group">
//                   <label htmlFor="role">Register As</label>
//                   <select
//                     id="role"
//                     name="role"
//                     value={formData.role}
//                     onChange={handleInputChange}
//                   >
//                     <option value="">-- Select Role --</option>
//                     <option value="Job Seeker">Job Seeker</option>
//                     <option value="Employer">Employer</option>
//                   </select>
//                 </div>

//                 <div className="auth-checkbox-group">
//                   <input
//                     type="checkbox"
//                     id="terms"
//                     name="terms"
//                     checked={formData.terms}
//                     onChange={handleInputChange}
//                   />
//                   <label htmlFor="terms">
//                     I agree to the <a href="#">Terms of Service</a> and{" "}
//                     <a href="#">Privacy Policy</a>
//                   </label>
//                 </div>

//                 <button
//                   type="submit"
//                   className="auth-btn-primary"
//                   disabled={!formData.terms || !formData.role}
//                 >
//                   Create Account
//                 </button>
//               </form>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignInSignUp;
// import React, { useState, useEffect } from "react";
// import "../Login/Login.css";
// import { Link, useNavigate } from "react-router-dom";

// const ADMIN_EMAIL = "admin@jobentry.com";
// const ADMIN_PASSWORD = "admin123";

// const SignInSignUp = ({ setUser }) => {
//   const navigate = useNavigate();
//   const [activeTab, setActiveTab] = useState("login");
//   const [formData, setFormData] = useState({
//     email: "",
//     password: "",
//     firstName: "",
//     lastName: "",
//     signupEmail: "",
//     signupPassword: "",
//     confirmPassword: "",
//     role: "",
//     remember: false,
//     terms: false,
//   });

//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   const switchTab = (tab) => {
//     setError("");
//     setSuccess("");
//     setActiveTab(tab);
//   };

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   // ✅ LOGIN
//   const handleLoginSubmit = async (e) => {
//     e.preventDefault();

//     if (!formData.email || !formData.password) {
//       setError("⚠️ Please fill all the fields.");
//       setSuccess("");
//       return;
//     }

//     try {
//       const res = await fetch("http://localhost:5000/api/login", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ email: formData.email, password: formData.password }),
//       });

//       const data = await res.json();

//       if (res.ok && data.success) {
//         setSuccess(`✅ ${data.message}`);
//         setError("");

//         if (data.user) {
//           localStorage.setItem("user", JSON.stringify(data.user));
//           setUser(data.user); // Update React state

//           // Redirect based on role
//           if (data.user.role.toLowerCase() === "jobseeker") {
//             navigate(`/jobseeker-profile/${data.user.id}`);
//           } else if (data.user.role.toLowerCase() === "employer") {
//             navigate(`/employer-profile/${data.user.id}`);
//           } else if (data.user.role.toLowerCase() === "admin") {
//             navigate("/admin");
//           } else {
//             navigate("/");
//           }
//         }
//       } else {
//         setError("⚠️ " + (data.error || data.message || "Something went wrong"));
//         setSuccess("");
//       }
//     } catch (err) {
//       setError("⚠️ Something went wrong: " + err.message);
//       setSuccess("");
//     }
//   };

//   // ✅ SIGNUP
//   const handleSignupSubmit = async (e) => {
//     e.preventDefault();

//     if (
//       !formData.firstName ||
//       !formData.lastName ||
//       !formData.signupEmail ||
//       !formData.signupPassword ||
//       !formData.confirmPassword ||
//       !formData.role
//     ) {
//       setError("⚠️ Please fill all the fields and select a role.");
//       setSuccess("");
//       return;
//     }

//     if (!formData.signupEmail.includes("@") || !formData.signupEmail.includes(".")) {
//       setError("⚠️ Please enter a valid email address.");
//       setSuccess("");
//       return;
//     }

//     if (formData.signupPassword !== formData.confirmPassword) {
//       setError("⚠️ Passwords do not match.");
//       setSuccess("");
//       return;
//     }

//     if (!formData.terms) {
//       setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
//       setSuccess("");
//       return;
//     }

//     try {
//       const res = await fetch("http://localhost:5000/api/signup", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           firstName: formData.firstName,
//           lastName: formData.lastName,
//           email: formData.signupEmail,
//           password: formData.signupPassword,
//           role: formData.role.toLowerCase(),
//         }),
//       });

//       const data = await res.json();

//       if (res.ok && data.userId) {
//         setSuccess(`✅ ${data.message}`);
//         setError("");

//         // Reset form
//         setFormData({
//           email: "",
//           password: "",
//           firstName: "",
//           lastName: "",
//           signupEmail: "",
//           signupPassword: "",
//           confirmPassword: "",
//           role: "",
//           remember: false,
//           terms: false,
//         });

//         // Redirect to profile form
//         const profilePath =
//           formData.role.toLowerCase() === "jobseeker"
//             ? `/jobseeker-profile/${data.userId}`
//             : `/employer-profile/${data.userId}`;
//         setTimeout(() => navigate(profilePath), 1200);
//       } else {
//         setError("⚠️ " + (data.error || data.message || "Something went wrong"));
//         setSuccess("");
//       }
//     } catch (err) {
//       setError("⚠️ Something went wrong: " + err.message);
//       setSuccess("");
//     }
//   };

//   // Floating label effect
//   useEffect(() => {
//     const inputs = document.querySelectorAll("input, select");
//     inputs.forEach((input) => {
//       const handleFocus = () => (input.parentElement.style.transform = "translateY(-2px)");
//       const handleBlur = () => (input.parentElement.style.transform = "translateY(0)");
//       input.addEventListener("focus", handleFocus);
//       input.addEventListener("blur", handleBlur);
//       return () => {
//         input.removeEventListener("focus", handleFocus);
//         input.removeEventListener("blur", handleBlur);
//       };
//     });
//   }, []);

//   return (
//     <div className="auth-signin-signup-container">
//       <div className="auth-main-container">
//         {/* LEFT */}
//         <div className="auth-left-section">
//           <div className="auth-logo">JobEntry</div>
//           <div className="auth-hero-content">
//             <h1 className="auth-hero-title">
//               Find The Perfect Job That You Deserved
//             </h1>
//             <p className="auth-hero-subtitle">
//               Join thousands of professionals who have found their dream careers through our platform. Your next opportunity is just a click away.
//             </p>
//           </div>
//           <div className="auth-business-icons">
//             <div className="auth-icon-circle">👥</div>
//             <div className="auth-icon-circle">💼</div>
//             <div className="auth-icon-circle">🚀</div>
//           </div>
//         </div>

//         {/* RIGHT */}
//         <div className="auth-right-section">
//           <div className="auth-form-header">
//             <div className="auth-form-tabs">
//               <div
//                 className={`auth-tab ${activeTab === "login" ? "auth-active" : ""}`}
//                 onClick={() => switchTab("login")}
//               >
//                 Login
//               </div>
//               <div
//                 className={`auth-tab ${activeTab === "signup" ? "auth-active" : ""}`}
//                 onClick={() => switchTab("signup")}
//               >
//                 Sign Up
//               </div>
//             </div>
//           </div>

//           {error && <div className="auth-error-message">{error}</div>}
//           {success && <div className="auth-success-message">{success}</div>}

//           {/* LOGIN FORM */}
//           {activeTab === "login" && (
//             <form className="auth-login-form auth-active" onSubmit={handleLoginSubmit}>
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="auth-form-title">Welcome Back!</h2>
//                 <p className="auth-form-subtitle">Please sign in to your account</p>
//               </div>

//               <div className="auth-form-group">
//                 <label>Email Address</label>
//                 <input
//                   type="email"
//                   name="email"
//                   value={formData.email}
//                   onChange={handleInputChange}
//                   placeholder="Enter your email"
//                 />
//               </div>
//               <div className="auth-form-group">
//                 <label>Password</label>
//                 <input
//                   type="password"
//                   name="password"
//                   value={formData.password}
//                   onChange={handleInputChange}
//                   placeholder="Enter your password"
//                 />
//               </div>

//               <div className="auth-checkbox-group">
//                 <input
//                   type="checkbox"
//                   name="remember"
//                   checked={formData.remember}
//                   onChange={handleInputChange}
//                 />
//                 <label>
//                   I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
//                 </label>
//               </div>

//               <button type="submit" className="auth-btn-primary" disabled={!formData.remember}>
//                 Sign In
//               </button>

//               <div style={{ marginTop: "10px", fontSize: "13px", color: "#888" }}>
//                 <b>Admin Login:</b> <br />
//                 Email: <span style={{ fontFamily: "monospace" }}>{ADMIN_EMAIL}</span> <br />
//                 Password: <span style={{ fontFamily: "monospace" }}>{ADMIN_PASSWORD}</span>
//               </div>

//               <div className="form-footer">
//                 <p><Link to="/forgot-password">Forgot Password?</Link></p>
//               </div>
//             </form>
//           )}

//           {/* SIGNUP FORM */}
//           {activeTab === "signup" && (
//             <form className="auth-signup-form auth-active" onSubmit={handleSignupSubmit}>
//               <div style={{ textAlign: "center", marginBottom: "30px" }}>
//                 <h2 className="auth-form-title">Create Account</h2>
//                 <p className="auth-form-subtitle">Join us and start your career journey</p>
//               </div>

//               <div className="auth-form-row">
//                 <div className="auth-form-group">
//                   <label>First Name</label>
//                   <input
//                     type="text"
//                     name="firstName"
//                     value={formData.firstName}
//                     onChange={handleInputChange}
//                     placeholder="Khushi"
//                   />
//                 </div>
//                 <div className="auth-form-group">
//                   <label>Last Name</label>
//                   <input
//                     type="text"
//                     name="lastName"
//                     value={formData.lastName}
//                     onChange={handleInputChange}
//                     placeholder="Kundariya"
//                   />
//                 </div>
//               </div>

//               <div className="auth-form-group">
//                 <label>Email Address</label>
//                 <input
//                   type="email"
//                   name="signupEmail"
//                   value={formData.signupEmail}
//                   onChange={handleInputChange}
//                   placeholder="khushi@example.com"
//                 />
//               </div>

//               <div className="auth-form-group">
//                 <label>Password</label>
//                 <input
//                   type="password"
//                   name="signupPassword"
//                   value={formData.signupPassword}
//                   onChange={handleInputChange}
//                   placeholder="Create a strong password"
//                 />
//               </div>

//               <div className="auth-form-group">
//                 <label>Confirm Password</label>
//                 <input
//                   type="password"
//                   name="confirmPassword"
//                   value={formData.confirmPassword}
//                   onChange={handleInputChange}
//                   placeholder="Confirm your password"
//                 />
//               </div>

//               <div className="auth-form-group">
//                 <label>Register As</label>
//                 <select name="role" value={formData.role} onChange={handleInputChange}>
//                   <option value="">-- Select Role --</option>
//                   <option value="jobseeker">Job Seeker</option>
//                   <option value="employer">Employer</option>
//                 </select>
//               </div>

//               <div className="auth-checkbox-group">
//                 <input type="checkbox" name="terms" checked={formData.terms} onChange={handleInputChange} />
//                 <label>
//                   I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
//                 </label>
//               </div>

//               <button
//                 type="submit"
//                 className="auth-btn-primary"
//                 disabled={!formData.terms || !formData.role}
//               >
//                 Create Account
//               </button>
//             </form>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignInSignUp;

import React, { useState, useEffect } from "react";
import "../Login/Login.css";
import { Link, useNavigate } from "react-router-dom";

const ADMIN_EMAIL = "admin@jobentry.com";
const ADMIN_PASSWORD = "admin123";

const SignInSignUp = ({ setUser }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("login");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
    signupEmail: "",
    signupPassword: "",
    confirmPassword: "",
    role: "",
    remember: false,
    terms: false,
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const switchTab = (tab) => {
    setError("");
    setSuccess("");
    setActiveTab(tab);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  // ---------------- LOGIN ----------------
  // const handleLoginSubmit = async (e) => {
  //   e.preventDefault();

  //   if (!formData.email || !formData.password) {
  //     setError("⚠️ Please fill all the fields.");
  //     setSuccess("");
  //     return;
  //   }

  //   try {
  //     const res = await fetch("http://localhost:5000/api/login", {
  //       method: "POST",
  //       headers: { "Content-Type": "application/json" },
  //       body: JSON.stringify({ email: formData.email, password: formData.password }),
  //     });

  //     const data = await res.json();

  //     if (res.ok && data.success) {
  //       setSuccess(`✅ ${data.message}`);
  //       setError("");

  //       if (data.user) {
  //         localStorage.setItem("user", JSON.stringify(data.user));
  //         setUser(data.user);

  //         // Delay for smooth UX
  //         setTimeout(() => {
  //           const { role, id, profileCompleted } = data.user;

  //           if (role.toLowerCase() === "admin") {
  //             navigate("/admin");
  //           } else if (role.toLowerCase() === "jobseeker") {
  //             if (!profileCompleted) {
  //               navigate(`/jobseeker-profile/${id}`);
  //             } else {
  //               navigate(`/jobseeker-dashboard/${id}`);
  //             }
  //           } else if (role.toLowerCase() === "employer") {
  //             if (!profileCompleted) {
  //               navigate(`/employer-profile/${id}`);
  //             } else {
  //               navigate(`/employer-dashboard/${id}`);
  //             }
  //           } else {
  //             navigate("/");
  //           }
  //         }, 1200); // 1.2s delay
  //       }
  //     } else {
  //       setError("⚠️ " + (data.error || data.message || "Something went wrong"));
  //       setSuccess("");
  //     }
  //   } catch (err) {
  //     setError("⚠️ Something went wrong: " + err.message);
  //     setSuccess("");
  //   }
  // };
const handleLoginSubmit = async (e) => {
    e.preventDefault();

    if (!formData.email || !formData.password) {
      setError("⚠️ Please fill all the fields.");
      setSuccess("");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: formData.email, password: formData.password }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setSuccess(`✅ ${data.message}`);
        setError("");

        if (data.user) {
          localStorage.setItem("user", JSON.stringify(data.user));
          setUser(data.user);

          // Corrected redirect logic
          const { role, id, profileCompleted } = data.user;
          const lowerRole = role.toLowerCase();

          if (lowerRole === "admin") {
            navigate("/admin");
          } else if (lowerRole === "jobseeker") {
            if (!profileCompleted) {
              navigate(`/jobseeker-profile/${id}`);
            } else {
              navigate(`/jobseeker-dashboard/${id}`);
            }
          } else if (lowerRole === "employer") {
            if (!profileCompleted) {
              navigate(`/employer-profile/${id}`);
            } else {
              navigate(`/employer-dashboard/${id}`);
            }
          } else {
            navigate("/"); 
          }
        }
      } else {
        setError("⚠️ " + (data.error || data.message || "Something went wrong"));
        setSuccess("");
      }
    } catch (err) {
      setError("⚠️ Something went wrong: " + err.message);
      setSuccess("");
    }
  };
  // ---------------- SIGNUP ----------------
  const handleSignupSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.firstName ||
      !formData.lastName ||
      !formData.signupEmail ||
      !formData.signupPassword ||
      !formData.confirmPassword ||
      !formData.role
    ) {
      setError("⚠️ Please fill all the fields and select a role.");
      setSuccess("");
      return;
    }

    if (!formData.signupEmail.includes("@") || !formData.signupEmail.includes(".")) {
      setError("⚠️ Please enter a valid email address.");
      setSuccess("");
      return;
    }

    if (formData.signupPassword !== formData.confirmPassword) {
      setError("⚠️ Passwords do not match.");
      setSuccess("");
      return;
    }

    if (!formData.terms) {
      setError("⚠️ You must agree to the Terms of Service and Privacy Policy.");
      setSuccess("");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName: formData.firstName,
          lastName: formData.lastName,
          email: formData.signupEmail,
          password: formData.signupPassword,
          role: formData.role.toLowerCase(),
        }),
      });

      const data = await res.json();

      if (res.ok && data.userId) {
        setSuccess(`✅ ${data.message}`);
        setError("");

        // Reset form
        setFormData({
          email: "",
          password: "",
          firstName: "",
          lastName: "",
          signupEmail: "",
          signupPassword: "",
          confirmPassword: "",
          role: "",
          remember: false,
          terms: false,
        });

        // Redirect to profile form
        const profilePath =
          formData.role.toLowerCase() === "jobseeker"
            ? `/jobseeker-profile/${data.userId}`
            : `/employer-profile/${data.userId}`;
        setTimeout(() => navigate(profilePath), 1200);
      } else {
        setError("⚠️ " + (data.error || data.message || "Something went wrong"));
        setSuccess("");
      }
    } catch (err) {
      setError("⚠️ Something went wrong: " + err.message);
      setSuccess("");
    }
  };

  // ---------------- Floating label effect ----------------
  useEffect(() => {
    const inputs = document.querySelectorAll("input, select");
    inputs.forEach((input) => {
      const handleFocus = () => (input.parentElement.style.transform = "translateY(-2px)");
      const handleBlur = () => (input.parentElement.style.transform = "translateY(0)");
      input.addEventListener("focus", handleFocus);
      input.addEventListener("blur", handleBlur);
      return () => {
        input.removeEventListener("focus", handleFocus);
        input.removeEventListener("blur", handleBlur);
      };
    });
  }, []);

  return (
    <div className="auth-signin-signup-container">
      <div className="auth-main-container">
        {/* LEFT */}
        <div className="auth-left-section">
          <div className="auth-logo">JobEntry</div>
          <div className="auth-hero-content">
            <h1 className="auth-hero-title">
              Find The Perfect Job That You Deserved
            </h1>
            <p className="auth-hero-subtitle">
              Join thousands of professionals who have found their dream careers through our platform. Your next opportunity is just a click away.
            </p>
          </div>
          <div className="auth-business-icons">
            <div className="auth-icon-circle">👥</div>
            <div className="auth-icon-circle">💼</div>
            <div className="auth-icon-circle">🚀</div>
          </div>
        </div>

        {/* RIGHT */}
        <div className="auth-right-section">
          <div className="auth-form-header">
            <div className="auth-form-tabs">
              <div
                className={`auth-tab ${activeTab === "login" ? "auth-active" : ""}`}
                onClick={() => switchTab("login")}
              >
                Login
              </div>
              <div
                className={`auth-tab ${activeTab === "signup" ? "auth-active" : ""}`}
                onClick={() => switchTab("signup")}
              >
                Sign Up
              </div>
            </div>
          </div>

          {error && <div className="auth-error-message">{error}</div>}
          {success && <div className="auth-success-message">{success}</div>}

          {/* LOGIN FORM */}
          {activeTab === "login" && (
            <form className="auth-login-form auth-active" onSubmit={handleLoginSubmit}>
              <div style={{ textAlign: "center", marginBottom: "30px" }}>
                <h2 className="auth-form-title">Welcome Back!</h2>
                <p className="auth-form-subtitle">Please sign in to your account</p>
              </div>

              <div className="auth-form-group">
                <label>Email Address</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="Enter your email"
                />
              </div>
              <div className="auth-form-group">
                <label>Password</label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="Enter your password"
                />
              </div>

              <div className="auth-checkbox-group">
                <input
                  type="checkbox"
                  name="remember"
                  checked={formData.remember}
                  onChange={handleInputChange}
                />
                <label>
                  I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
                </label>
              </div>

              <button type="submit" className="auth-btn-primary" disabled={!formData.remember}>
                Sign In
              </button>

              <div style={{ marginTop: "10px", fontSize: "13px", color: "#888" }}>
                <b>Admin Login:</b> <br />
                Email: <span style={{ fontFamily: "monospace" }}>{ADMIN_EMAIL}</span> <br />
                Password: <span style={{ fontFamily: "monospace" }}>{ADMIN_PASSWORD}</span>
              </div>

              <div className="form-footer">
                <p><Link to="/forgot-password">Forgot Password?</Link></p>
              </div>
            </form>
          )}

          {/* SIGNUP FORM */}
          {activeTab === "signup" && (
            <form className="auth-signup-form auth-active" onSubmit={handleSignupSubmit}>
              <div style={{ textAlign: "center", marginBottom: "30px" }}>
                <h2 className="auth-form-title">Create Account</h2>
                <p className="auth-form-subtitle">Join us and start your career journey</p>
              </div>

              <div className="auth-form-row">
                <div className="auth-form-group">
                  <label>First Name</label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    placeholder="Khushi"
                  />
                </div>
                <div className="auth-form-group">
                  <label>Last Name</label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    placeholder="Kundariya"
                  />
                </div>
              </div>

              <div className="auth-form-group">
                <label>Email Address</label>
                <input
                  type="email"
                  name="signupEmail"
                  value={formData.signupEmail}
                  onChange={handleInputChange}
                  placeholder="khushi@example.com"
                />
              </div>

              <div className="auth-form-group">
                <label>Password</label>
                <input
                  type="password"
                  name="signupPassword"
                  value={formData.signupPassword}
                  onChange={handleInputChange}
                  placeholder="Create a strong password"
                />
              </div>

              <div className="auth-form-group">
                <label>Confirm Password</label>
                <input
                  type="password"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  placeholder="Confirm your password"
                />
              </div>

              <div className="auth-form-group">
                <label>Register As</label>
                <select name="role" value={formData.role} onChange={handleInputChange}>
                  <option value="">-- Select Role --</option>
                  <option value="jobseeker">Job Seeker</option>
                  <option value="employer">Employer</option>
                </select>
              </div>

              <div className="auth-checkbox-group">
                <input type="checkbox" name="terms" checked={formData.terms} onChange={handleInputChange} />
                <label>
                  I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
                </label>
              </div>

              <button
                type="submit"
                className="auth-btn-primary"
                disabled={!formData.terms || !formData.role}
              >
                Create Account
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default SignInSignUp;
