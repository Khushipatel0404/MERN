// // // import React, { useState } from "react";
// // // import { useParams, useNavigate } from "react-router-dom";

// // // const EmployerProfileForm = () => {
// // //   const { userId } = useParams();
// // //   const navigate = useNavigate();

// // //   const [formData, setFormData] = useState({
// // //     companyName: "",
// // //     website: "",
// // //     industry: "",
// // //     phone: "",
// // //     address: "",
// // //     city: "",
// // //     country: "",
// // //     description: "",
// // //   });

// // //   const [error, setError] = useState("");
// // //   const [success, setSuccess] = useState("");

// // //   const handleInputChange = (e) => {
// // //     const { name, value } = e.target;
// // //     setFormData({ ...formData, [name]: value });
// // //   };

// // //   const handleSubmit = async (e) => {
// // //     e.preventDefault();
// // //     try {
// // //       const res = await fetch("http://localhost:5000/api/profile/employer", {
// // //         method: "POST",
// // //         headers: { "Content-Type": "application/json" },
// // //         body: JSON.stringify({ userId, ...formData }),
// // //       });

// // //       const data = await res.json();
// // //       if (res.ok && data.success) {
// // //         setSuccess(data.message);
// // //         setError("");
// // //         setTimeout(() => navigate("/login"), 1500); // Redirect to login
// // //       } else {
// // //         setError(data.message || "Something went wrong");
// // //       }
// // //     } catch (err) {
// // //       setError(err.message);
// // //     }
// // //   };

// // //   return (
// // //     <div className="profile-form-container">
// // //       <h2>Employer Profile</h2>
// // //       {error && <div className="error">{error}</div>}
// // //       {success && <div className="success">{success}</div>}
// // //       <form onSubmit={handleSubmit}>
// // //         <label>Company Name</label>
// // //         <input type="text" name="companyName" value={formData.companyName} onChange={handleInputChange} />

// // //         <label>Website</label>
// // //         <input type="text" name="website" value={formData.website} onChange={handleInputChange} />

// // //         <label>Industry</label>
// // //         <input type="text" name="industry" value={formData.industry} onChange={handleInputChange} />

// // //         <label>Phone</label>
// // //         <input type="text" name="phone" value={formData.phone} onChange={handleInputChange} />

// // //         <label>Address</label>
// // //         <input type="text" name="address" value={formData.address} onChange={handleInputChange} />

// // //         <label>City</label>
// // //         <input type="text" name="city" value={formData.city} onChange={handleInputChange} />

// // //         <label>Country</label>
// // //         <input type="text" name="country" value={formData.country} onChange={handleInputChange} />

// // //         <label>Description</label>
// // //         <textarea name="description" value={formData.description} onChange={handleInputChange} />

// // //         <button type="submit">Save Profile</button>
// // //       </form>
// // //     </div>
// // //   );
// // // };

// // // export default EmployerProfileForm;
// // import React, { useState } from "react";
// // import { useNavigate } from "react-router-dom";

// // const EmployerProfile = ({ userId }) => {
// //   const navigate = useNavigate();

// //   const [formData, setFormData] = useState({
// //     companyName: "",
// //     website: "",
// //     industry: "",
// //     companySize: "",
// //     phone: "",
// //     email: "",
// //     address: "",
// //     city: "",
// //     state: "",
// //     country: "",
// //     description: "",
// //     logo: "",
// //     linkedin: "",
// //   });

// //   const [success, setSuccess] = useState("");
// //   const [error, setError] = useState("");

// //   const handleInputChange = (e) => {
// //     const { name, value } = e.target;
// //     setFormData((prev) => ({ ...prev, [name]: value }));
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();

// //     try {
// //       const res = await fetch("http://localhost:5000/api/profile/employer", {
// //         method: "POST",
// //         headers: { "Content-Type": "application/json" },
// //         body: JSON.stringify({ ...formData, userId }),
// //       });

// //       const data = await res.json();
// //       if (res.ok && data.success) {
// //         setSuccess(data.message);
// //         setError("");
// //         setTimeout(() => navigate("/recruiter"), 1500);
// //       } else {
// //         setError(data.message || "Something went wrong");
// //         setSuccess("");
// //       }
// //     } catch (err) {
// //       setError("Error: " + err.message);
// //       setSuccess("");
// //     }
// //   };

// //   return (
// //     <div className="profile-container">
// //       <h2>Employer Profile</h2>
// //       {error && <p style={{ color: "red" }}>{error}</p>}
// //       {success && <p style={{ color: "green" }}>{success}</p>}
// //       <form onSubmit={handleSubmit}>
// //         <label>Company Name</label>
// //         <input name="companyName" value={formData.companyName} onChange={handleInputChange} />

// //         <label>Website</label>
// //         <input name="website" value={formData.website} onChange={handleInputChange} />

// //         <label>Industry</label>
// //         <input name="industry" value={formData.industry} onChange={handleInputChange} />

// //         <label>Company Size</label>
// //         <input name="companySize" value={formData.companySize} onChange={handleInputChange} />

// //         <label>Phone</label>
// //         <input name="phone" value={formData.phone} onChange={handleInputChange} />

// //         <label>Email</label>
// //         <input name="email" value={formData.email} onChange={handleInputChange} />

// //         <label>Address</label>
// //         <input name="address" value={formData.address} onChange={handleInputChange} />

// //         <label>City</label>
// //         <input name="city" value={formData.city} onChange={handleInputChange} />

// //         <label>State</label>
// //         <input name="state" value={formData.state} onChange={handleInputChange} />

// //         <label>Country</label>
// //         <input name="country" value={formData.country} onChange={handleInputChange} />

// //         <label>Description</label>
// //         <textarea name="description" value={formData.description} onChange={handleInputChange} />

// //         <label>Logo URL</label>
// //         <input name="logo" value={formData.logo} onChange={handleInputChange} />

// //         <label>LinkedIn</label>
// //         <input name="linkedin" value={formData.linkedin} onChange={handleInputChange} />

// //         <button type="submit">Submit Profile</button>
// //       </form>
// //     </div>
// //   );
// // };

// // export default EmployerProfile;

// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";

// const EmployerProfile = ({ userId }) => {
//   const navigate = useNavigate();

//   const [formData, setFormData] = useState({
//     companyName: "",
//     website: "",
//     industry: "",
//     companySize: "",
//     phone: "",
//     email: "",
//     address: "",
//     city: "",
//     state: "",
//     country: "",
//     description: "",
//     logo: "",
//     linkedin: "",
//   });

//   const [success, setSuccess] = useState("");
//   const [error, setError] = useState("");

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({ ...prev, [name]: value }));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!userId) return setError("❌ userId missing!");

//     try {
//       const res = await fetch("http://localhost:5000/api/profile/employer", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ ...formData, userId }),
//       });

//       const data = await res.json();
//       if (res.ok && data.success) {
//         setSuccess(data.message);
//         setError("");
//         setTimeout(() => navigate("/recruiter"), 1500);
//       } else {
//         setError(data.message || "Something went wrong");
//         setSuccess("");
//       }
//     } catch (err) {
//       setError("Error: " + err.message);
//       setSuccess("");
//     }
//   };

//   return (
//     <div className="profile-container">
//       <h2>Employer Profile</h2>
//       {error && <p style={{ color: "red" }}>{error}</p>}
//       {success && <p style={{ color: "green" }}>{success}</p>}
//       <form onSubmit={handleSubmit}>
//         <label>Company Name</label>
//         <input name="companyName" value={formData.companyName} onChange={handleInputChange} />

//         <label>Website</label>
//         <input name="website" value={formData.website} onChange={handleInputChange} />

//         <label>Industry</label>
//         <input name="industry" value={formData.industry} onChange={handleInputChange} />

//         <label>Company Size</label>
//         <input name="companySize" value={formData.companySize} onChange={handleInputChange} />

//         <label>Phone</label>
//         <input name="phone" value={formData.phone} onChange={handleInputChange} />

//         <label>Email</label>
//         <input name="email" value={formData.email} onChange={handleInputChange} />

//         <label>Address</label>
//         <input name="address" value={formData.address} onChange={handleInputChange} />

//         <label>City</label>
//         <input name="city" value={formData.city} onChange={handleInputChange} />

//         <label>State</label>
//         <input name="state" value={formData.state} onChange={handleInputChange} />

//         <label>Country</label>
//         <input name="country" value={formData.country} onChange={handleInputChange} />

//         <label>Description</label>
//         <textarea name="description" value={formData.description} onChange={handleInputChange} />

//         <label>Logo URL</label>
//         <input name="logo" value={formData.logo} onChange={handleInputChange} />

//         <label>LinkedIn</label>
//         <input name="linkedin" value={formData.linkedin} onChange={handleInputChange} />

//         <button type="submit">Submit Profile</button>
//       </form>
//     </div>
//   );
// };

// export default EmployerProfile;
// import React, { useState } from "react";
// import { useNavigate, useParams } from "react-router-dom";

// const EmployerProfile = () => {
//   const navigate = useNavigate();
//   const { userId } = useParams(); // Get userId from URL

//   const [formData, setFormData] = useState({
//     companyName: "",
//     website: "",
//     industry: "",
//     companySize: "",
//     phone: "",
//     email: "",
//     address: "",
//     city: "",
//     state: "",
//     country: "",
//     description: "",
//     logo: "",
//     linkedin: "",
//   });

//   const [success, setSuccess] = useState("");
//   const [error, setError] = useState("");

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({ ...prev, [name]: value }));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!userId) return setError("❌ userId missing!");

//     try {
//       const res = await fetch("http://localhost:5000/api/profile/employer", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ ...formData, userId }),
//       });

//       const data = await res.json();
//       if (res.ok && data.success) {
//         setSuccess(data.message);
//         setError("");
//         setTimeout(() => navigate("/signin"), 1500);
//       } else {
//         setError(data.message || "Something went wrong");
//         setSuccess("");
//       }
//     } catch (err) {
//       setError("Error: " + err.message);
//       setSuccess("");
//     }
//   };

//   return (
//     <div className="profile-container">
//       <h2>Employer Profile</h2>
//       {error && <p style={{ color: "red" }}>{error}</p>}
//       {success && <p style={{ color: "green" }}>{success}</p>}
//       <form onSubmit={handleSubmit}>
//         <label>Company Name</label>
//         <input name="companyName" value={formData.companyName} onChange={handleInputChange} />

//         <label>Website</label>
//         <input name="website" value={formData.website} onChange={handleInputChange} />

//         <label>Industry</label>
//         <input name="industry" value={formData.industry} onChange={handleInputChange} />

//         <label>Company Size</label>
//         <input name="companySize" value={formData.companySize} onChange={handleInputChange} />

//         <label>Phone</label>
//         <input name="phone" value={formData.phone} onChange={handleInputChange} />

//         <label>Email</label>
//         <input name="email" value={formData.email} onChange={handleInputChange} />

//         <label>Address</label>
//         <input name="address" value={formData.address} onChange={handleInputChange} />

//         <label>City</label>
//         <input name="city" value={formData.city} onChange={handleInputChange} />

//         <label>State</label>
//         <input name="state" value={formData.state} onChange={handleInputChange} />

//         <label>Country</label>
//         <input name="country" value={formData.country} onChange={handleInputChange} />

//         <label>Description</label>
//         <textarea name="description" value={formData.description} onChange={handleInputChange} />

//         <label>Logo URL</label>
//         <input name="logo" value={formData.logo} onChange={handleInputChange} />

//         <label>LinkedIn</label>
//         <input name="linkedin" value={formData.linkedin} onChange={handleInputChange} />

//         <button type="submit">Submit Profile</button>
//       </form>
//     </div>
//   );
// };

// export default EmployerProfile;
import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../Login/Login.css"; 

const EmployerProfile = () => {
  const navigate = useNavigate();
  const { userId } = useParams();

  const [formData, setFormData] = useState({
    companyName: "",
    website: "",
    industry: "",
    companySize: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "",
    country: "",
    description: "",
    logo: "",
    linkedin: "",
  });

  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!userId) return setError("❌ userId missing!");

    try {
      const res = await fetch("http://localhost:5000/api/profile/employer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...formData, userId }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSuccess(data.message);
        setError("");
        setTimeout(() => navigate("/signin"), 1500);
      } else {
        setError(data.message || "Something went wrong");
        setSuccess("");
      }
    } catch (err) {
      setError("Error: " + err.message);
      setSuccess("");
    }
  };

  return (
    <div className="auth-signin-signup-container">
      <div className="auth-main-container">
        {/* LEFT Section (optional image / info) */}
        <div className="auth-left-section">
          <div className="auth-logo">JobEntry</div>
          <div className="auth-hero-content">
            <h1 className="auth-hero-title">Employer Profile Setup</h1>
            <p className="auth-hero-subtitle">
              Complete your company profile to post jobs and find the best talent.
            </p>
          </div>
        </div>

        {/* RIGHT Section (Form) */}
        <div className="auth-right-section">
          <div className="auth-form-header">
            <h2 className="auth-form-title">Employer Profile</h2>
            <p className="auth-form-subtitle">Fill out your company details</p>
          </div>

          {error && <div className="auth-error-message">{error}</div>}
          {success && <div className="auth-success-message">{success}</div>}

          <form onSubmit={handleSubmit} className="auth-signup-form auth-active">
            <div className="auth-form-group">
              <label>Company Name</label>
              <input name="companyName" value={formData.companyName} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Website</label>
              <input name="website" value={formData.website} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Industry</label>
              <input name="industry" value={formData.industry} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Company Size</label>
              <input name="companySize" value={formData.companySize} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Phone</label>
              <input name="phone" value={formData.phone} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Email</label>
              <input name="email" value={formData.email} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Address</label>
              <input name="address" value={formData.address} onChange={handleInputChange} />
            </div>

            <div className="auth-form-row">
              <div className="auth-form-group">
                <label>City</label>
                <input name="city" value={formData.city} onChange={handleInputChange} />
              </div>
              <div className="auth-form-group">
                <label>State</label>
                <input name="state" value={formData.state} onChange={handleInputChange} />
              </div>
            </div>

            <div className="auth-form-group">
              <label>Country</label>
              <input name="country" value={formData.country} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Description</label>
              <textarea name="description" value={formData.description} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>Logo URL</label>
              <input name="logo" value={formData.logo} onChange={handleInputChange} />
            </div>

            <div className="auth-form-group">
              <label>LinkedIn</label>
              <input name="linkedin" value={formData.linkedin} onChange={handleInputChange} />
            </div>

            <button type="submit" className="auth-btn-primary">Submit Profile</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EmployerProfile;
