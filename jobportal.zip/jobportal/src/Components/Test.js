import React, { useState, useEffect } from "react";

const testimonials = [
  {
    id: 1,
    text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
    img: "https://randomuser.me/api/portraits/men/32.jpg",
    name: "Client Name",
    profession: "Profession",
  },
  {
    id: 2,
    text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
    img: "https://randomuser.me/api/portraits/men/45.jpg",
    name: "Client Name",
    profession: "Profession",
  },
  {
    id: 3,
    text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
    img: "https://randomuser.me/api/portraits/women/65.jpg",
    name: "Client Name",
    profession: "Profession",
  },
];

export default function TestimonialCarousel() {
  const [activeIndex, setActiveIndex] = useState(1);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      style={{
        maxWidth: "1200px",
        margin: "60px auto",
        padding: "20px",
        textAlign: "center",
      }}
    >
      <h1 style={{ marginBottom: "40px" }}>Our Clients Say!!!</h1>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "20px",
        }}
      >
        {testimonials.map((t, i) => {
          const isActive = i === activeIndex;

          return (
            <div
              key={t.id}
              style={{
                flex: "0 0 30%",
                minWidth: "300px",
                padding: "20px",
                borderRadius: "8px",
                background: isActive ? "#00b074" : "#f8f9fa",
                color: isActive ? "#fff" : "#000",
                transition: "all 0.5s ease",
              }}
            >
              <i
                className="fa fa-quote-left"
                style={{
                  fontSize: "24px",
                  marginBottom: "12px",
                  color: isActive ? "#fff" : "#00b074",
                }}
              ></i>
              <p style={{ marginBottom: "1rem" }}>{t.text}</p>
              <div style={{ display: "flex", alignItems: "center" }}>
                <img
                  src={t.img}
                  alt="client"
                  style={{
                    width: "50px",
                    height: "50px",
                    borderRadius: "50%",
                    flexShrink: 0,
                  }}
                />
                <div style={{ paddingLeft: "12px", textAlign: "left" }}>
                  <h5 style={{ margin: 0, color: isActive ? "#fff" : "#000" }}>
                    {t.name}
                  </h5>
                  <small style={{ color: isActive ? "#f0f0f0" : "#555" }}>
                    {t.profession}
                  </small>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Dots */}
      <div style={{ marginTop: "20px" }}>
        {testimonials.map((_, i) => (
          <span
            key={i}
            onClick={() => setActiveIndex(i)}
            style={{
              display: "inline-block",
              width: "10px",
              height: "10px",
              margin: "0 5px",
              borderRadius: "50%",
              background: i === activeIndex ? "#00b074" : "#ccc",
              cursor: "pointer",
            }}
          ></span>
        ))}
      </div>
    </div>
  );
}
