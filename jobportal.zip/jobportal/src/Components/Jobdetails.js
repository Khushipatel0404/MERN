
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const JobDetails = () => {
  const navigate = useNavigate();
  const { employerId, jobseekerId } = useParams();
  const [jobData, setJobData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [jobSeekerProfile, setJobSeekerProfile] = useState(null);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [applicationData, setApplicationData] = useState({
    name: "",
    email: "",
    portfolio: "",
    coverLetter: "",
    resume: null
  });

  // Fetch job details data
  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/jobdetails/${employerId}/${jobseekerId}`);
        if (res.data.success) {
          setJobData(res.data);
        } else {
          setError("Job details not found");
        }
      } catch (err) {
        console.error("❌ Error fetching job details:", err);
        setError("Error fetching job details");
      } finally {
        setLoading(false);
      }
    };

    if (employerId && jobseekerId) {
      fetchJobDetails();
    }
  }, [employerId, jobseekerId]);

  // User authentication and profile setup
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser(storedUser);

      // Job Seeker profile fetch
      fetch(`http://localhost:5000/api/profile/jobseeker/${storedUser.id}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success) setJobSeekerProfile(data.profile);
        })
        .catch((err) => console.error("Profile fetch error:", err));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/");
  };

  const handleProfileUpdate = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const updatedData = Object.fromEntries(formData.entries());

    fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedData),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setJobSeekerProfile(data.profile);
          setIsEditOpen(false);
        }
      })
      .catch((err) => console.error(err));
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          oldPassword,
          newPassword,
        }),
      });

      const data = await res.json();
      if (data.success) {
        alert("✅ Password updated successfully");
        setIsChangePasswordOpen(false);
      } else {
        alert("❌ " + data.message);
      }
    } catch (err) {
      console.error("Change Password Error:", err);
      alert("❌ Error updating password");
    }
  };

  const handleApplicationSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const formData = new FormData();
      formData.append('name', applicationData.name);
      formData.append('email', applicationData.email);
      formData.append('portfolio', applicationData.portfolio);
      formData.append('coverLetter', applicationData.coverLetter);
      formData.append('employerId', employerId);
      formData.append('jobseekerId', jobseekerId);
      
      if (applicationData.resume) {
        formData.append('resume', applicationData.resume);
      }

      const response = await fetch('http://localhost:5000/api/apply-job', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();
      
      if (result.success) {
        alert('Application submitted successfully!');
        setIsApplyModalOpen(false);
        setApplicationData({
          name: "",
          email: "",
          portfolio: "",
          coverLetter: "",
          resume: null
        });
      } else {
        alert('Error submitting application: ' + result.message);
      }
    } catch (error) {
      console.error('Error submitting application:', error);
      alert('Error submitting application. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setApplicationData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setApplicationData(prev => ({
      ...prev,
      resume: file
    }));
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ height: "50vh" }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-5">
        <div className="alert alert-danger text-center">
          <h4>Error</h4>
          <p>{error}</p>
          <Link to="/jobs" className="btn btn-primary">Back to Jobs</Link>
        </div>
      </div>
    );
  }

  if (!jobData) {
    return (
      <div className="container mt-5">
        <div className="alert alert-warning text-center">
          <h4>No Data Found</h4>
          <p>Job details not available</p>
          <Link to="/jobs" className="btn btn-primary">Back to Jobs</Link>
        </div>
      </div>
    );
  }

  const { employer, jobseeker } = jobData;

  return (
    <div>
      {/* Navigation Bar */}
     <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
       <Link
         to="/"
         className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5"
       >
         <h1 className="m-0 text-primary">JobEntry</h1>
       </Link>
     
       <button
         type="button"
         className="navbar-toggler me-4"
         data-bs-toggle="collapse"
         data-bs-target="#navbarCollapse"
       >
         <span className="navbar-toggler-icon"></span>
       </button>
     
       <div className="collapse navbar-collapse" id="navbarCollapse">
         <div className="navbar-nav ms-auto p-4 p-lg-0">
           {user && (
             <span className="nav-item nav-link text-primary fw-bold me-2">
               Welcome, {user.firstName || user.name}
             </span>
           )}
     
           <Link to="/" className="nav-item nav-link">Home</Link>
           <Link to="/about" className="nav-item nav-link">About</Link>
     
           <div className="nav-item dropdown">
             <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
               Jobs
             </a>
             <div className="dropdown-menu rounded-0 m-0">
               <Link to="/jobs" className="dropdown-item">Job List</Link>
               <Link to="/jobdetails" className="dropdown-item">Job Detail</Link>
               {user && (
       <Link to="/user/applications" className="nav-item nav-link">
         My Applications
       </Link>
     )}
             </div>
           </div>
     
     
           <div className="nav-item dropdown">
             <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
               Pages
             </a>
             <div className="dropdown-menu rounded-0 m-0">
               <Link to="/category" className="dropdown-item">Job Category</Link>
               <Link to="/testimonial" className="dropdown-item">Testimonial</Link>
               <Link to="/404" className="dropdown-item">404</Link>
             </div>
           </div>
     
           <Link to="/contact" className="nav-item nav-link">Contact</Link>
     
           {/* Profile / Login */}
           {user ? (
             <div className="nav-item dropdown" style={{ position: "relative" }}>
               <a
                 href="#"
                 className="nav-link dropdown-toggle d-flex align-items-center"
                 onClick={(e) => {
                   e.preventDefault();
                   setIsProfileOpen(!isProfileOpen);
                 }}
               >
                 {user.avatar ? (
       <img
         src={user.avatar}
         alt="profile"
         style={{
           width: "35px",
           height: "35px",
           borderRadius: "50%",
           marginRight: "8px",
           cursor: "pointer",
         }}
       />
     ) : (
       <div
         style={{
           width: "35px",
           height: "35px",
           borderRadius: "50%",
           background: "#ddd",
           display: "flex",
           alignItems: "center",
           justifyContent: "center",
           marginRight: "8px",
           cursor: "pointer",
           fontSize: "16px",
           fontWeight: "bold",
           color: "#555",
         }}
       >
         👤
       </div>
     )}
     
               </a>
     
     {isProfileOpen && (
       <div
         style={{
           position: "absolute",
           top: "50px",
           right: 0,
           background: "#fff",
           boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
           borderRadius: "10px",
           minWidth: "300px",
           zIndex: 100,
           overflow: "hidden",
           fontFamily: "Segoe UI, sans-serif",
         }}
       >
        
         <div
           style={{
             padding: "15px",
             borderBottom: "1px solid #eee",
             background: "#f9f9f9",
           }}
         >
           <strong style={{ fontSize: "16px", color: "#333" }}>
             {user.firstName} {user.lastName}
           </strong>
           <div style={{ fontSize: "13px", color: "#777" }}>
             {user.email}
           </div>
         </div>
     
         {jobSeekerProfile ? (
           <div style={{ padding: "12px 16px", fontSize: "14px", color: "#444" }}>
             {jobSeekerProfile.bio && <p>📝 <strong>Bio:</strong> {jobSeekerProfile.bio}</p>}
             {jobSeekerProfile.skills && <p>🛠️ <strong>Skills:</strong> {jobSeekerProfile.skills}</p>}
             {jobSeekerProfile.experience && <p>💼 <strong>Experience:</strong> {jobSeekerProfile.experience}</p>}
             {jobSeekerProfile.education && <p>🎓 <strong>Education:</strong> {jobSeekerProfile.education}</p>}
             {jobSeekerProfile.phone && <p>📞 <strong>Phone:</strong> {jobSeekerProfile.phone}</p>}
             {jobSeekerProfile.location && (
               <p>🌍 <strong>Location:</strong> {jobSeekerProfile.location.city}, {jobSeekerProfile.location.state}, {jobSeekerProfile.location.country}</p>
             )}
             {jobSeekerProfile.linkedin && (
               <p>🔗 <a href={jobSeekerProfile.linkedin} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>LinkedIn</a></p>
             )}
             {jobSeekerProfile.github && (
               <p>💻 <a href={jobSeekerProfile.github} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>GitHub</a></p>
             )}
             {jobSeekerProfile.resume && (
               <p>📄 <a href={jobSeekerProfile.resume} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>View Resume</a></p>
             )}
             {jobSeekerProfile.expectedSalary && <p>💰 {jobSeekerProfile.expectedSalary}</p>}
             {jobSeekerProfile.availability && <p>⏳ {jobSeekerProfile.availability}</p>}
           </div>
         ) : (
           <div style={{ padding: "12px 16px", color: "#888" }}>
             ⚠️ No profile found
           </div>
         )}
     
        
         <button
           onClick={() => setIsEditOpen(true)}
           style={{
             width: "100%",
             background: "none",
             border: "none",
             color: "#3498db",
             padding: "12px 16px",
             textAlign: "left",
             cursor: "pointer",
             fontWeight: "bold",
             borderTop: "1px solid #eee",
           }}
         >
           ✏️ Edit Profile
         </button>
     
     
         <button
           onClick={() => setIsChangePasswordOpen(true)}
           style={{
             width: "100%",
             background: "none",
             border: "none",
             color: "#f39c12",
             padding: "12px 16px",
             textAlign: "left",
             cursor: "pointer",
             fontWeight: "bold",
             borderTop: "1px solid #eee",
           }}
         >
           🔑 Change Password
         </button>
     
         <button
           onClick={handleLogout}
           style={{
             width: "100%",
             background: "none",
             border: "none",
             color: "#e74c3c",
             padding: "12px 16px",
             textAlign: "left",
             cursor: "pointer",
             fontWeight: "bold",
             borderTop: "1px solid #eee",
           }}
         >
           🚪 Logout
         </button>
       </div>
     )}
     
             </div>
           ) : (
             <Link to="/signin" className="nav-item nav-link">Login</Link>
           )}
         </div>
     
         <Link
           to="/Category"
           className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"
           style={{ backgroundColor: "#00D9A0", borderColor: "#00D9A0" }}
         >
           Post A Job <i className="fa fa-arrow-right ms-3"></i>
         </Link>
       </div>
     {/* Change Password Modal */}
     {isChangePasswordOpen && (
       <div style={{
         position: "fixed",
         top: 0, left: 0, width: "100%", height: "100%",
         background: "rgba(0,0,0,0.5)", display: "flex",
         justifyContent: "center", alignItems: "center", zIndex: 200
       }}>
         <div style={{
           background: "#fff", padding: "20px",
           borderRadius: "8px", width: "400px"
         }}>
           <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>🔒 Change Password</h4>
           <form onSubmit={handleChangePassword}>
             <input
               type="password"
               placeholder="Old Password"
               value={oldPassword}
               onChange={(e) => setOldPassword(e.target.value)}
               style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
               required
             />
             <input
               type="password"
               placeholder="New Password"
               value={newPassword}
               onChange={(e) => setNewPassword(e.target.value)}
               style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
               required
             />
             <button type="submit" style={{
               padding: "8px 12px",
               background: "#00D9A0", color: "#fff",
               border: "none", borderRadius: "4px", cursor: "pointer"
             }}>
               Save
             </button>
             <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
               padding: "8px 12px", marginLeft: "10px",
               background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
             }}>
               Cancel
             </button>
           </form>
         </div>
       </div>
     )}
     
     
       {/* Edit Profile Modal with form */}
       {isEditOpen && (
         <div
           style={{
             position: "fixed",
             top: 0,
             left: 0,
             width: "100%",
             height: "100%",
             background: "rgba(0,0,0,0.5)",
             display: "flex",
             justifyContent: "center",
             alignItems: "center",
             zIndex: 200,
           }}
         >
           <div
             style={{
               background: "#fff",
               padding: "20px",
               borderRadius: "8px",
               width: "400px",
               maxHeight: "90vh",
               overflowY: "auto",
             }}
           >
             <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
               ✏️ Edit JobSeeker Profile
             </h4>
     
             <form onSubmit={handleProfileUpdate}>
               <label>Bio</label>
               <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Skills</label>
               <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Experience</label>
               <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Education</label>
               <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Phone</label>
               <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>LinkedIn</label>
               <input type="text" name="linkedin" defaultValue={jobSeekerProfile?.linkedin} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>GitHub</label>
               <input type="text" name="github" defaultValue={jobSeekerProfile?.github} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Resume</label>
               <input type="text" name="resume" defaultValue={jobSeekerProfile?.resume} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Expected Salary</label>
               <input type="text" name="expectedSalary" defaultValue={jobSeekerProfile?.expectedSalary} style={{ width: "100%", marginBottom: "10px" }} />
     
               <label>Availability</label>
               <input type="text" name="availability" defaultValue={jobSeekerProfile?.availability} style={{ width: "100%", marginBottom: "10px" }} />
     
               <div style={{ textAlign: "right", marginTop: "10px" }}>
                 <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px" }}>
                   Cancel
                 </button>
                 <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "6px 12px", border: "none", borderRadius: "4px" }}>
                   Save
                 </button>
               </div>
             </form>
           </div>
         </div>
       )}
     </nav>

      {/* Header Section */}
      <div
        className="container-xxl py-5 bg-dark page-header mb-5"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="container my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Job Details & Company Profile
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb text-uppercase">
              <li className="breadcrumb-item">
                <Link to="/" className="text-white">Home</Link>
              </li>
              <li className="breadcrumb-item">
                <Link to="/jobs" className="text-white">Jobs</Link>
              </li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Job Details
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container">
          <div className="row gy-5 gx-4">
            {/* Left Column - Job Details */}
            <div className="col-lg-8">
              {/* Company Header */}
              <div className="card shadow-sm mb-4">
                <div className="card-body">
                  <div className="d-flex align-items-center mb-4">
                    {/* <img
                      className="flex-shrink-0 img-fluid border rounded"
                      src={employer.logo || "https://via.placeholder.com/80x80?text=Logo"}
                      alt="Company Logo"
                      style={{ width: "80px", height: "80px", objectFit: "cover" }}
                    /> */}
                    <div className="text-start ps-4">
                      <h3 className="mb-2 text-primary">{employer.companyName}</h3>
                      <span className="text-muted me-3">
                        <i className="fa fa-map-marker-alt text-primary me-2"></i>
                        {employer.city}, {employer.state}, {employer.country}
                      </span>
                      <br />
                      <span className="text-muted me-3">
                        <i className="fa fa-industry text-primary me-2"></i>
                        {employer.industry}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Company Description */}
              <div className="card shadow-sm mb-4">
                <div className="card-header bg-light">
                  <h4 className="mb-0">About Company</h4>
                </div>
                <div className="card-body">
                  <p className="mb-3">
                    {employer.description || "No company description available."}
                  </p>
                  
                  <div className="row">
                    <div className="col-md-6">
                      <h5 className="text-primary mb-3">Company Details</h5>
                      <ul className="list-unstyled">
                        <li><i className="fa fa-building text-primary me-2"></i><strong>Company Size:</strong> {employer.companySize || "Not specified"}</li>
                        <li><i className="fa fa-globe text-primary me-2"></i><strong>Website:</strong> 
                          {employer.website ? (
                            <a href={employer.website} target="_blank" rel="noreferrer" className="text-decoration-none ms-2">
                              {employer.website}
                            </a>
                          ) : " Not provided"}
                        </li>
                        <li><i className="fa fa-linkedin text-primary me-2"></i><strong>LinkedIn:</strong> 
                          {employer.linkedin ? (
                            <a href={employer.linkedin} target="_blank" rel="noreferrer" className="text-decoration-none ms-2">
                              View Profile
                            </a>
                          ) : " Not provided"}
                        </li>
                      </ul>
                    </div>
                    <div className="col-md-6">
                      <h5 className="text-primary mb-3">Contact Information</h5>
                      <ul className="list-unstyled">
                        <li><i className="fa fa-envelope text-primary me-2"></i><strong>Email:</strong> {employer.email}</li>
                        <li><i className="fa fa-phone text-primary me-2"></i><strong>Phone:</strong> {employer.phone || "Not provided"}</li>
                        <li><i className="fa fa-map-marker-alt text-primary me-2"></i><strong>Address:</strong> {employer.address || "Not provided"}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Applicant Information */}
              {jobseeker && (
                <div className="card shadow-sm mb-4">
                  <div className="card-header bg-primary text-white">
                    <h4 className="mb-0">Applicant Profile</h4>
                  </div>
                  <div className="card-body">
                    <div className="row">
                      <div className="col-md-6">
                        <h5 className="text-primary mb-3">Personal Information</h5>
                        <ul className="list-unstyled">
                          <li><strong>Name:</strong> {jobseeker.userId?.firstName} {jobseeker.userId?.lastName}</li>
                          <li><strong>Email:</strong> {jobseeker.userId?.email}</li>
                          <li><strong>Phone:</strong> {jobseeker.phone || "Not provided"}</li>
                        </ul>
                      </div>
                      <div className="col-md-6">
                        <h5 className="text-primary mb-3">Professional Details</h5>
                        <ul className="list-unstyled">
                          <li><strong>Skills:</strong> {jobseeker.skills || "Not specified"}</li>
                          <li><strong>Experience:</strong> {jobseeker.experience || "Not specified"}</li>
                          <li><strong>Education:</strong> {jobseeker.education || "Not specified"}</li>
                        </ul>
                      </div>
                    </div>
                    
                    {jobseeker.bio && (
                      <div className="mt-3">
                        <h6 className="text-primary">Bio:</h6>
                        <p>{jobseeker.bio}</p>
                      </div>
                    )}

                    <div className="mt-3">
                      <h6 className="text-primary">Professional Links:</h6>
                      <div className="d-flex gap-3">
                        {jobseeker.linkedin && (
                          <a href={jobseeker.linkedin} target="_blank" rel="noreferrer" className="btn btn-outline-primary btn-sm">
                            <i className="fab fa-linkedin me-1"></i>LinkedIn
                          </a>
                        )}
                        {jobseeker.github && (
                          <a href={jobseeker.github} target="_blank" rel="noreferrer" className="btn btn-outline-dark btn-sm">
                            <i className="fab fa-github me-1"></i>GitHub
                          </a>
                        )}
                        {jobseeker.resume && (
                          <a href={jobseeker.resume} target="_blank" rel="noreferrer" className="btn btn-outline-success btn-sm">
                            <i className="fa fa-file-pdf me-1"></i>Resume
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - Quick Summary */}
            <div className="col-lg-4">
              <div className="bg-light rounded p-4 mb-4 wow slideInUp" data-wow-delay="0.1s">
                <h4 className="mb-4 text-primary">Company Summary</h4>
                <div className="list-group list-group-flush">
                  <div className="list-group-item d-flex justify-content-between align-items-center bg-transparent border-0 px-0">
                    <span><i className="fa fa-building text-primary me-2"></i>Company:</span>
                    <span className="fw-bold">{employer.companyName}</span>
                  </div>
                  <div className="list-group-item d-flex justify-content-between align-items-center bg-transparent border-0 px-0">
                    <span><i className="fa fa-industry text-primary me-2"></i>Industry:</span>
                    <span>{employer.industry || "Not specified"}</span>
                  </div>
                  <div className="list-group-item d-flex justify-content-between align-items-center bg-transparent border-0 px-0">
                    <span><i className="fa fa-users text-primary me-2"></i>Size:</span>
                    <span>{employer.companySize || "Not specified"}</span>
                  </div>
                  <div className="list-group-item d-flex justify-content-between align-items-center bg-transparent border-0 px-0">
                    <span><i className="fa fa-map-marker-alt text-primary me-2"></i>Location:</span>
                    <span>{employer.city}, {employer.country}</span>
                  </div>
                  <div className="list-group-item d-flex justify-content-between align-items-center bg-transparent border-0 px-0">
                    <span><i className="fa fa-envelope text-primary me-2"></i>Contact:</span>
                    <a href={`mailto:${employer.email}`} className="text-decoration-none">
                      {employer.email}
                    </a>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="bg-primary rounded p-4 text-white text-center">
                <h5 className="mb-3">Interested in this company?</h5>
                <div className="d-grid gap-2">
                  <button 
                    className="btn btn-light btn-lg"
                    onClick={() => setIsApplyModalOpen(true)}
                  >
                    <i className="fa fa-paper-plane me-2"></i>Apply Now
                  </button>
                  {/* <button className="btn btn-outline-light">
                    <i className="fa fa-bookmark me-2"></i>Save Company
                  </button> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {/* Job Application Modal */}
      {isApplyModalOpen && (
        <div style={{
          position: "fixed",
          top: 0, left: 0, width: "100%", height: "100%",
          background: "rgba(0,0,0,0.5)", display: "flex",
          justifyContent: "center", alignItems: "center", zIndex: 200
        }}>
          <div style={{
            background: "#fff", padding: "25px",
            borderRadius: "12px", width: "600px",
            maxHeight: "90vh", overflowY: "auto",
            boxShadow: "0 10px 30px rgba(0,0,0,0.3)"
          }}>
            <div style={{
              display: "flex", justifyContent: "space-between", 
              alignItems: "center", marginBottom: "20px",
              borderBottom: "2px solid #f0f0f0", paddingBottom: "15px"
            }}>
              <h4 style={{ margin: 0, color: "#00D9A0", fontSize: "24px" }}>
                📄 Apply For The Job
              </h4>
              <button 
                onClick={() => setIsApplyModalOpen(false)}
                style={{
                  background: "none", border: "none", 
                  fontSize: "24px", cursor: "pointer",
                  color: "#999", padding: "0"
                }}
              >
                ×
              </button>
            </div>

            <form onSubmit={handleApplicationSubmit}>
              <div style={{ display: "grid", gap: "15px" }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "15px" }}>
                  <div>
                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#333" }}>
                      Your Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={applicationData.name}
                      onChange={handleInputChange}
                      className="form-control"
                      placeholder="Enter your full name"
                      required
                      style={{ 
                        padding: "12px", border: "1px solid #ddd", 
                        borderRadius: "6px", fontSize: "14px"
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#333" }}>
                      Your Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={applicationData.email}
                      onChange={handleInputChange}
                      className="form-control"
                      placeholder="Enter your email address"
                      required
                      style={{ 
                        padding: "12px", border: "1px solid #ddd", 
                        borderRadius: "6px", fontSize: "14px"
                      }}
                    />
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "15px" }}>
                  <div>
                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#333" }}>
                      Portfolio Website
                    </label>
                    <input
                      type="url"
                      name="portfolio"
                      value={applicationData.portfolio}
                      onChange={handleInputChange}
                      className="form-control"
                      placeholder="https://your-portfolio.com"
                      style={{ 
                        padding: "12px", border: "1px solid #ddd", 
                        borderRadius: "6px", fontSize: "14px"
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#333" }}>
                      Upload Resume
                    </label>
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="form-control bg-white"
                      accept=".pdf,.doc,.docx"
                      style={{ 
                        padding: "8px", border: "1px solid #ddd", 
                        borderRadius: "6px", fontSize: "14px"
                      }}
                    />
                    <small style={{ color: "#666", fontSize: "12px" }}>
                      Accepted formats: PDF, DOC, DOCX
                    </small>
                  </div>
                </div>

                <div>
                  <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#333" }}>
                    Cover Letter *
                  </label>
                  <textarea 
                    name="coverLetter"
                    value={applicationData.coverLetter}
                    onChange={handleInputChange}
                    className="form-control" 
                    rows="6" 
                    placeholder="Write a compelling cover letter explaining why you're perfect for this role..."
                    required
                    style={{ 
                      padding: "12px", border: "1px solid #ddd", 
                      borderRadius: "6px", fontSize: "14px",
                      resize: "vertical"
                    }}
                  />
                </div>

                <div style={{ 
                  display: "flex", gap: "10px", 
                  justifyContent: "flex-end", marginTop: "20px",
                  borderTop: "1px solid #f0f0f0", paddingTop: "20px"
                }}>
                  <button 
                    type="button" 
                    onClick={() => setIsApplyModalOpen(false)}
                    style={{
                      padding: "12px 24px", background: "#6c757d", 
                      color: "#fff", border: "none", borderRadius: "6px", 
                      cursor: "pointer", fontSize: "14px", fontWeight: "bold"
                    }}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    style={{
                      padding: "12px 24px", background: "#00D9A0", 
                      color: "#fff", border: "none", borderRadius: "6px", 
                      cursor: "pointer", fontSize: "14px", fontWeight: "bold",
                      boxShadow: "0 2px 4px rgba(0,217,160,0.3)"
                    }}
                  >
                    📤 Submit Application
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {isChangePasswordOpen && (
        <div style={{
          position: "fixed",
          top: 0, left: 0, width: "100%", height: "100%",
          background: "rgba(0,0,0,0.5)", display: "flex",
          justifyContent: "center", alignItems: "center", zIndex: 200
        }}>
          <div style={{
            background: "#fff", padding: "20px",
            borderRadius: "8px", width: "400px"
          }}>
            <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>🔒 Change Password</h4>
            <form onSubmit={handleChangePassword}>
              <input
                type="password"
                placeholder="Old Password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
                required
              />
              <input
                type="password"
                placeholder="New Password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
                required
              />
              <button type="submit" style={{
                padding: "8px 12px",
                background: "#00D9A0", color: "#fff",
                border: "none", borderRadius: "4px", cursor: "pointer"
              }}>
                Save
              </button>
              <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
                padding: "8px 12px", marginLeft: "10px",
                background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
              }}>
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditOpen && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 200,
          }}
        >
          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "8px",
              width: "400px",
              maxHeight: "90vh",
              overflowY: "auto",
            }}
          >
            <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
              ✏️ Edit JobSeeker Profile
            </h4>

            <form onSubmit={handleProfileUpdate}>
              <label>Bio</label>
              <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px" }} />

              <label>Skills</label>
              <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px" }} />

              <label>Experience</label>
              <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px" }} />

              <label>Education</label>
              <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px" }} />

              <label>Phone</label>
              <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px" }} />

              <div style={{ textAlign: "right", marginTop: "10px" }}>
                <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px" }}>
                  Cancel
                </button>
                <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "6px 12px", border: "none", borderRadius: "4px" }}>
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div className="container py-5">
          <div className="row g-5">
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Company</h5>
              <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
              <Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
              <Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
            </div>
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Quick Links</h5>
              <Link className="btn btn-link text-white-50" to="/jobs">Find Jobs</Link>
              <Link className="btn btn-link text-white-50" to="/post-job">Post Job</Link>
              <Link className="btn btn-link text-white-50" to="/category">Categories</Link>
            </div>
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Contact</h5>
              <p className="mb-2"><i className="fa fa-map-marker-alt me-3"></i>123 Ahmedabad, India</p>
              <p className="mb-2"><i className="fa fa-phone-alt me-3"></i>+91 99021 23412</p>
              <p className="mb-2"><i className="fa fa-envelope me-3"></i>jobentry@email.com</p>
            </div>
            <div className="col-lg-3 col-md-6">
              <h5 className="text-white mb-4">Follow Us</h5>
              <div className="d-flex pt-2">
                <a className="btn btn-outline-light btn-social" href="#"><i className="fab fa-twitter"></i></a>
                <a className="btn btn-outline-light btn-social" href="#"><i className="fab fa-facebook-f"></i></a>
                <a className="btn btn-outline-light btn-social" href="#"><i className="fab fa-linkedin-in"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;