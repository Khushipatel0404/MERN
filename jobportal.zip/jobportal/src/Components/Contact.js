

import React, { useState, useEffect } from "react";
import carousel from "../img/carousel-1.jpg";
import carousel2 from "../img/carousel-2.jpg";
import About from "../img/about-1.jpg";
import About1 from "../img/about-2.jpg";
import About2 from "../img/about-3.jpg";
import About3 from "../img/about-4.jpg";
import com1 from "../img/com-logo-1.jpg";
import com2 from "../img/com-logo-2.jpg";
import com3 from "../img/com-logo-3.jpg";
import com4 from "../img/com-logo-4.jpg";
import com5 from "../img/com-logo-5.jpg";
import tersti1 from "../img/testimonial-1.jpg";
import tersti2 from "../img/testimonial-2.jpg";
import tersti3 from "../img/testimonial-3.jpg";
import tersti4 from "../img/testimonial-4.jpg";
import { Link, useNavigate } from "react-router-dom";
// CSS
import "../lib/animate/animate.min.css";
import "../lib/owlcarousel/assets/owl.carousel.min.css";
import "../css/bootstrap.min.css";
import "../css/style.css";

const Contact = () => {
    const [currentSlide, setCurrentSlide] = useState(0);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
const [jobSeekerProfile, setJobSeekerProfile] = useState(null);
// Add this in your component state section

const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
const [oldPassword, setOldPassword] = useState("");
const [newPassword, setNewPassword] = useState("");
  const [isSending, setIsSending] = useState(false);
  // Slider images
  const slides = [
    {
      image:
        "https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80",
      title: "Find The Perfect Job That You Deserved",
      description:
        "Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et kasd rebum sea elitr.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      title: "Find The Best Startup Job That Fit You",
      description:
        "Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et kasd rebum sea elitr.",
    },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  const [isEditOpen, setIsEditOpen] = useState(false);
  // Testimonials
  const testimonials = [
    {
      id: 1,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/men/32.jpg",
      name: "Client Name",
      profession: "Profession",
    },
    {
      id: 2,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/men/45.jpg",
      name: "Client Name",
      profession: "Profession",
    },
    {
      id: 3,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/women/65.jpg",
      name: "Client Name",
      profession: "Profession",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);


useEffect(() => {
  const storedUser = JSON.parse(localStorage.getItem("user"));
  if (storedUser) {
    setUser(storedUser);

    // Job Seeker profile fetch
    fetch(`http://localhost:5000/api/profile/jobseeker/${storedUser.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setJobSeekerProfile(data.profile);
      })
      .catch((err) => console.error("Profile fetch error:", err));
  }
}, []);
  // useEffect(() => {

    
  //   const interval = setInterval(() => {
  //     setActiveIndex((prev) => (prev + 1) % testimonials.length);
  //   }, 3000);
  //   return () => clearInterval(interval);
  // }, [testimonials.length]);

  useEffect(() => {
    // Auto testimonial slider
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 3000);

    // Check login user from localStorage
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }

    return () => clearInterval(interval);
  }, [testimonials.length]);

  // ✅ Logout handler
  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/");
  };
const handleEditSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const updatedData = Object.fromEntries(formData.entries());

    fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedData),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setJobSeekerProfile(data.profile);
          setIsEditOpen(false);
        }
      })
      .catch((err) => console.error(err));
  };
  const handleProfileUpdate = (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const updatedData = Object.fromEntries(formData.entries());

  fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updatedData),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        setJobSeekerProfile(data.profile);
        setIsEditOpen(false);
      }
    })
    .catch((err) => console.error(err));
};
 const handleContactSubmit = (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const subject = document.getElementById("subject").value.trim();
    const message = document.getElementById("message").value.trim();

    if (!name || !email || !message) {
      alert("Please fill Name, Email and Message.");
      return;
    }

    setIsSending(true);
    fetch("http://localhost:5000/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, subject, message }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          alert("✅ Message sent successfully!");
          e.target.reset();
        } else {
          alert("❌ " + (data.message || "Server error"));
        }
      })
      .catch((err) => {
        console.error("Contact submit error:", err);
        alert("❌ Error sending message: " + err.message || err);
      })
      .finally(() => setIsSending(false));
  };
const handleChangePassword = async (e) => {
  e.preventDefault();
  try {
    const res = await fetch("http://localhost:5000/api/change-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: user.id,  
        oldPassword,
        newPassword,
      }),
    });

    const data = await res.json();
    if (data.success) {
      alert("✅ Password updated successfully");
      setIsChangePasswordOpen(false);
    } else {
      alert("❌ " + data.message);
    }
  } catch (err) {
    console.error("Change Password Error:", err);
    alert("❌ Error updating password");
  }
};


  return (
    <div>
      {/* <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <Link to="/" className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
          <h1 className="m-0 text-primary">JobEntry</h1>
        </Link>
        <button
          type="button"
          className="navbar-toggler me-4"
          data-bs-toggle="collapse"
          data-bs-target="#navbarCollapse"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarCollapse">
          <div className="navbar-nav ms-auto p-4 p-lg-0">
            <Link to="/" className="nav-item nav-link">
              Home
            </Link>
            <Link to="/about" className="nav-item nav-link">
              About
            </Link>
            <div className="nav-item dropdown">
              <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                Jobs
              </a>
              <div className="dropdown-menu rounded-0 m-0">
                <Link to="/jobs" className="dropdown-item">
                  Job List
                </Link>
                <Link to="/jobdetails" className="dropdown-item">
                  Job Detail
                </Link>
              </div>
            </div>
            <div className="nav-item dropdown">
              <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                Pages
              </a>
              <div className="dropdown-menu rounded-0 m-0">
                <Link to="/category" className="dropdown-item">
                  Job Category
                </Link>
                <Link to="/testimonial" className="dropdown-item">
                  Testimonial
                </Link>
                <a href="#" className="dropdown-item">
                  404
                </a>
              </div>
            </div>
            <Link to="/contact" className="nav-item nav-link active">
              Contact
            </Link>
          </div>
          <a href="#" className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block">
            Post A Job<i className="fa fa-arrow-right ms-3"></i>
          </a>
        </div>
      </nav> */}

<nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
  <Link
    to="/"
    className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5"
  >
    <h1 className="m-0 text-primary">JobEntry</h1>
  </Link>

  <button
    type="button"
    className="navbar-toggler me-4"
    data-bs-toggle="collapse"
    data-bs-target="#navbarCollapse"
  >
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse" id="navbarCollapse">
    <div className="navbar-nav ms-auto p-4 p-lg-0">
      {user && (
        <span className="nav-item nav-link text-primary fw-bold me-2">
          Welcome, {user.firstName || user.name}
        </span>
      )}

      <Link to="/" className="nav-item nav-link">Home</Link>
      <Link to="/about" className="nav-item nav-link">About</Link>

      <div className="nav-item dropdown">
        <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          Jobs
        </a>
        <div className="dropdown-menu rounded-0 m-0">
          <Link to="/jobs" className="dropdown-item">Job List</Link>
          <Link to="/jobdetails" className="dropdown-item">Job Detail</Link>
          {user && (
  <Link to="/user/applications" className="nav-item nav-link">
    My Applications
  </Link>
)}
        </div>
      </div>


      <div className="nav-item dropdown">
        <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          Pages
        </a>
        <div className="dropdown-menu rounded-0 m-0">
          <Link to="/category" className="dropdown-item">Job Category</Link>
          <Link to="/testimonial" className="dropdown-item">Testimonial</Link>
          <Link to="/404" className="dropdown-item">404</Link>
        </div>
      </div>

      <Link to="/contact" className="nav-item nav-link">Contact</Link>

      {/* Profile / Login */}
      {user ? (
        <div className="nav-item dropdown" style={{ position: "relative" }}>
          <a
            href="#"
            className="nav-link dropdown-toggle d-flex align-items-center"
            onClick={(e) => {
              e.preventDefault();
              setIsProfileOpen(!isProfileOpen);
            }}
          >
            {user.avatar ? (
  <img
    src={user.avatar}
    alt="profile"
    style={{
      width: "35px",
      height: "35px",
      borderRadius: "50%",
      marginRight: "8px",
      cursor: "pointer",
    }}
  />
) : (
  <div
    style={{
      width: "35px",
      height: "35px",
      borderRadius: "50%",
      background: "#ddd",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginRight: "8px",
      cursor: "pointer",
      fontSize: "16px",
      fontWeight: "bold",
      color: "#555",
    }}
  >
    👤
  </div>
)}

          </a>

{isProfileOpen && (
  <div
    style={{
      position: "absolute",
      top: "50px",
      right: 0,
      background: "#fff",
      boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
      borderRadius: "10px",
      minWidth: "300px",
      zIndex: 100,
      overflow: "hidden",
      fontFamily: "Segoe UI, sans-serif",
    }}
  >
   
    <div
      style={{
        padding: "15px",
        borderBottom: "1px solid #eee",
        background: "#f9f9f9",
      }}
    >
      <strong style={{ fontSize: "16px", color: "#333" }}>
        {user.firstName} {user.lastName}
      </strong>
      <div style={{ fontSize: "13px", color: "#777" }}>
        {user.email}
      </div>
    </div>

    {jobSeekerProfile ? (
      <div style={{ padding: "12px 16px", fontSize: "14px", color: "#444" }}>
        {jobSeekerProfile.bio && <p>📝 <strong>Bio:</strong> {jobSeekerProfile.bio}</p>}
        {jobSeekerProfile.skills && <p>🛠️ <strong>Skills:</strong> {jobSeekerProfile.skills}</p>}
        {jobSeekerProfile.experience && <p>💼 <strong>Experience:</strong> {jobSeekerProfile.experience}</p>}
        {jobSeekerProfile.education && <p>🎓 <strong>Education:</strong> {jobSeekerProfile.education}</p>}
        {jobSeekerProfile.phone && <p>📞 <strong>Phone:</strong> {jobSeekerProfile.phone}</p>}
        {jobSeekerProfile.location && (
          <p>🌍 <strong>Location:</strong> {jobSeekerProfile.location.city}, {jobSeekerProfile.location.state}, {jobSeekerProfile.location.country}</p>
        )}
        {jobSeekerProfile.linkedin && (
          <p>🔗 <a href={jobSeekerProfile.linkedin} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>LinkedIn</a></p>
        )}
        {jobSeekerProfile.github && (
          <p>💻 <a href={jobSeekerProfile.github} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>GitHub</a></p>
        )}
        {jobSeekerProfile.resume && (
          <p>📄 <a href={jobSeekerProfile.resume} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>View Resume</a></p>
        )}
        {jobSeekerProfile.expectedSalary && <p>💰 {jobSeekerProfile.expectedSalary}</p>}
        {jobSeekerProfile.availability && <p>⏳ {jobSeekerProfile.availability}</p>}
      </div>
    ) : (
      <div style={{ padding: "12px 16px", color: "#888" }}>
        ⚠️ No profile found
      </div>
    )}

   
    <button
      onClick={() => setIsEditOpen(true)}
      style={{
        width: "100%",
        background: "none",
        border: "none",
        color: "#3498db",
        padding: "12px 16px",
        textAlign: "left",
        cursor: "pointer",
        fontWeight: "bold",
        borderTop: "1px solid #eee",
      }}
    >
      ✏️ Edit Profile
    </button>


    <button
      onClick={() => setIsChangePasswordOpen(true)}
      style={{
        width: "100%",
        background: "none",
        border: "none",
        color: "#f39c12",
        padding: "12px 16px",
        textAlign: "left",
        cursor: "pointer",
        fontWeight: "bold",
        borderTop: "1px solid #eee",
      }}
    >
      🔑 Change Password
    </button>

    <button
      onClick={handleLogout}
      style={{
        width: "100%",
        background: "none",
        border: "none",
        color: "#e74c3c",
        padding: "12px 16px",
        textAlign: "left",
        cursor: "pointer",
        fontWeight: "bold",
        borderTop: "1px solid #eee",
      }}
    >
      🚪 Logout
    </button>
  </div>
)}

        </div>
      ) : (
        <Link to="/signin" className="nav-item nav-link">Login</Link>
      )}
    </div>

    <Link
      to="/Category"
      className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"
      style={{ backgroundColor: "#00D9A0", borderColor: "#00D9A0" }}
    >
      Post A Job <i className="fa fa-arrow-right ms-3"></i>
    </Link>
  </div>
{/* Change Password Modal */}
{isChangePasswordOpen && (
  <div style={{
    position: "fixed",
    top: 0, left: 0, width: "100%", height: "100%",
    background: "rgba(0,0,0,0.5)", display: "flex",
    justifyContent: "center", alignItems: "center", zIndex: 200
  }}>
    <div style={{
      background: "#fff", padding: "20px",
      borderRadius: "8px", width: "400px"
    }}>
      <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>🔒 Change Password</h4>
      <form onSubmit={handleChangePassword}>
        <input
          type="password"
          placeholder="Old Password"
          value={oldPassword}
          onChange={(e) => setOldPassword(e.target.value)}
          style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
          required
        />
        <input
          type="password"
          placeholder="New Password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
          required
        />
        <button type="submit" style={{
          padding: "8px 12px",
          background: "#00D9A0", color: "#fff",
          border: "none", borderRadius: "4px", cursor: "pointer"
        }}>
          Save
        </button>
        <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
          padding: "8px 12px", marginLeft: "10px",
          background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
        }}>
          Cancel
        </button>
      </form>
    </div>
  </div>
)}


  {/* Edit Profile Modal with form */}
  {isEditOpen && (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        background: "rgba(0,0,0,0.5)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 200,
      }}
    >
      <div
        style={{
          background: "#fff",
          padding: "20px",
          borderRadius: "8px",
          width: "400px",
          maxHeight: "90vh",
          overflowY: "auto",
        }}
      >
        <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
          ✏️ Edit JobSeeker Profile
        </h4>

        <form onSubmit={handleProfileUpdate}>
          <label>Bio</label>
          <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Skills</label>
          <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Experience</label>
          <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Education</label>
          <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Phone</label>
          <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px" }} />

          <label>LinkedIn</label>
          <input type="text" name="linkedin" defaultValue={jobSeekerProfile?.linkedin} style={{ width: "100%", marginBottom: "10px" }} />

          <label>GitHub</label>
          <input type="text" name="github" defaultValue={jobSeekerProfile?.github} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Resume</label>
          <input type="text" name="resume" defaultValue={jobSeekerProfile?.resume} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Expected Salary</label>
          <input type="text" name="expectedSalary" defaultValue={jobSeekerProfile?.expectedSalary} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Availability</label>
          <input type="text" name="availability" defaultValue={jobSeekerProfile?.availability} style={{ width: "100%", marginBottom: "10px" }} />

          <div style={{ textAlign: "right", marginTop: "10px" }}>
            <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px" }}>
              Cancel
            </button>
            <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "6px 12px", border: "none", borderRadius: "4px" }}>
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  )}
</nav>

      <div
        className="container-xxl py-5 bg-dark page-header mb-5"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div className="container my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">Contact</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb text-uppercase">
              <li className="breadcrumb-item">
                <Link to="/">Home</Link>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Contact
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="container-xxl py-5">
        <div className="container">
          <h1 className="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
            Contact For Any Query
          </h1>
          <div className="row g-4">
            <div className="col-12">
              <div className="row gy-4">
                <div className="col-md-4 wow fadeIn" data-wow-delay="0.1s">
                  <div className="d-flex align-items-center bg-light rounded p-4">
                    <div
                      className="bg-white border rounded d-flex flex-shrink-0 align-items-center justify-content-center me-3"
                      style={{ width: "45px", height: "45px" }}
                    >
                      <i className="fa fa-map-marker-alt text-primary"></i>
                    </div>
                    <span>123,Ahemdabad </span>
                  </div>
                </div>
                <div className="col-md-4 wow fadeIn" data-wow-delay="0.3s">
                  <div className="d-flex align-items-center bg-light rounded p-4">
                    <div
                      className="bg-white border rounded d-flex flex-shrink-0 align-items-center justify-content-center me-3"
                      style={{ width: "45px", height: "45px" }}
                    >
                      <i className="fa fa-envelope-open text-primary"></i>
                    </div>
                    <span>jobentry@email.com</span>
                  </div>
                </div>
                <div className="col-md-4 wow fadeIn" data-wow-delay="0.5s">
                  <div className="d-flex align-items-center bg-light rounded p-4">
                    <div
                      className="bg-white border rounded d-flex flex-shrink-0 align-items-center justify-content-center me-3"
                      style={{ width: "45px", height: "45px" }}
                    >
                      <i className="fa fa-phone-alt text-primary"></i>
                    </div>
                    <span>+91 99021 23412</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 wow fadeInUp" data-wow-delay="0.1s">
              <iframe
                className="position-relative rounded w-100 h-100"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3001156.4288297426!2d-78.01371936852176!3d42.72876761954724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew%20York%2C%20USA!5e0!3m2!1sen!2sbd!4v1603794290143!5m2!1sen!2sbd"
                frameBorder="0"
                style={{ minHeight: "400px", border: 0 }}
                allowFullScreen=""
                aria-hidden="false"
                tabIndex="0"
                title="Google Map"
              ></iframe>
            </div>
            <div className="col-md-6">
              <div className="wow fadeInUp" data-wow-delay="0.5s">
                <p className="mb-4">
                  The contact form is currently inactive. Get a functional and working contact form with Ajax & PHP in a few minutes. Just copy and paste the files, add a little code and you're done.{" "}
                  <a href="https://htmlcodex.com/contact-form">Download Now</a>.
                </p>
                {/* <form>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <div className="form-floating">
                        <input
                          type="text"
                          className="form-control"
                          id="name"
                          placeholder="Your Name"
                        />
                        <label htmlFor="name">Your Name</label>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-floating">
                        <input
                          type="email"
                          className="form-control"
                          id="email"
                          placeholder="Your Email"
                        />
                        <label htmlFor="email">Your Email</label>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-floating">
                        <input
                          type="text"
                          className="form-control"
                          id="subject"
                          placeholder="Subject"
                        />
                        <label htmlFor="subject">Subject</label>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-floating">
                        <textarea
                          className="form-control"
                          placeholder="Leave a message here"
                          id="message"
                          style={{ height: "150px" }}
                        ></textarea>
                        <label htmlFor="message">Message</label>
                      </div>
                    </div>
                    <div className="col-12">
                      <button className="btn btn-primary w-100 py-3" type="submit">
                        Send Message
                      </button>
                    </div>
                  </div>
                </form> */}
                {/* <form
  onSubmit={(e) => {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const subject = document.getElementById("subject").value;
    const message = document.getElementById("message").value;

    fetch("http://localhost:5000/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, subject, message }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          alert("✅ Message sent successfully!");
          e.target.reset(); // clear form
        } else {
          alert("❌ " + data.message);
        }
      })
      .catch((err) => alert("❌ Error sending message: " + err));
  }}
>
  <div className="row g-3">
    <div className="col-md-6">
      <div className="form-floating">
        <input type="text" className="form-control" id="name" placeholder="Your Name" required />
        <label htmlFor="name">Your Name</label>
      </div>
    </div>
    <div className="col-md-6">
      <div className="form-floating">
        <input type="email" className="form-control" id="email" placeholder="Your Email" required />
        <label htmlFor="email">Your Email</label>
      </div>
    </div>
    <div className="col-12">
      <div className="form-floating">
        <input type="text" className="form-control" id="subject" placeholder="Subject" required />
        <label htmlFor="subject">Subject</label>
      </div>
    </div>
    <div className="col-12">
      <div className="form-floating">
        <textarea className="form-control" placeholder="Leave a message here" id="message" style={{ height: "150px" }} required></textarea>
        <label htmlFor="message">Message</label>
      </div>
    </div>
    <div className="col-12">
      <button className="btn btn-primary w-100 py-3" type="submit">Send Message</button>
    </div>
  </div>
</form> */}
 <form onSubmit={handleContactSubmit}>
                <div className="row g-3">
                  <div className="col-md-6">
                    <div className="form-floating">
                      <input type="text" className="form-control" id="name" placeholder="Your Name" required />
                      <label htmlFor="name">Your Name</label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-floating">
                      <input type="email" className="form-control" id="email" placeholder="Your Email" required />
                      <label htmlFor="email">Your Email</label>
                    </div>
                  </div>
                  <div className="col-12">
                    <div className="form-floating">
                      <input type="text" className="form-control" id="subject" placeholder="Subject" />
                      <label htmlFor="subject">Subject</label>
                    </div>
                  </div>
                  <div className="col-12">
                    <div className="form-floating">
                      <textarea className="form-control" placeholder="Leave a message here" id="message" style={{ height: "150px" }} required></textarea>
                      <label htmlFor="message">Message</label>
                    </div>
                  </div>
                  <div className="col-12">
                    <button className="btn btn-primary w-100 py-3" type="submit" disabled={isSending}>
                      {isSending ? "Sending..." : "Send Message"}
                    </button>
                  </div>
                </div>
              </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;