
import React, { useState, useEffect } from "react";

import com2 from "../img/com-logo-2.jpg";
// CSS
import "../lib/animate/animate.min.css";
import "../lib/owlcarousel/assets/owl.carousel.min.css";
import "../css/bootstrap.min.css";
import "../css/style.css";
import { Link, useNavigate } from "react-router-dom";
const About = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
const [jobSeekerProfile, setJobSeekerProfile] = useState(null);
// Add this in your component state section

const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
const [oldPassword, setOldPassword] = useState("");
const [newPassword, setNewPassword] = useState("");

  // Slider images
  const slides = [
    {
      image:
        "https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80",
      title: "Find The Perfect Job That You Deserved",
      description:
        "Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et kasd rebum sea elitr.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      title: "Find The Best Startup Job That Fit You",
      description:
        "Vero elitr justo clita lorem. Ipsum dolor at sed stet sit diam no. Kasd rebum ipsum et diam justo clita et kasd rebum sea elitr.",
    },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  const [isEditOpen, setIsEditOpen] = useState(false);
  // Testimonials
  const testimonials = [
    {
      id: 1,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/men/32.jpg",
      name: "Client Name",
      profession: "Profession",
    },
    {
      id: 2,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/men/45.jpg",
      name: "Client Name",
      profession: "Profession",
    },
    {
      id: 3,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/women/65.jpg",
      name: "Client Name",
      profession: "Profession",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);


useEffect(() => {
  const storedUser = JSON.parse(localStorage.getItem("user"));
  if (storedUser) {
    setUser(storedUser);

    // Job Seeker profile fetch
    fetch(`http://localhost:5000/api/profile/jobseeker/${storedUser.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setJobSeekerProfile(data.profile);
      })
      .catch((err) => console.error("Profile fetch error:", err));
  }
}, []);
   useEffect(() => {
      // Auto testimonial slider
      const interval = setInterval(() => {
        setActiveIndex((prev) => (prev + 1) % testimonials.length);
      }, 3000);
  
      // Check login user from localStorage
      const storedUser = localStorage.getItem("user");
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
  
      return () => clearInterval(interval);
    }, [testimonials.length]);
  
    // ✅ Logout handler
    const handleLogout = () => {
      localStorage.removeItem("user");
      setUser(null);
      navigate("/");
    };
  const handleEditSubmit = (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const updatedData = Object.fromEntries(formData.entries());
  
      fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedData),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            setJobSeekerProfile(data.profile);
            setIsEditOpen(false);
          }
        })
        .catch((err) => console.error(err));
    };
    const handleProfileUpdate = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const updatedData = Object.fromEntries(formData.entries());
  
    fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedData),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setJobSeekerProfile(data.profile);
          setIsEditOpen(false);
        }
      })
      .catch((err) => console.error(err));
  };
  const handleChangePassword = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,  
          oldPassword,
          newPassword,
        }),
      });
  
      const data = await res.json();
      if (data.success) {
        alert("✅ Password updated successfully");
        setIsChangePasswordOpen(false);
      } else {
        alert("❌ " + data.message);
      }
    } catch (err) {
      console.error("Change Password Error:", err);
      alert("❌ Error updating password");
    }
  };
  
  
  return (
    <div>
       {/* <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
            <a href="index.html" class="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
                <h1 class="m-0 text-primary">JobEntry</h1>
            </a>
            <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto p-4 p-lg-0">
                    <a href="index.html" class="nav-item nav-link">Home</a>
                    <a href="about.html" class="nav-item nav-link active">About</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a>
                        <div class="dropdown-menu rounded-0 m-0">
                            <a href="job-list.html" class="dropdown-item">Job List</a>
                            <a href="job-detail.html" class="dropdown-item">Job Detail</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu rounded-0 m-0">
                            <a href="category.html" class="dropdown-item">Job Category</a>
                            <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                            <a href="404.html" class="dropdown-item">404</a>
                        </div>
                    </div>
                    <a href="contact.html" class="nav-item nav-link">Contact</a>
                </div>
                <a href="" class="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block">Post A Job<i class="fa fa-arrow-right ms-3"></i></a>
            </div>
        </nav> */}
 <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
   <Link
     to="/"
     className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5"
   >
     <h1 className="m-0 text-primary">JobEntry</h1>
   </Link>
 
   <button
     type="button"
     className="navbar-toggler me-4"
     data-bs-toggle="collapse"
     data-bs-target="#navbarCollapse"
   >
     <span className="navbar-toggler-icon"></span>
   </button>
 
   <div className="collapse navbar-collapse" id="navbarCollapse">
     <div className="navbar-nav ms-auto p-4 p-lg-0">
       {user && (
         <span className="nav-item nav-link text-primary fw-bold me-2">
           Welcome, {user.firstName || user.name}
         </span>
       )}
 
       <Link to="/" className="nav-item nav-link">Home</Link>
       <Link to="/about" className="nav-item nav-link">About</Link>
 
       <div className="nav-item dropdown">
         <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
           Jobs
         </a>
         <div className="dropdown-menu rounded-0 m-0">
           <Link to="/jobs" className="dropdown-item">Job List</Link>
           <Link to="/jobdetails" className="dropdown-item">Job Detail</Link>
           {user && (
   <Link to="/user/applications" className="nav-item nav-link">
     My Applications
   </Link>
 )}
         </div>
       </div>
 
 
       <div className="nav-item dropdown">
         <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
           Pages
         </a>
         <div className="dropdown-menu rounded-0 m-0">
           <Link to="/category" className="dropdown-item">Job Category</Link>
           <Link to="/testimonial" className="dropdown-item">Testimonial</Link>
           <Link to="/404" className="dropdown-item">404</Link>
         </div>
       </div>
 
       <Link to="/contact" className="nav-item nav-link">Contact</Link>
 
       {/* Profile / Login */}
       {user ? (
         <div className="nav-item dropdown" style={{ position: "relative" }}>
           <a
             href="#"
             className="nav-link dropdown-toggle d-flex align-items-center"
             onClick={(e) => {
               e.preventDefault();
               setIsProfileOpen(!isProfileOpen);
             }}
           >
             {user.avatar ? (
   <img
     src={user.avatar}
     alt="profile"
     style={{
       width: "35px",
       height: "35px",
       borderRadius: "50%",
       marginRight: "8px",
       cursor: "pointer",
     }}
   />
 ) : (
   <div
     style={{
       width: "35px",
       height: "35px",
       borderRadius: "50%",
       background: "#ddd",
       display: "flex",
       alignItems: "center",
       justifyContent: "center",
       marginRight: "8px",
       cursor: "pointer",
       fontSize: "16px",
       fontWeight: "bold",
       color: "#555",
     }}
   >
     👤
   </div>
 )}
 
           </a>
 
 {isProfileOpen && (
   <div
     style={{
       position: "absolute",
       top: "50px",
       right: 0,
       background: "#fff",
       boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
       borderRadius: "10px",
       minWidth: "300px",
       zIndex: 100,
       overflow: "hidden",
       fontFamily: "Segoe UI, sans-serif",
     }}
   >
    
     <div
       style={{
         padding: "15px",
         borderBottom: "1px solid #eee",
         background: "#f9f9f9",
       }}
     >
       <strong style={{ fontSize: "16px", color: "#333" }}>
         {user.firstName} {user.lastName}
       </strong>
       <div style={{ fontSize: "13px", color: "#777" }}>
         {user.email}
       </div>
     </div>
 
     {jobSeekerProfile ? (
       <div style={{ padding: "12px 16px", fontSize: "14px", color: "#444" }}>
         {jobSeekerProfile.bio && <p>📝 <strong>Bio:</strong> {jobSeekerProfile.bio}</p>}
         {jobSeekerProfile.skills && <p>🛠️ <strong>Skills:</strong> {jobSeekerProfile.skills}</p>}
         {jobSeekerProfile.experience && <p>💼 <strong>Experience:</strong> {jobSeekerProfile.experience}</p>}
         {jobSeekerProfile.education && <p>🎓 <strong>Education:</strong> {jobSeekerProfile.education}</p>}
         {jobSeekerProfile.phone && <p>📞 <strong>Phone:</strong> {jobSeekerProfile.phone}</p>}
         {jobSeekerProfile.location && (
           <p>🌍 <strong>Location:</strong> {jobSeekerProfile.location.city}, {jobSeekerProfile.location.state}, {jobSeekerProfile.location.country}</p>
         )}
         {jobSeekerProfile.linkedin && (
           <p>🔗 <a href={jobSeekerProfile.linkedin} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>LinkedIn</a></p>
         )}
         {jobSeekerProfile.github && (
           <p>💻 <a href={jobSeekerProfile.github} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>GitHub</a></p>
         )}
         {jobSeekerProfile.resume && (
           <p>📄 <a href={jobSeekerProfile.resume} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>View Resume</a></p>
         )}
         {jobSeekerProfile.expectedSalary && <p>💰 {jobSeekerProfile.expectedSalary}</p>}
         {jobSeekerProfile.availability && <p>⏳ {jobSeekerProfile.availability}</p>}
       </div>
     ) : (
       <div style={{ padding: "12px 16px", color: "#888" }}>
         ⚠️ No profile found
       </div>
     )}
 
    
     <button
       onClick={() => setIsEditOpen(true)}
       style={{
         width: "100%",
         background: "none",
         border: "none",
         color: "#3498db",
         padding: "12px 16px",
         textAlign: "left",
         cursor: "pointer",
         fontWeight: "bold",
         borderTop: "1px solid #eee",
       }}
     >
       ✏️ Edit Profile
     </button>
 
 
     <button
       onClick={() => setIsChangePasswordOpen(true)}
       style={{
         width: "100%",
         background: "none",
         border: "none",
         color: "#f39c12",
         padding: "12px 16px",
         textAlign: "left",
         cursor: "pointer",
         fontWeight: "bold",
         borderTop: "1px solid #eee",
       }}
     >
       🔑 Change Password
     </button>
 
     <button
       onClick={handleLogout}
       style={{
         width: "100%",
         background: "none",
         border: "none",
         color: "#e74c3c",
         padding: "12px 16px",
         textAlign: "left",
         cursor: "pointer",
         fontWeight: "bold",
         borderTop: "1px solid #eee",
       }}
     >
       🚪 Logout
     </button>
   </div>
 )}
 
         </div>
       ) : (
         <Link to="/signin" className="nav-item nav-link">Login</Link>
       )}
     </div>
 
     <Link
       to="/Category"
       className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"
       style={{ backgroundColor: "#00D9A0", borderColor: "#00D9A0" }}
     >
       Post A Job <i className="fa fa-arrow-right ms-3"></i>
     </Link>
   </div>
 {/* Change Password Modal */}
 {isChangePasswordOpen && (
   <div style={{
     position: "fixed",
     top: 0, left: 0, width: "100%", height: "100%",
     background: "rgba(0,0,0,0.5)", display: "flex",
     justifyContent: "center", alignItems: "center", zIndex: 200
   }}>
     <div style={{
       background: "#fff", padding: "20px",
       borderRadius: "8px", width: "400px"
     }}>
       <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>🔒 Change Password</h4>
       <form onSubmit={handleChangePassword}>
         <input
           type="password"
           placeholder="Old Password"
           value={oldPassword}
           onChange={(e) => setOldPassword(e.target.value)}
           style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
           required
         />
         <input
           type="password"
           placeholder="New Password"
           value={newPassword}
           onChange={(e) => setNewPassword(e.target.value)}
           style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
           required
         />
         <button type="submit" style={{
           padding: "8px 12px",
           background: "#00D9A0", color: "#fff",
           border: "none", borderRadius: "4px", cursor: "pointer"
         }}>
           Save
         </button>
         <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
           padding: "8px 12px", marginLeft: "10px",
           background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
         }}>
           Cancel
         </button>
       </form>
     </div>
   </div>
 )}
 
 
   {/* Edit Profile Modal with form */}
   {isEditOpen && (
     <div
       style={{
         position: "fixed",
         top: 0,
         left: 0,
         width: "100%",
         height: "100%",
         background: "rgba(0,0,0,0.5)",
         display: "flex",
         justifyContent: "center",
         alignItems: "center",
         zIndex: 200,
       }}
     >
       <div
         style={{
           background: "#fff",
           padding: "20px",
           borderRadius: "8px",
           width: "400px",
           maxHeight: "90vh",
           overflowY: "auto",
         }}
       >
         <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
           ✏️ Edit JobSeeker Profile
         </h4>
 
         <form onSubmit={handleProfileUpdate}>
           <label>Bio</label>
           <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>Skills</label>
           <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>Experience</label>
           <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>Education</label>
           <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>Phone</label>
           <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>LinkedIn</label>
           <input type="text" name="linkedin" defaultValue={jobSeekerProfile?.linkedin} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>GitHub</label>
           <input type="text" name="github" defaultValue={jobSeekerProfile?.github} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>Resume</label>
           <input type="text" name="resume" defaultValue={jobSeekerProfile?.resume} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>Expected Salary</label>
           <input type="text" name="expectedSalary" defaultValue={jobSeekerProfile?.expectedSalary} style={{ width: "100%", marginBottom: "10px" }} />
 
           <label>Availability</label>
           <input type="text" name="availability" defaultValue={jobSeekerProfile?.availability} style={{ width: "100%", marginBottom: "10px" }} />
 
           <div style={{ textAlign: "right", marginTop: "10px" }}>
             <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px" }}>
               Cancel
             </button>
             <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "6px 12px", border: "none", borderRadius: "4px" }}>
               Save
             </button>
           </div>
         </form>
       </div>
     </div>
   )}
 </nav>


       {/* <div class="container-xxl py-5 bg-dark page-header mb-5">
            <div class="container my-5 pt-5 pb-4">
                <h1 class="display-3 text-white mb-3 animated slideInDown">About Us</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb text-uppercase">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                    </ol>
                </nav>
            </div>
        </div> */}

<div
  className="container-xxl py-5 bg-dark page-header mb-5"
  style={{
    backgroundImage:
      "linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
  }}
>
  <div className="container my-5 pt-5 pb-4">
    <h1 className="display-3 text-white mb-3 animated slideInDown">About Us</h1>
    <nav aria-label="breadcrumb">
      <ol className="breadcrumb text-uppercase">
        <li className="breadcrumb-item">
          <a href="#">Home</a>
        </li>
        <li className="breadcrumb-item">
          <a href="#">Pages</a>
        </li>
        <li className="breadcrumb-item text-white active" aria-current="page">
          About us
        </li>
      </ol>
    </nav>
  </div>
</div>

 <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="row g-0 about-bg rounded overflow-hidden">
                            <div className="col-6 text-start">
  <img className="img-fluid w-100" src={require("../img/about-1.jpg")} alt="about-1" />
</div>
<div className="col-6 text-start">
  <img className="img-fluid" src={require("../img/about-2.jpg")} alt="about-2" style={{ width: "85%", marginTop: "15%" }} />
</div>
<div className="col-6 text-end">
  <img className="img-fluid" src={require("../img/about-3.jpg")} alt="about-3" style={{ width: "85%" }} />
</div>
<div className="col-6 text-end">
  <img className="img-fluid w-100" src={require("../img/about-4.jpg")} alt="about-4" />
</div>
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h1 class="mb-4">We Help To Get The Best Job And Find A Talent</h1>
                        <p class="mb-4">Finding the right job or the right candidate doesn’t have to be stressful. At JobEntry, we bridge the gap between employers and job seekers by creating a platform where talent meets opportunity.</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Access thousands of verified job opportunities across industries</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Discover top talent that matches your business needs</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Build lasting connections for a successful future</p>
                        {/* <a class="btn btn-primary py-3 px-5 mt-3" href="">Read More</a> */}
                        <Link to="/category" className="btn btn-primary py-3 px-5 mt-3">
  Read More
</Link>
                    </div>
                </div>
            </div>
        </div>
        


          <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Company</h5>
                        <a class="btn btn-link text-white-50" href="">About Us</a>
                        <a class="btn btn-link text-white-50" href="">Contact Us</a>
                        <a class="btn btn-link text-white-50" href="">Our Services</a>
                        <a class="btn btn-link text-white-50" href="">Privacy Policy</a>
                        <a class="btn btn-link text-white-50" href="">Terms & Condition</a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Quick Links</h5>
                        <a class="btn btn-link text-white-50" href="">About Us</a>
                        <a class="btn btn-link text-white-50" href="">Contact Us</a>
                        <a class="btn btn-link text-white-50" href="">Our Services</a>
                        <a class="btn btn-link text-white-50" href="">Privacy Policy</a>
                        <a class="btn btn-link text-white-50" href="">Terms & Condition</a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Contact</h5>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>123 Street, New York, USA</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+012 345 67890</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@example.com</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Newsletter</h5>
                        <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
                        {/* <div class="position-relative mx-auto" style="max-width: 400px;"> */}
                        <div className="position-relative mx-auto" style={{ maxWidth: "400px" }}>
                          <input
  className="form-control bg-transparent w-100 py-3 ps-4 pe-5"
  type="text"
  placeholder="Your email"
/>

                            {/* <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email"> */}
                            <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="#">Your Site Name</a>, All Right Reserved. 
							Designed By <a class="border-bottom" href="https://htmlcodex.com">HTML Codex</a>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
      </div>
      );
};

export default About;