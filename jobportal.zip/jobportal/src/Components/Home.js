import React, { useState, useEffect } from "react";
import carousel from "../img/carousel-1.jpg";
import carousel2 from "../img/carousel-2.jpg";
import About from "../img/about-1.jpg";
import About1 from "../img/about-2.jpg";
import About2 from "../img/about-3.jpg";
import About3 from "../img/about-4.jpg";
import com1 from "../img/com-logo-1.jpg";
import com2 from "../img/com-logo-2.jpg";
import com3 from "../img/com-logo-3.jpg";
import com4 from "../img/com-logo-4.jpg";
import com5 from "../img/com-logo-5.jpg";
import tersti1 from "../img/testimonial-1.jpg";
import tersti2 from "../img/testimonial-2.jpg";
import tersti3 from "../img/testimonial-3.jpg";
import tersti4 from "../img/testimonial-4.jpg";
import { Link, useNavigate } from "react-router-dom";
// CSS
import "../lib/animate/animate.min.css";
import "../lib/owlcarousel/assets/owl.carousel.min.css";
import "../css/bootstrap.min.css";
import "../css/style.css";



// import { Link } from "react-router-dom";
import Contact from './Contact';


const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
const [jobSeekerProfile, setJobSeekerProfile] = useState(null);


const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
const [oldPassword, setOldPassword] = useState("");
const [newPassword, setNewPassword] = useState("");


  const slides = [
    {
      image:
        "https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80",
      title: "Find The Perfect Job That You Deserved",
      description:
        "Discover your dream startup job and kickstart the career that truly fits you.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      title: "Find The Best Startup Job That Fit You",
      description:
        "Discover your dream startup job and kickstart the career that truly fits you..",
    },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  const [isEditOpen, setIsEditOpen] = useState(false);
  // Testimonials
  const testimonials = [
    {
      id: 1,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/men/32.jpg",
      name: "Client Name",
      profession: "Profession",
    },
    {
      id: 2,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/men/45.jpg",
      name: "Client Name",
      profession: "Profession",
    },
    {
      id: 3,
      text: "Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam",
      img: "https://randomuser.me/api/portraits/women/65.jpg",
      name: "Client Name",
      profession: "Profession",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);


useEffect(() => {
  const storedUser = JSON.parse(localStorage.getItem("user"));
  if (storedUser) {
    setUser(storedUser);

    
    fetch(`http://localhost:5000/api/profile/jobseeker/${storedUser.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setJobSeekerProfile(data.profile);
      })
      .catch((err) => console.error("Profile fetch error:", err));
  }
}, []);
  // useEffect(() => {

    
  //   const interval = setInterval(() => {
  //     setActiveIndex((prev) => (prev + 1) % testimonials.length);
  //   }, 3000);
  //   return () => clearInterval(interval);
  // }, [testimonials.length]);

  useEffect(() => {
    
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 3000);

   
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }

    return () => clearInterval(interval);
  }, [testimonials.length]);

  // ✅ Logout handler
  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/");
  };
const handleEditSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const updatedData = Object.fromEntries(formData.entries());

    fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedData),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setJobSeekerProfile(data.profile);
          setIsEditOpen(false);
        }
      })
      .catch((err) => console.error(err));
  };
  const handleProfileUpdate = (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const updatedData = Object.fromEntries(formData.entries());

  fetch(`http://localhost:5000/api/profile/jobseeker/${user.id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updatedData),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        setJobSeekerProfile(data.profile);
        setIsEditOpen(false);
      }
    })
    .catch((err) => console.error(err));
};
const handleChangePassword = async (e) => {
  e.preventDefault();
  try {
    const res = await fetch("http://localhost:5000/api/change-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: user.id,   
        oldPassword,
        newPassword,
      }),
    });

    const data = await res.json();
    if (data.success) {
      alert("✅ Password updated successfully");
      setIsChangePasswordOpen(false);
    } else {
      alert("❌ " + data.message);
    }
  } catch (err) {
    console.error("Change Password Error:", err);
    alert("❌ Error updating password");
  }
};



  return (
    <div>
    

{/* <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
  <Link to="/" className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
    <h1 className="m-0 text-primary">JobEntry</h1>
  </Link>
  <button
    type="button"
    className="navbar-toggler me-4"
    data-bs-toggle="collapse"
    data-bs-target="#navbarCollapse"
  >
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarCollapse">
    <div className="navbar-nav ms-auto p-4 p-lg-0">
      <Link to="/" className="nav-item nav-link">Home</Link>
      <Link to="/about" className="nav-item nav-link">About</Link>
      <div className="nav-item dropdown">
        <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          Jobs
        </a>
        <div className="dropdown-menu rounded-0 m-0">
          <Link to="/jobs" className="dropdown-item">Job List</Link>
          <Link to="/jobdetails" className="dropdown-item">Job Detail</Link>
        </div>
      </div>
      <div className="nav-item dropdown">
        <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          Pages
        </a>
        <div className="dropdown-menu rounded-0 m-0">
          <Link to="/category" className="dropdown-item">Job Category</Link>
          <Link to="/testimonial" className="dropdown-item">Testimonial</Link>
          <a href="#" className="dropdown-item">404</a>
        </div>
      </div>
      <Link to="/contact" className="nav-item nav-link">Contact</Link>
      <Link to="/signin" className="nav-item nav-link">Login</Link>
    </div>
    <Link to="/jobs" className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block">
      Post A Job<i className="fa fa-arrow-right ms-3"></i>
    </Link>
  </div>
</nav> */}
<nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
  <Link
    to="/"
    className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5"
  >
    <h1 className="m-0 text-primary">JobEntry</h1>
  </Link>

  <button
    type="button"
    className="navbar-toggler me-4"
    data-bs-toggle="collapse"
    data-bs-target="#navbarCollapse"
  >
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse" id="navbarCollapse">
    <div className="navbar-nav ms-auto p-4 p-lg-0">
      {user && (
        <span className="nav-item nav-link text-primary fw-bold me-2">
          Welcome, {user.firstName || user.name}
        </span>
      )}

      <Link to="/" className="nav-item nav-link">Home</Link>
      <Link to="/about" className="nav-item nav-link">About</Link>

      <div className="nav-item dropdown">
        <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          Jobs
        </a>
        <div className="dropdown-menu rounded-0 m-0">
          <Link to="/jobs" className="dropdown-item">Job List</Link>
          <Link to="/jobdetails" className="dropdown-item">Job Detail</Link>
          {user && (
  <Link to="/user/applications" className="nav-item nav-link">
    My Applications
  </Link>
)}
        </div>
      </div>


      <div className="nav-item dropdown">
        <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          Pages
        </a>
        <div className="dropdown-menu rounded-0 m-0">
          <Link to="/category" className="dropdown-item">Job Category</Link>
          <Link to="/testimonial" className="dropdown-item">Testimonial</Link>
          <Link to="/404" className="dropdown-item">404</Link>
        </div>
      </div>

      <Link to="/contact" className="nav-item nav-link">Contact</Link>

      {/* Profile / Login */}
      {user ? (
        <div className="nav-item dropdown" style={{ position: "relative" }}>
          <a
            href="#"
            className="nav-link dropdown-toggle d-flex align-items-center"
            onClick={(e) => {
              e.preventDefault();
              setIsProfileOpen(!isProfileOpen);
            }}
          >
            {user.avatar ? (
  <img
    src={user.avatar}
    alt="profile"
    style={{
      width: "35px",
      height: "35px",
      borderRadius: "50%",
      marginRight: "8px",
      cursor: "pointer",
    }}
  />
) : (
  <div
    style={{
      width: "35px",
      height: "35px",
      borderRadius: "50%",
      background: "#ddd",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginRight: "8px",
      cursor: "pointer",
      fontSize: "16px",
      fontWeight: "bold",
      color: "#555",
    }}
  >
    👤
  </div>
)}

          </a>

{isProfileOpen && (
  <div
    style={{
      position: "absolute",
      top: "50px",
      right: 0,
      background: "#fff",
      boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
      borderRadius: "10px",
      minWidth: "300px",
      zIndex: 100,
      overflow: "hidden",
      fontFamily: "Segoe UI, sans-serif",
    }}
  >
   
    <div
      style={{
        padding: "15px",
        borderBottom: "1px solid #eee",
        background: "#f9f9f9",
      }}
    >
      <strong style={{ fontSize: "16px", color: "#333" }}>
        {user.firstName} {user.lastName}
      </strong>
      <div style={{ fontSize: "13px", color: "#777" }}>
        {user.email}
      </div>
    </div>

    {jobSeekerProfile ? (
      <div style={{ padding: "12px 16px", fontSize: "14px", color: "#444" }}>
        {jobSeekerProfile.bio && <p>📝 <strong>Bio:</strong> {jobSeekerProfile.bio}</p>}
        {jobSeekerProfile.skills && <p>🛠️ <strong>Skills:</strong> {jobSeekerProfile.skills}</p>}
        {jobSeekerProfile.experience && <p>💼 <strong>Experience:</strong> {jobSeekerProfile.experience}</p>}
        {jobSeekerProfile.education && <p>🎓 <strong>Education:</strong> {jobSeekerProfile.education}</p>}
        {jobSeekerProfile.phone && <p>📞 <strong>Phone:</strong> {jobSeekerProfile.phone}</p>}
        {jobSeekerProfile.location && (
          <p>🌍 <strong>Location:</strong> {jobSeekerProfile.location.city}, {jobSeekerProfile.location.state}, {jobSeekerProfile.location.country}</p>
        )}
        {jobSeekerProfile.linkedin && (
          <p>🔗 <a href={jobSeekerProfile.linkedin} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>LinkedIn</a></p>
        )}
        {jobSeekerProfile.github && (
          <p>💻 <a href={jobSeekerProfile.github} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>GitHub</a></p>
        )}
        {jobSeekerProfile.resume && (
          <p>📄 <a href={jobSeekerProfile.resume} target="_blank" rel="noreferrer" style={{ color: "#3498db" }}>View Resume</a></p>
        )}
        {jobSeekerProfile.expectedSalary && <p>💰 {jobSeekerProfile.expectedSalary}</p>}
        {jobSeekerProfile.availability && <p>⏳ {jobSeekerProfile.availability}</p>}
      </div>
    ) : (
      <div style={{ padding: "12px 16px", color: "#888" }}>
        ⚠️ No profile found
      </div>
    )}

   
    <button
      onClick={() => setIsEditOpen(true)}
      style={{
        width: "100%",
        background: "none",
        border: "none",
        color: "#3498db",
        padding: "12px 16px",
        textAlign: "left",
        cursor: "pointer",
        fontWeight: "bold",
        borderTop: "1px solid #eee",
      }}
    >
      ✏️ Edit Profile
    </button>


    <button
      onClick={() => setIsChangePasswordOpen(true)}
      style={{
        width: "100%",
        background: "none",
        border: "none",
        color: "#f39c12",
        padding: "12px 16px",
        textAlign: "left",
        cursor: "pointer",
        fontWeight: "bold",
        borderTop: "1px solid #eee",
      }}
    >
      🔑 Change Password
    </button>

    <button
      onClick={handleLogout}
      style={{
        width: "100%",
        background: "none",
        border: "none",
        color: "#e74c3c",
        padding: "12px 16px",
        textAlign: "left",
        cursor: "pointer",
        fontWeight: "bold",
        borderTop: "1px solid #eee",
      }}
    >
      🚪 Logout
    </button>
  </div>
)}

        </div>
      ) : (
        <Link to="/signin" className="nav-item nav-link">Login</Link>
      )}
    </div>

    <Link
      to="/Category"
      className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"
      style={{ backgroundColor: "#00D9A0", borderColor: "#00D9A0" }}
    >
      Post A Job <i className="fa fa-arrow-right ms-3"></i>
    </Link>
  </div>
{/* Change Password Modal */}
{isChangePasswordOpen && (
  <div style={{
    position: "fixed",
    top: 0, left: 0, width: "100%", height: "100%",
    background: "rgba(0,0,0,0.5)", display: "flex",
    justifyContent: "center", alignItems: "center", zIndex: 200
  }}>
    <div style={{
      background: "#fff", padding: "20px",
      borderRadius: "8px", width: "400px"
    }}>
      <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>🔒 Change Password</h4>
      <form onSubmit={handleChangePassword}>
        <input
          type="password"
          placeholder="Old Password"
          value={oldPassword}
          onChange={(e) => setOldPassword(e.target.value)}
          style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
          required
        />
        <input
          type="password"
          placeholder="New Password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
          required
        />
        <button type="submit" style={{
          padding: "8px 12px",
          background: "#00D9A0", color: "#fff",
          border: "none", borderRadius: "4px", cursor: "pointer"
        }}>
          Save
        </button>
        <button type="button" onClick={() => setIsChangePasswordOpen(false)} style={{
          padding: "8px 12px", marginLeft: "10px",
          background: "#ccc", border: "none", borderRadius: "4px", cursor: "pointer"
        }}>
          Cancel
        </button>
      </form>
    </div>
  </div>
)}


  {/* Edit Profile Modal with form */}
  {isEditOpen && (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        background: "rgba(0,0,0,0.5)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 200,
      }}
    >
      <div
        style={{
          background: "#fff",
          padding: "20px",
          borderRadius: "8px",
          width: "400px",
          maxHeight: "90vh",
          overflowY: "auto",
        }}
      >
        <h4 style={{ marginBottom: "15px", color: "#00D9A0" }}>
          ✏️ Edit JobSeeker Profile
        </h4>

        <form onSubmit={handleProfileUpdate}>
          <label>Bio</label>
          <input type="text" name="bio" defaultValue={jobSeekerProfile?.bio} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Skills</label>
          <input type="text" name="skills" defaultValue={jobSeekerProfile?.skills} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Experience</label>
          <input type="text" name="experience" defaultValue={jobSeekerProfile?.experience} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Education</label>
          <input type="text" name="education" defaultValue={jobSeekerProfile?.education} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Phone</label>
          <input type="text" name="phone" defaultValue={jobSeekerProfile?.phone} style={{ width: "100%", marginBottom: "10px" }} />

          <label>LinkedIn</label>
          <input type="text" name="linkedin" defaultValue={jobSeekerProfile?.linkedin} style={{ width: "100%", marginBottom: "10px" }} />

          <label>GitHub</label>
          <input type="text" name="github" defaultValue={jobSeekerProfile?.github} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Resume</label>
          <input type="text" name="resume" defaultValue={jobSeekerProfile?.resume} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Expected Salary</label>
          <input type="text" name="expectedSalary" defaultValue={jobSeekerProfile?.expectedSalary} style={{ width: "100%", marginBottom: "10px" }} />

          <label>Availability</label>
          <input type="text" name="availability" defaultValue={jobSeekerProfile?.availability} style={{ width: "100%", marginBottom: "10px" }} />

          <div style={{ textAlign: "right", marginTop: "10px" }}>
            <button type="button" onClick={() => setIsEditOpen(false)} style={{ marginRight: "10px" }}>
              Cancel
            </button>
            <button type="submit" style={{ background: "#00D9A0", color: "#fff", padding: "6px 12px", border: "none", borderRadius: "4px" }}>
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  )}
</nav>



        <div class="container-fluid p-0">
          <div>
      {/* Carousel Container */}
      <div style={{
        position: 'relative',
        width: '100%',
        height: '100vh',
        maxHeight: '800px',
        minHeight: '600px',
        overflow: 'hidden',
        boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
      }}>
        
        {/* Slides Container */}
        <div style={{
          display: 'flex',
          width: `${slides.length * 100}%`,
          height: '100%',
          transform: `translateX(-${currentSlide * (100 / slides.length)}%)`,
          transition: 'transform 0.6s ease-in-out'
        }}>
          
          {slides.map((slide, index) => (
            <div key={index} style={{
              position: 'relative',
              width: `${100 / slides.length}%`,
              height: '100%',
              flexShrink: 0,
              overflow: 'hidden'
            }}>
              
              {/* Background Image */}
              <img 
                src={slide.image} 
                alt={`Carousel ${index + 1}`} 
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  objectPosition: 'center 30%', 
                  display: 'block'
                }}
              />
              
              {/* Overlay */}
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                background: 'rgba(43, 57, 64, 0.5)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                
                {/* Content Container */}
                <div style={{
                  width: '100%',
                  maxWidth: '1200px',
                  padding: '0 20px'
                }}>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'flex-start'
                  }}>
                    <div style={{
                      width: '100%',
                      maxWidth: '70%',
                      color: 'white'
                    }}>
                      
                      {/* Title */}
                      <h1 style={{
                        fontSize: 'clamp(2rem, 5vw, 3.5rem)',
                        fontWeight: 'bold',
                        color: 'white',
                        marginBottom: '25px',
                        lineHeight: '1.2',
                        textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
                        animation: currentSlide === index ? 'slideInDown 1s ease-out' : 'none'
                      }}>
                        {slide.title}
                      </h1>
                      
                      {/* Description */}
                      <p style={{
                        fontSize: '1.25rem',
                        fontWeight: '400',
                        color: 'white',
                        marginBottom: '35px',
                        lineHeight: '1.7',
                        opacity: '0.95',
                        textShadow: '1px 1px 2px rgba(0,0,0,0.5)',
                        animation: currentSlide === index ? 'fadeInUp 1s ease-out 0.3s both' : 'none'
                      }}>
                        {slide.description}
                      </p>
                      
                      {/* Buttons */}
                      <div style={{
                        display: 'flex',
                        gap: '20px',
                        flexWrap: 'wrap',
                        animation: currentSlide === index ? 'fadeInUp 1s ease-out 0.6s both' : 'none'
                      }}>
                       
                        <a 
  href="/Category" 
  style={{
    backgroundColor: '#007bff',
    color: 'white',
    textDecoration: 'none',
    padding: '15px 30px',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '600',
    transition: 'all 0.3s ease',
    display: 'inline-block',
    boxShadow: '0 4px 15px rgba(0,123,255,0.3)'
  }}
  onMouseOver={(e) => {
    e.target.style.backgroundColor = '#0056b3';
    e.target.style.transform = 'translateY(-3px)';
    e.target.style.boxShadow = '0 8px 25px rgba(0,123,255,0.4)';
  }}
  onMouseOut={(e) => {
    e.target.style.backgroundColor = '#007bff';
    e.target.style.transform = 'translateY(0)';
    e.target.style.boxShadow = '0 4px 15px rgba(0,123,255,0.3)';
  }}
>
  Search A Job
</a>

                       
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Previous Arrow */}
        <button 
          onClick={prevSlide}
          style={{
            position: 'absolute',
            left: '25px',
            top: '50%',
            transform: 'translateY(-50%)',
            backgroundColor: 'rgba(255, 255, 255, 0.9)',
            border: 'none',
            borderRadius: '50%',
            width: '60px',
            height: '60px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#333',
            transition: 'all 0.3s ease',
            zIndex: 10,
            boxShadow: '0 6px 20px rgba(0,0,0,0.15)'
          }}
          onMouseOver={(e) => {
            e.target.style.backgroundColor = 'rgba(255, 255, 255, 1)';
            e.target.style.transform = 'translateY(-50%) scale(1.1)';
            e.target.style.boxShadow = '0 10px 30px rgba(0,0,0,0.25)';
          }}
          onMouseOut={(e) => {
            e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
            e.target.style.transform = 'translateY(-50%) scale(1)';
            e.target.style.boxShadow = '0 6px 20px rgba(0,0,0,0.15)';
          }}
        >
          ‹
        </button>

        {/* Next Arrow */}
        <button 
          onClick={nextSlide}
          style={{
            position: 'absolute',
            right: '25px',
            top: '50%',
            transform: 'translateY(-50%)',
            backgroundColor: 'rgba(255, 255, 255, 0.9)',
            border: 'none',
            borderRadius: '50%',
            width: '60px',
            height: '60px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#333',
            transition: 'all 0.3s ease',
            zIndex: 10,
            boxShadow: '0 6px 20px rgba(0,0,0,0.15)'
          }}
          onMouseOver={(e) => {
            e.target.style.backgroundColor = 'rgba(255, 255, 255, 1)';
            e.target.style.transform = 'translateY(-50%) scale(1.1)';
            e.target.style.boxShadow = '0 10px 30px rgba(0,0,0,0.25)';
          }}
          onMouseOut={(e) => {
            e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
            e.target.style.transform = 'translateY(-50%) scale(1)';
            e.target.style.boxShadow = '0 6px 20px rgba(0,0,0,0.15)';
          }}
        >
          ›
        </button>

        {/* Dots Indicator */}
        <div style={{
          position: 'absolute',
          bottom: '30px',
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          gap: '15px',
          zIndex: 10
        }}>
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              style={{
                width: currentSlide === index ? '40px' : '15px',
                height: '15px',
                borderRadius: '10px',
                border: 'none',
                backgroundColor: currentSlide === index ? '#007bff' : 'rgba(255, 255, 255, 0.6)',
                cursor: 'pointer',
                transition: 'all 0.4s ease',
                boxShadow: '0 3px 10px rgba(0,0,0,0.2)'
              }}
              onMouseOver={(e) => {
                if (currentSlide !== index) {
                  e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
                  e.target.style.transform = 'scale(1.2)';
                }
              }}
              onMouseOut={(e) => {
                if (currentSlide !== index) {
                  e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.6)';
                  e.target.style.transform = 'scale(1)';
                }
              }}
            />
          ))}
        </div>

        {/* Slide Counter */}
        <div style={{
          position: 'absolute',
          top: '30px',
          right: '30px',
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
          color: 'white',
          padding: '10px 20px',
          borderRadius: '25px',
          fontSize: '14px',
          fontWeight: '500',
          zIndex: 10
        }}>
          {currentSlide + 1} / {slides.length}
        </div>
      </div>

      {/* CSS Animations */}
      <style jsx>{`
        @keyframes slideInDown {
          from {
            opacity: 0;
            transform: translateY(-40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @media (max-width: 768px) {
          .carousel-container {
            height: 80vh !important;
            min-height: 500px !important;
          }
          
          .carousel-content {
            max-width: 90% !important;
            padding: 0 15px !important;
          }
          
          .carousel-title {
            font-size: 1.8rem !important;
          }
          
          .carousel-buttons {
            flex-direction: column !important;
            gap: 15px !important;
          }
          
          .carousel-arrow {
            width: 50px !important;
            height: 50px !important;
            font-size: 20px !important;
          }
        }

        @media (max-width: 480px) {
          .carousel-container {
            height: 70vh !important;
            min-height: 400px !important;
          }
          
          .carousel-arrow {
            left: 15px !important;
            right: 15px !important;
          }
        }
      `}</style>
    </div>
            
        

      
        </div>
        

       <hr/>



        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="row g-0 about-bg rounded overflow-hidden">
                            <div class="col-6 text-start">
                                <img src={About}  class="img-fluid w-100" />
                               
                            </div>
                            <div class="col-6 text-start">
                             <img 
  src={About1} 
  className="img-fluid" 
  style={{ width: "85%", marginTop: "15%" }} 
  alt="About" 
/>

                               
                            </div>
                            <div class="col-6 text-end">
                                <img src={About2}  class="img-fluid" style={{ width: "85%" }} />
                                
                            </div>
                            <div class="col-6 text-end">
                                <img src={About3}  class="img-fluid w-100" />
                             
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h1 class="mb-4">We Help To Get The Best Job And Find A Talent</h1>
                        <p class="mb-4">Finding the right job or the right candidate doesn’t have to be stressful. At JobEntry, we bridge the gap between employers and job seekers by creating a platform where talent meets opportunity.</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Access thousands of verified job opportunities across industries</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Discover top talent that matches your business needs</p>
                        <p><i class="fa fa-check text-primary me-3"></i>Build lasting connections for a successful future</p>
                        {/* <a class="btn btn-primary py-3 px-5 mt-3" href="">Read More</a> */}
                        <Link to="/category" className="btn btn-primary py-3 px-5 mt-3">
  Read More
</Link>
                    </div>
                </div>
            </div>
        </div>
           <div
      style={{
        maxWidth: "1200px",
        margin: "60px auto",
        padding: "20px",
        textAlign: "center",
      }}
    >
      <h1 style={{ marginBottom: "40px" }}>Our Clients Say!!!</h1>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "20px",
        }}
      >
        {testimonials.map((t, i) => {
          const isActive = i === activeIndex;

          return (
            <div
              key={t.id}
              style={{
                flex: "0 0 30%",
                minWidth: "300px",
                padding: "20px",
                borderRadius: "8px",
                background: isActive ? "#00b074" : "#f8f9fa",
                color: isActive ? "#fff" : "#000",
                transition: "all 0.5s ease",
              }}
            >
              <i
                className="fa fa-quote-left"
                style={{
                  fontSize: "24px",
                  marginBottom: "12px",
                  color: isActive ? "#fff" : "#00b074",
                }}
              ></i>
              <p style={{ marginBottom: "1rem" }}>{t.text}</p>
              <div style={{ display: "flex", alignItems: "center" }}>
                <img
                  src={t.img}
                  alt="client"
                  style={{
                    width: "50px",
                    height: "50px",
                    borderRadius: "50%",
                    flexShrink: 0,
                  }}
                />
                <div style={{ paddingLeft: "12px", textAlign: "left" }}>
                  <h5 style={{ margin: 0, color: isActive ? "#fff" : "#000" }}>
                    {t.name}
                  </h5>
                  <small style={{ color: isActive ? "#f0f0f0" : "#555" }}>
                    {t.profession}
                  </small>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Dots */}
      <div style={{ marginTop: "20px" }}>
        {testimonials.map((_, i) => (
          <span
            key={i}
            onClick={() => setActiveIndex(i)}
            style={{
              display: "inline-block",
              width: "10px",
              height: "10px",
              margin: "0 5px",
              borderRadius: "50%",
              background: i === activeIndex ? "#00b074" : "#ccc",
              cursor: "pointer",
            }}
          ></span>
        ))}
      </div>
    </div>
<hr/>        
        <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Company</h5>
                        {/* <a class="btn btn-link text-white-50" href="">About Us</a>
                        <a class="btn btn-link text-white-50" href="">Contact Us</a>
                        <a class="btn btn-link text-white-50" href="">Our Services</a>
                        <a class="btn btn-link text-white-50" href="">Privacy Policy</a>
                        <a class="btn btn-link text-white-50" href="">Terms & Condition</a> */}
                        <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
<Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
<Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
<Link className="btn btn-link text-white-50" to="/privacy-policy">Privacy Policy</Link>
<Link className="btn btn-link text-white-50" to="/Testimonial">Terms & Condition</Link>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Quick Links</h5>
                        <Link className="btn btn-link text-white-50" to="/about">About Us</Link>
<Link className="btn btn-link text-white-50" to="/contact">Contact Us</Link>
<Link className="btn btn-link text-white-50" to="/jobs">Our Services</Link>
<Link className="btn btn-link text-white-50" to="/privacy-policy">Privacy Policy</Link>
<Link className="btn btn-link text-white-50" to="/Testimonial">Terms & Condition</Link>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Contact</h5>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>123 Ahemdabad, India</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+91 99021 23412</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>jobentry@email.com</p>
                        <div class="d-flex pt-2">
  <a class="btn btn-outline-light btn-social" 
     href="https://twitter.com" 
     target="_blank" 
     rel="noopener noreferrer">
     <i class="fab fa-twitter"></i>
  </a>

  <a class="btn btn-outline-light btn-social" 
     href="https://facebook.com" 
     target="_blank" 
     rel="noopener noreferrer">
     <i class="fab fa-facebook-f"></i>
  </a>

  <a class="btn btn-outline-light btn-social" 
     href="https://youtube.com" 
     target="_blank" 
     rel="noopener noreferrer">
     <i class="fab fa-youtube"></i>
  </a>

  <a class="btn btn-outline-light btn-social" 
     href="https://linkedin.com" 
     target="_blank" 
     rel="noopener noreferrer">
     <i class="fab fa-linkedin-in"></i>
  </a>
</div>

                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Newsletter</h5>
                        <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
                     <div className="position-relative mx-auto" style={{ maxWidth: "400px" }}>

                            {/* <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email"> */}
                           <input
  className="form-control bg-transparent w-100 py-3 ps-4 pe-5"
  type="text"
  placeholder="Your email"
/>
 {/* <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button> */}
 <button
          type="button"
          className="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2"
          onClick={() => navigate("/signin")}
        >
          SignUp
        </button>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>


       

       
    </div>
      
  );
};

export default Home;
